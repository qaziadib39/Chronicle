-- Run in Supabase > SQL Editor. Safe to run again after updates (v0.4).

-- One saved game per student.
create table if not exists public.progress (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null default '{}',
  updated_at timestamptz not null default now()
);
alter table public.progress enable row level security;

-- Basic sanity limits so a tampered client can't store junk. (Scores still come from the
-- browser, so treat them as practice data; read the essay text in `submissions` for grading.)
alter table public.progress drop constraint if exists progress_data_size;
alter table public.progress add constraint progress_data_size check (pg_column_size(data) < 200000);
alter table public.progress drop constraint if exists progress_xp_range;
alter table public.progress add constraint progress_xp_range
  check (coalesce((data->>'xp')::int, 0) between 0 and 2000);

drop policy if exists "read own progress" on public.progress;
drop policy if exists "insert own progress" on public.progress;
drop policy if exists "update own progress" on public.progress;
create policy "read own progress" on public.progress for select using (auth.uid() = user_id);
create policy "insert own progress" on public.progress for insert with check (auth.uid() = user_id);
create policy "update own progress" on public.progress for update using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- The server, not the browser, decides when a save happened.
create or replace function public.touch_updated_at() returns trigger language plpgsql as $$
begin new.updated_at := now(); return new; end $$;
drop trigger if exists progress_touch on public.progress;
create trigger progress_touch before insert or update on public.progress
  for each row execute function public.touch_updated_at();

-- Every SAQ / LEQ / DBQ submission, with the full answer text, for teacher review.
-- Students can add and read their own rows; nobody can edit or delete them from the app.
-- Teachers read them in the Supabase Table Editor (or with the service role key).
create table if not exists public.submissions (
  id bigint generated always as identity primary key,
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  challenge_id text not null check (challenge_id ~ '^c[0-9]+$'),
  score int not null check (score between 0 and 10),
  max_score int not null check (max_score between 1 and 10),
  answer jsonb not null check (pg_column_size(answer) < 100000),
  created_at timestamptz not null default now()
);
create index if not exists submissions_user_idx on public.submissions (user_id, created_at desc);
alter table public.submissions enable row level security;
drop policy if exists "insert own submissions" on public.submissions;
drop policy if exists "read own submissions" on public.submissions;
create policy "insert own submissions" on public.submissions for insert with check (auth.uid() = user_id);
create policy "read own submissions" on public.submissions for select using (auth.uid() = user_id);

-- Handy view for teachers: newest submissions with the student's email.
-- (Views run with the owner's rights; it is not exposed to students because it is in a private schema.)
create schema if not exists teacher;
create or replace view teacher.recent_submissions as
  select s.created_at, u.email, s.challenge_id, s.score, s.max_score, s.answer->>'essay' as essay, s.answer
  from public.submissions s join auth.users u on u.id = s.user_id
  order by s.created_at desc;
revoke all on schema teacher from anon, authenticated;
