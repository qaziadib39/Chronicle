import Phaser from 'phaser';
import { UI } from '../ui/ui';
import { runChallenge, xpFor, type Result } from '../ui/challenges';
import { showJournal } from '../ui/journal';
import { state, save, addXp, level } from '../state';
import { QUESTS, questDone } from '../quests';
import { AREAS, SOURCES, CHALLENGES, rankIndex, RANKS, type Area, type Exit, type Npc } from '../data/content';
import { buildAssets, buildGround, PROPS } from '../gfx/art';
import { registerChar, DIRS, portraits, PLAYER_LOOK } from '../gfx/chars';
import { sfx } from '../audio';
import { touch, mountTouchControls } from '../touch';

interface Thing { label: string; x: number; y: number; act: () => void }
interface Obj { id: string; sourceId: string; sprite: Phaser.GameObjects.Image; glow: Phaser.GameObjects.Image; tween: Phaser.Tweens.Tween }
interface NpcView { npc: Npc; sprite: Phaser.GameObjects.Sprite; mark: Phaser.GameObjects.Text }

export class GameScene extends Phaser.Scene {
  private ui!: UI;
  private player!: Phaser.Physics.Arcade.Sprite;
  private keys!: Record<string, Phaser.Input.Keyboard.Key>;
  private things: Thing[] = [];
  private objs: Obj[] = [];
  private npcViews: NpcView[] = [];
  private waters: Phaser.GameObjects.TileSprite[] = [];
  private area: Area = AREAS.crossroads;
  private spawn?: [number, number];
  private dir = 0;
  private dustAt = 0;
  private busy = false;
  private dust!: Phaser.GameObjects.Particles.ParticleEmitter;

  constructor() { super('Game'); }

  init(data: { spawn?: [number, number] }): void {
    this.area = AREAS[state.area] ?? AREAS.crossroads;
    this.spawn = data?.spawn;
    this.things = []; this.objs = []; this.npcViews = []; this.waters = []; this.busy = false;
  }

  create(): void {
    if (!this.ui) {
      this.ui = new UI();
      // While a panel is open, Phaser must not swallow keystrokes (it calls preventDefault on
      // WASD/E/Space/etc.), or students cannot type those letters into their answers.
      this.ui.onOpen = () => {
        const kb = this.input.keyboard!;
        kb.disableGlobalCapture(); kb.enabled = false;
      };
      this.ui.onClose = () => {
        const kb = this.input.keyboard!;
        kb.enableGlobalCapture(); kb.enabled = true; kb.resetKeys();
      };
      mountTouchControls();
    }
    buildAssets(this);
    const a = this.area;
    state.flags['visited_' + a.id] = true;
    registerChar(this, 'player', PLAYER_LOOK);
    a.npcs.forEach((n) => registerChar(this, 'npc_' + n.id, n.look));
    (document.getElementById('grade') as HTMLElement).style.background = a.grade;
    this.physics.world.setBounds(0, 0, a.w, a.h);

    buildGround(this, 'ground_' + a.id, a.w, a.h, a.ground, a.paths, a.seed);
    this.add.image(0, 0, 'ground_' + a.id).setOrigin(0).setDepth(-1000);

    const zones: Phaser.GameObjects.Zone[] = [];
    const solid = (x: number, y: number, w: number, h: number) => {
      const z = this.add.zone(x, y, w, h); this.physics.add.existing(z, true); zones.push(z);
    };

    (a.water ?? []).forEach(([x, y, w, h]) => {
      this.waters.push(this.add.tileSprite(x, y, w, h, 'wave').setOrigin(0).setDepth(-900));
      this.waters.push(this.add.tileSprite(x, y, w, h, 'wave').setOrigin(0).setDepth(-899).setAlpha(0.28).setBlendMode(Phaser.BlendModes.ADD));
      const f = this.add.graphics().setDepth(-898); f.lineStyle(4, 0xffffff, 0.5); f.lineBetween(x, y + 1, x + w, y + 1);
      this.tweens.add({ targets: f, alpha: 0.3, yoyo: true, repeat: -1, duration: 1300 });
      solid(x + w / 2, y + h / 2, w, h);
    });

    a.props.forEach((p) => {
      const def = PROPS[p.t];
      this.add.image(p.x, p.y, 'prop_' + p.t).setOrigin(0.5, 1).setDepth(p.y);
      if (def.fw) solid(p.x, p.y - def.fh / 2, def.fw, def.fh);
      if (p.t === 'lantern') {
        const gl = this.add.image(p.x, p.y - 36, 'glow').setBlendMode(Phaser.BlendModes.ADD).setDepth(p.y + 1).setAlpha(0.7).setScale(1.4);
        this.tweens.add({ targets: gl, alpha: 0.4, scale: 1.2, yoyo: true, repeat: -1, duration: 900 + Math.random() * 400 });
      }
    });

    for (const n of a.npcs) {
      const s = this.add.sprite(n.x, n.y, 'npc_' + n.id, 0).setOrigin(0.5, 1).setDepth(n.y);
      this.tweens.add({ targets: s, scaleY: 1.03, yoyo: true, repeat: -1, duration: 1100 + Math.random() * 500, ease: 'Sine.easeInOut' });
      this.add.text(n.x, n.y - 36, n.name, { fontFamily: 'Georgia, serif', fontSize: '12px', color: '#fff6d8', stroke: '#1d1420', strokeThickness: 3 })
        .setOrigin(0.5, 1).setDepth(9999).setResolution(2);
      const mark = this.add.text(n.x, n.y - 52, '!', { fontFamily: 'Georgia, serif', fontSize: '20px', fontStyle: 'bold', color: '#ffd34d', stroke: '#1d1420', strokeThickness: 4 })
        .setOrigin(0.5, 1).setDepth(9999).setResolution(2);
      this.tweens.add({ targets: mark, y: mark.y - 5, yoyo: true, repeat: -1, duration: 600, ease: 'Sine.easeInOut' });
      this.npcViews.push({ npc: n, sprite: s, mark });
      this.things.push({ label: `Talk to ${n.name}`, x: n.x, y: n.y - 12, act: () => this.talk(n.id) });
    }

    for (const o of a.objects) {
      const glow = this.add.image(o.x, o.y, 'glow').setBlendMode(Phaser.BlendModes.ADD).setDepth(o.y - 1).setScale(0.8);
      const sprite = this.add.image(o.x, o.y, 'ico_' + o.icon).setDepth(o.y).setScale(1.3);
      const tween = this.tweens.add({ targets: [sprite], y: o.y - 4, yoyo: true, repeat: -1, duration: 800, ease: 'Sine.easeInOut' });
      this.tweens.add({ targets: glow, alpha: 0.35, scale: 1.1, yoyo: true, repeat: -1, duration: 900 });
      this.objs.push({ id: o.id, sourceId: o.sourceId, sprite, glow, tween });
      this.things.push({ label: `Examine ${o.label}`, x: o.x, y: o.y, act: () => this.examine(o.sourceId) });
    }

    for (const e of a.exits) {
      const glow = this.add.image(e.x, e.y, 'glow').setTint(0xb48cff).setBlendMode(Phaser.BlendModes.ADD).setDepth(e.y - 1).setScale(1.2);
      this.tweens.add({ targets: glow, alpha: 0.4, yoyo: true, repeat: -1, duration: 800 });
      const s = this.add.image(e.x, e.y, 'ico_gate').setDepth(e.y).setFlipX(e.x < a.w / 2);
      this.tweens.add({ targets: s, x: e.x + (e.x < a.w / 2 ? -5 : 5), yoyo: true, repeat: -1, duration: 700 });
      this.things.push({ label: `Travel to ${e.label}`, x: e.x, y: e.y, act: () => this.travel(e) });
    }

    this.add.particles(0, 0, 'mote', {
      x: { min: 0, max: a.w }, y: { min: 0, max: a.h }, lifespan: 5000,
      speedX: { min: -12, max: 12 }, speedY: { min: -10, max: -2 },
      scale: { start: 0.8, end: 0 }, alpha: { start: 0.55, end: 0 }, frequency: 90, blendMode: 'ADD', tint: a.mote,
    }).setDepth(10000);
    this.dust = this.add.particles(0, 0, 'mote', {
      lifespan: 380, speed: { min: 6, max: 22 }, scale: { start: 1.1, end: 0 }, alpha: { start: 0.5, end: 0 }, tint: 0xd9c6a0, emitting: false,
    }).setDepth(9000);

    const [sx, sy] = this.spawn ?? a.spawn;
    this.player = this.physics.add.sprite(sx, sy, 'player', 0).setOrigin(0.5, 1);
    this.player.setCollideWorldBounds(true);
    (this.player.body as Phaser.Physics.Arcade.Body).setSize(12, 8).setOffset(6, 24);
    zones.forEach((z) => this.physics.add.collider(this.player, z));

    const cam = this.cameras.main;
    cam.setZoom(1.5); cam.setBounds(0, 0, a.w, a.h); cam.startFollow(this.player, true, 0.1, 0.1); cam.setRoundPixels(true);
    cam.fadeIn(450, 0, 0, 0);

    this.keys = this.input.keyboard!.addKeys('W,A,S,D,UP,DOWN,LEFT,RIGHT,E,SPACE,J,M') as Record<string, Phaser.Input.Keyboard.Key>;
    this.refresh();
    this.ui.toast(a.name);
    // Test hook for automated play-throughs. Only exists in `npm run dev`, never in a production build.
    if (import.meta.env.DEV) (window as unknown as Record<string, unknown>).__chronicle = { scene: this, state };
  }

  update(_t: number, delta: number): void {
    this.waters.forEach((t, i) => { t.tilePositionX += (i % 2 ? -0.35 : 0.2) * delta / 16; t.tilePositionY += 0.08 * delta / 16; });
    const body = this.player.body as Phaser.Physics.Arcade.Body;
    if (this.ui.isOpen() || this.busy) {
      body.setVelocity(0); this.player.anims.stop(); this.player.setFrame(this.dir * 3); this.ui.prompt(null);
      touch.act = false; touch.journal = false;
      return;
    }

    const k = this.keys;
    const dx = (k.D.isDown || k.RIGHT.isDown ? 1 : 0) - (k.A.isDown || k.LEFT.isDown ? 1 : 0) || touch.dx;
    const dy = (k.S.isDown || k.DOWN.isDown ? 1 : 0) - (k.W.isDown || k.UP.isDown ? 1 : 0) || touch.dy;
    body.setVelocity(dx, dy);
    if (dx || dy) {
      body.velocity.normalize().scale(135);
      this.dir = Math.abs(dx) > Math.abs(dy) ? (dx < 0 ? 1 : 2) : (dy < 0 ? 3 : 0);
      this.player.anims.play(`player-${DIRS[this.dir]}`, true);
      if (this.time.now - this.dustAt > 160) { this.dustAt = this.time.now; this.dust.emitParticleAt(this.player.x, this.player.y - 2, 1); }
    } else { this.player.anims.stop(); this.player.setFrame(this.dir * 3); }
    this.player.setDepth(this.player.y);

    for (const v of this.npcViews) {
      v.mark.setVisible(this.hasWork(v.npc));
      const ddx = this.player.x - v.sprite.x, ddy = this.player.y - v.sprite.y;
      if (Math.abs(ddx) < 110 && Math.abs(ddy) < 110) {
        const d = Math.abs(ddx) > Math.abs(ddy) ? (ddx < 0 ? 1 : 2) : (ddy < 0 ? 3 : 0);
        v.sprite.setFrame(d * 3);
      }
    }

    let near: Thing | null = null, best = 42;
    const py = this.player.y - 10;
    for (const t of this.things) {
      const d = Phaser.Math.Distance.Between(this.player.x, py, t.x, t.y);
      if (d < best) { best = d; near = t; }
    }
    this.ui.prompt(near ? `[E] ${near.label}` : null);

    if (Phaser.Input.Keyboard.JustDown(k.M)) this.ui.toast(sfx.toggleMute() ? 'Sound off' : 'Sound on');
    const ready = performance.now() - this.ui.closedAt > 250;
    const journal = Phaser.Input.Keyboard.JustDown(k.J) || touch.journal;
    const pressed = Phaser.Input.Keyboard.JustDown(k.E) || Phaser.Input.Keyboard.JustDown(k.SPACE) || touch.act;
    touch.act = false; touch.journal = false;
    if (!ready) return;
    if (journal) { showJournal(this.ui); return; }
    if (pressed && near) near.act();
  }

  private hasWork(n: Npc): boolean {
    if (n.talkFlag && !state.flags[n.talkFlag]) return true;
    return !!n.offers && n.offers.ready() && !state.passed.includes(n.offers.challengeId);
  }

  private travel(e: Exit): void {
    const msg = e.requires?.();
    if (msg) { this.ui.toast(msg); return; }
    this.busy = true; sfx.travel();
    state.area = e.to; save();
    const cam = this.cameras.main;
    cam.fadeOut(350, 0, 0, 0);
    cam.once(Phaser.Cameras.Scene2D.Events.FADE_OUT_COMPLETE, () => this.scene.restart({ spawn: e.spawn }));
  }

  private talk(id: string): void {
    const npc = this.area.npcs.find((n) => n.id === id)!;
    sfx.click();
    this.ui.showDialogue(npc.name, npc.lines(), () => {
      if (npc.talkFlag && !state.flags[npc.talkFlag]) { state.flags[npc.talkFlag] = true; this.gain(10, `Met ${npc.name}`); }
      const o = npc.offers;
      if (o && o.ready() && !state.passed.includes(o.challengeId)) this.challenge(o.challengeId);
      this.refresh();
    }, portraits['npc_' + id]);
  }

  private examine(sourceId: string): void {
    const s = SOURCES[sourceId];
    sfx.pickup();
    this.ui.showSource(s, () => {
      if (!state.examined.includes(sourceId)) { state.examined.push(sourceId); this.gain(10, `Collected: ${s.title}`); }
      this.refresh();
    });
  }

  private challenge(id: string): void {
    const c = CHALLENGES[id];
    runChallenge(this.ui, c, c.sourceIds.map((i) => SOURCES[i]), (r: Result) => {
      if (r.passed && !state.passed.includes(id)) {
        const rankBefore = rankIndex();
        state.passed.push(id);
        sfx.good();
        this.gain(xpFor(c, r), `${c.title} passed!`);
        const rankAfter = rankIndex();
        if (rankAfter > rankBefore) this.time.delayedCall(1700, () => { sfx.level(); this.ui.toast(`★ New rank: ${RANKS[rankAfter].title}!`); });
      }
      this.refresh();
    });
  }

  private gain(xp: number, msg: string): void {
    const before = level();
    addXp(xp);
    const up = level() > before;
    if (up) sfx.level();
    this.ui.toast(`+${xp} XP: ${msg}${up ? `  • Level ${level()}!` : ''}`);
  }

  private refresh(): void {
    for (const q of QUESTS) {
      const key = `done_${q.id}`;
      if (questDone(q) && !state.flags[key]) {
        state.flags[key] = true;
        this.time.delayedCall(900, () => this.ui.toast(`Quest complete: ${q.title}`));
      }
    }
    this.objs.forEach((o) => {
      if (state.examined.includes(o.sourceId)) { o.glow.setVisible(false); o.sprite.setAlpha(0.45); }
    });
    save(); this.ui.renderHud();
  }
}
