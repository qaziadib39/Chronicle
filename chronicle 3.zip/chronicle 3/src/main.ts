import { showTitle } from './ui/title';
import { sfx } from './audio';

// The game engine (Phaser, ~1.2 MB) loads only after the student presses Start,
// so the title screen appears quickly on slow school networks.
void showTitle(async () => {
  sfx.resume();
  const [{ default: Phaser }, { GameScene }] = await Promise.all([import('phaser'), import('./scenes/GameScene')]);
  new Phaser.Game({
    type: Phaser.AUTO,
    parent: 'game',
    width: 960,
    height: 600,
    backgroundColor: '#14101a',
    pixelArt: true,
    scale: { mode: Phaser.Scale.FIT, autoCenter: Phaser.Scale.CENTER_BOTH },
    physics: { default: 'arcade', arcade: { debug: false } },
    scene: [GameScene],
  });
});
