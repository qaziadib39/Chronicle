// Procedural pixel-art: terrain, props, icons. Everything is drawn on canvases at runtime.
import Phaser from 'phaser';

export type G = CanvasRenderingContext2D;
export type Ground = 'grass' | 'sand' | 'cobble';
export type PathKind = 'dirt' | 'plank' | 'cobble';
export type PathSpec = [number, number, number, number, PathKind?];
export type Rect = [number, number, number, number];

export const rng = (seed: number) => {
  let s = (seed >>> 0) || 1;
  return () => (s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 4294967296;
};
export const mk = (w: number, h: number): [HTMLCanvasElement, G] => {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const g = c.getContext('2d')!; g.imageSmoothingEnabled = false; return [c, g];
};
export const R = (g: G, c: string, x: number, y: number, w: number, h: number): void => {
  g.fillStyle = c; g.fillRect(Math.round(x), Math.round(y), Math.max(0, Math.round(w)), Math.max(0, Math.round(h)));
};
export const O = (g: G, c: string, cx: number, cy: number, rx: number, ry: number): void => {
  g.fillStyle = c; g.beginPath(); g.ellipse(cx, cy, Math.max(0.5, rx), Math.max(0.5, ry), 0, 0, Math.PI * 2); g.fill();
};
export const adj = (c: string, d: number): string => {
  const n = parseInt(c.slice(1), 16); const f = (v: number) => Math.max(0, Math.min(255, v + d));
  return `rgb(${f(n >> 16)},${f((n >> 8) & 255)},${f(n & 255)})`;
};
const shade = (g: G, cx: number, cy: number, rx: number, ry: number) => O(g, 'rgba(0,0,0,.28)', cx, cy, rx, ry);

/** Dark 1px outline around opaque pixels (gives the sprites a crisp pixel-art look). */
export function outline(g: G, w: number, h: number, col = '#24171f'): void {
  const d = g.getImageData(0, 0, w, h), src = d.data, out = new Uint8ClampedArray(src);
  const rgb = [parseInt(col.slice(1, 3), 16), parseInt(col.slice(3, 5), 16), parseInt(col.slice(5, 7), 16)];
  const dirs = [[1, 0], [-1, 0], [0, 1], [0, -1]];
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const i = (y * w + x) * 4;
    if (src[i + 3] > 40) continue;
    const hit = dirs.some(([dx, dy]) => {
      const xx = x + dx, yy = y + dy;
      return xx >= 0 && yy >= 0 && xx < w && yy < h && src[(yy * w + xx) * 4 + 3] > 200;
    });
    if (hit) { out[i] = rgb[0]; out[i + 1] = rgb[1]; out[i + 2] = rgb[2]; out[i + 3] = 255; }
  }
  g.putImageData(new ImageData(out, w, h), 0, 0);
}

// ---------- Ground ----------
const GPAL: Record<Ground, { base: string; a: string; b: string }> = {
  grass: { base: '#4f8a4a', a: '#62a058', b: '#3f7a3f' },
  sand: { base: '#dcc58e', a: '#e9d7a8', b: '#cdb27a' },
  cobble: { base: '#b9a98c', a: '#cbbc9f', b: '#a69673' },
};
const PPAL: Record<PathKind, [string, string, string]> = {
  dirt: ['#c4a56c', '#d6bb85', '#9c7e4c'],
  plank: ['#8a5a34', '#a06e42', '#5f3b20'],
  cobble: ['#a39784', '#b8ad9a', '#7f7464'],
};

export function buildGround(scene: Phaser.Scene, key: string, w: number, h: number, ground: Ground, paths: PathSpec[], seed: number): void {
  if (scene.textures.exists(key)) return;
  const [c, g] = mk(w, h), r = rng(seed), p = GPAL[ground];
  R(g, p.base, 0, 0, w, h);
  g.globalAlpha = 0.35;
  for (let i = 0; i < (w * h) / 5000; i++) O(g, r() < 0.5 ? p.a : p.b, r() * w, r() * h, 30 + r() * 60, 20 + r() * 40);
  g.globalAlpha = 1;
  for (let i = 0; i < (w * h) / 70; i++) {
    const x = r() * w, y = r() * h;
    R(g, r() < 0.5 ? p.a : p.b, x, y, 2, 2);
    if (ground === 'grass' && r() < 0.4) { R(g, '#2f6a33', x, y - 3, 1, 3); R(g, '#7ab85e', x + 2, y - 4, 1, 3); }
  }
  const inPath = (x: number, y: number) => paths.some(([px, py, pw, ph]) => x > px - 12 && x < px + pw + 12 && y > py - 12 && y < py + ph + 12);
  for (let i = 0; i < w * h / 4500; i++) {
    const x = r() * w, y = r() * h; if (inPath(x, y)) continue;
    if (ground === 'grass') {
      const col = ['#f4e36b', '#f2f2f2', '#e86a8a', '#9a7ae0'][Math.floor(r() * 4)];
      R(g, '#2f6a33', x + 1, y + 2, 1, 3); R(g, col, x, y, 3, 3); R(g, '#fff6b0', x + 1, y + 1, 1, 1);
    } else { O(g, adj(p.b, -20), x, y, 3, 2); R(g, p.a, x - 1, y - 2, 2, 1); }
  }
  paths.forEach(([x, y, pw, ph, k = 'dirt']) => R(g, PPAL[k][2], x - 4, y - 4, pw + 8, ph + 8));
  paths.forEach(([x, y, pw, ph, k = 'dirt']) => {
    const [base, hi, lo] = PPAL[k];
    if (k === 'cobble') {
      R(g, lo, x, y, pw, ph);
      for (let yy = y; yy < y + ph; yy += 16) for (let xx = x - ((yy - y) / 16 % 2 ? 8 : 0); xx < x + pw; xx += 16) {
        const cx = Math.max(x, xx), cw = Math.min(x + pw, xx + 16) - cx;
        if (cw > 2) { R(g, r() < 0.5 ? hi : base, cx + 1, yy + 1, cw - 2, 14); R(g, adj('#a39784', 28), cx + 1, yy + 1, cw - 2, 2); }
      }
    } else if (k === 'plank') {
      R(g, base, x, y, pw, ph);
      for (let yy = y; yy < y + ph; yy += 8) { R(g, lo, x, yy, pw, 1); R(g, hi, x, yy + 1, pw, 1); }
      for (let xx = x + 16 + r() * 20; xx < x + pw; xx += 24 + r() * 40) R(g, lo, xx, y, 1, ph);
    } else {
      R(g, base, x, y, pw, ph);
      for (let i = 0; i < pw * ph / 40; i++) R(g, r() < 0.5 ? hi : lo, x + r() * pw, y + r() * ph, 2, 1);
      for (let i = 0; i < pw * ph / 700; i++) O(g, lo, x + r() * pw, y + r() * ph, 2, 1.5);
    }
  });
  scene.textures.addCanvas(key, c);
}

// ---------- Props ----------
export interface PropDef { w: number; h: number; fw: number; fh: number; draw: (g: G) => void; ol?: boolean; flat?: boolean }

function foliage(g: G, leaf: string, blobs: number[][], squash = 0.92): void {
  const dark = adj(leaf, -36), lite = adj(leaf, 28);
  blobs.forEach(([x, y, r]) => O(g, dark, x + 2, y + 4, r, r * squash));
  blobs.forEach(([x, y, r]) => O(g, leaf, x, y, r, r * squash));
  blobs.forEach(([x, y, r]) => O(g, lite, x - r * 0.3, y - r * 0.38, r * 0.5, r * 0.38));
}
const tree = (leaf: string) => (g: G) => {
  shade(g, 32, 76, 22, 6); R(g, '#5b3a22', 28, 48, 8, 28); R(g, '#7e5532', 28, 48, 3, 28); R(g, '#4a2e1a', 33, 52, 3, 24);
  foliage(g, leaf, [[32, 34, 22], [18, 44, 14], [46, 44, 14], [32, 20, 14], [20, 28, 12], [44, 28, 12]]);
};
const cypress = (g: G) => {
  shade(g, 20, 84, 12, 4); R(g, '#4a2e1a', 18, 74, 4, 10);
  [[20, 62, 11, 18], [20, 46, 10, 18], [20, 30, 8, 16], [20, 16, 5, 12]].forEach(([x, y, rx, ry]) => O(g, '#1f5a34', x + 1, y + 2, rx, ry));
  [[20, 62, 11, 18], [20, 46, 10, 18], [20, 30, 8, 16], [20, 16, 5, 12]].forEach(([x, y, rx, ry]) => { O(g, '#2f7a46', x, y, rx, ry); O(g, '#4a9a5c', x - 3, y - 4, rx * 0.4, ry * 0.4); });
};
const palm = (g: G) => {
  shade(g, 40, 100, 18, 5);
  for (let i = 0; i < 9; i++) R(g, i % 2 ? '#8a6a3e' : '#a07c48', 36 + Math.sin(i * 0.35) * 4 + i * 0.5, 94 - i * 8.5, 7, 9);
  const tx = 42, ty = 22;
  [-2.7, -2.1, -1.5, -0.6, 0.15, 0.85, 1.5, 2.15].forEach((a, i) => {
    g.save(); g.translate(tx, ty); g.rotate(a);
    g.fillStyle = i % 2 ? '#2f7a3a' : '#40984a'; g.beginPath(); g.ellipse(15, 0, 17, 4.5, 0, 0, Math.PI * 2); g.fill();
    g.fillStyle = '#235f2c'; g.fillRect(0, 0, 28, 1); g.restore();
  });
  O(g, '#6b4a2a', tx - 2, ty + 3, 3.5, 3.5); O(g, '#5a3a20', tx + 3, ty + 5, 3, 3);
};
const bush = (g: G) => { shade(g, 18, 25, 15, 3); foliage(g, '#3f8a46', [[18, 16, 11], [8, 19, 7], [28, 19, 7]]); };
const rock = (g: G) => { shade(g, 14, 17, 12, 3); O(g, '#6f6a62', 14, 11, 11, 7); O(g, '#8a847a', 12, 9, 8, 5); O(g, '#a39d92', 10, 7, 4, 2.5); };

interface HouseOpt { wall: string; trim: string; roof: string; door: string; dome?: string; shutters?: string }
const house = (o: HouseOpt) => (g: G) => {
  shade(g, 64, 110, 58, 6);
  R(g, o.wall, 12, 40, 104, 68); R(g, adj(o.wall, -24), 12, 40, 10, 68); R(g, adj(o.wall, 20), 22, 40, 94, 3);
  const r = rng(11); for (let i = 0; i < 80; i++) R(g, adj(o.wall, r() < 0.5 ? -14 : 12), 14 + r() * 98, 46 + r() * 58, 3, 2);
  R(g, o.roof, 8, 32, 112, 12); R(g, adj(o.roof, -34), 8, 42, 112, 3); R(g, adj(o.roof, 26), 8, 32, 112, 2);
  for (let x = 14; x < 116; x += 14) R(g, '#5b3a22', x, 44, 6, 4);
  if (o.dome) {
    g.save(); g.beginPath(); g.rect(0, 0, 128, 33); g.clip();
    O(g, adj(o.dome, -30), 66, 34, 31, 29); O(g, o.dome, 64, 32, 30, 28); O(g, adj(o.dome, 30), 54, 22, 11, 9); g.restore();
    R(g, '#e8c46a', 63, 0, 2, 7); O(g, '#e8c46a', 64, 3, 3, 3);
  }
  g.fillStyle = o.door; g.beginPath(); g.moveTo(51, 108); g.lineTo(51, 84); g.arc(64, 84, 13, Math.PI, 0); g.lineTo(77, 108); g.fill();
  R(g, adj(o.door, -34), 63, 76, 2, 32); R(g, '#e8c46a', 70, 94, 2, 2);
  [[24, 60], [92, 60]].forEach(([x, y]) => {
    R(g, '#2a2230', x, y, 12, 16); R(g, o.shutters ?? o.trim, x - 3, y, 3, 16); R(g, o.shutters ?? o.trim, x + 12, y, 3, 16); R(g, '#ffd77a', x + 2, y + 2, 8, 5);
  });
  R(g, o.trim, 12, 104, 104, 4);
};
const roofTier = (g: G, x0: number, x1: number, yb: number, h: number, col: string) => {
  g.fillStyle = col; g.beginPath(); g.moveTo(x0 - 8, yb - 8); g.lineTo(x0, yb); g.lineTo(x1, yb); g.lineTo(x1 + 8, yb - 8); g.lineTo(x1 - 14, yb - h); g.lineTo(x0 + 14, yb - h); g.fill();
  g.strokeStyle = adj(col, -30); g.lineWidth = 1;
  for (let x = x0 + 6; x < x1; x += 8) { g.beginPath(); g.moveTo(x, yb - 1); g.lineTo(x + (x - (x0 + x1) / 2) * 0.12, yb - h + 2); g.stroke(); }
  R(g, adj(col, -50), x0, yb, x1 - x0, 3); R(g, '#e8c46a', x0 + 12, yb - h - 1, x1 - x0 - 24, 2);
};
const pavilion = (g: G) => {
  shade(g, 72, 122, 66, 6); R(g, '#8f8a80', 8, 108, 128, 10); R(g, '#b0aaa0', 8, 108, 128, 2);
  R(g, '#efe2c0', 20, 70, 104, 38);
  [22, 52, 86, 116].forEach((x) => { R(g, '#b3302e', x, 66, 6, 42); R(g, '#7a1f1f', x + 4, 66, 2, 42); });
  R(g, '#3a1d1d', 60, 82, 24, 26); R(g, '#e8c46a', 59, 80, 26, 2); R(g, '#e8c46a', 71, 90, 2, 18);
  roofTier(g, 10, 134, 70, 22, '#2f6f5a'); roofTier(g, 36, 108, 46, 22, '#38806a');
  R(g, '#e8c46a', 70, 12, 4, 12); O(g, '#e8c46a', 72, 11, 3, 3);
};
const stall = (c1: string, c2: string, goods: string[]) => (g: G) => {
  shade(g, 36, 61, 33, 4); R(g, '#5b3a22', 6, 18, 4, 42); R(g, '#5b3a22', 62, 18, 4, 42);
  R(g, '#7a5030', 4, 40, 64, 18); R(g, '#9a6a40', 4, 40, 64, 3); R(g, '#5b3a22', 4, 55, 64, 3);
  goods.forEach((c, i) => { O(g, adj(c, -30), 15 + i * 12, 39, 5, 4); O(g, c, 14 + i * 12, 38, 5, 4); });
  for (let i = 0; i < 8; i++) { const c = i % 2 ? c1 : c2; R(g, c, 4 + i * 8, 8, 8, 18); O(g, c, 8 + i * 8, 26, 4, 3); }
  R(g, 'rgba(0,0,0,.18)', 4, 24, 64, 2);
};
const tent = (c1: string, c2: string) => (g: G) => {
  shade(g, 44, 70, 40, 4);
  g.save(); g.beginPath(); g.moveTo(4, 68); g.lineTo(44, 6); g.lineTo(84, 68); g.closePath(); g.clip();
  for (let i = 0; i < 12; i++) R(g, i % 2 ? c1 : c2, 4 + i * 7, 0, 7, 70);
  R(g, 'rgba(0,0,0,.22)', 44, 0, 44, 70); g.restore();
  g.fillStyle = '#2a1a24'; g.beginPath(); g.moveTo(34, 68); g.lineTo(44, 36); g.lineTo(54, 68); g.fill();
  R(g, '#5b3a22', 43, 0, 2, 8);
};
const well = (g: G) => {
  shade(g, 24, 48, 22, 4); R(g, '#8a8378', 6, 30, 36, 16); O(g, '#9a9488', 24, 30, 18, 8); O(g, '#1c2a3a', 24, 30, 13, 5); O(g, '#3a6a8a', 24, 31, 10, 3);
  R(g, '#a39d92', 6, 30, 36, 3); R(g, '#5b3a22', 7, 8, 3, 26); R(g, '#5b3a22', 38, 8, 3, 26); R(g, '#7a5030', 4, 6, 40, 4);
  g.fillStyle = '#9a3a2a'; g.beginPath(); g.moveTo(2, 8); g.lineTo(24, -0); g.lineTo(46, 8); g.fill(); R(g, '#c5c0b4', 23, 10, 2, 12); R(g, '#7a5030', 20, 22, 8, 5);
};
const fountain = (g: G) => {
  shade(g, 40, 66, 34, 5); O(g, '#8a8378', 40, 54, 34, 14); O(g, '#aaa498', 40, 51, 34, 13); O(g, '#3f86bd', 40, 50, 29, 10); O(g, '#7cc2ea', 40, 49, 22, 6);
  R(g, '#aaa498', 36, 22, 8, 28); R(g, '#c8c2b6', 36, 22, 3, 28); O(g, '#aaa498', 40, 24, 14, 5); O(g, '#7cc2ea', 40, 23, 11, 3);
  [[40, 6], [34, 12], [46, 12]].forEach(([x, y]) => R(g, '#cdeffd', x, y, 2, 12));
};
const minaret = (g: G) => {
  shade(g, 20, 134, 16, 4); R(g, '#e8dcc0', 12, 40, 16, 94); R(g, '#c9bd9f', 12, 40, 5, 94);
  for (let y = 54; y < 130; y += 14) R(g, '#b8ab8b', 12, y, 16, 2);
  R(g, '#d4c8aa', 7, 54, 26, 5); R(g, '#a99d80', 7, 58, 26, 2); R(g, '#7a6f58', 15, 100, 10, 18);
  g.fillStyle = '#6f7f9a'; g.beginPath(); g.moveTo(10, 40); g.lineTo(30, 40); g.lineTo(20, 8); g.fill();
  g.fillStyle = '#8a9ab4'; g.beginPath(); g.moveTo(10, 40); g.lineTo(18, 40); g.lineTo(20, 8); g.fill();
  R(g, '#e8c46a', 19, 0, 2, 9); O(g, '#e8c46a', 20, 3, 3, 3);
};
const barrel = (g: G) => { shade(g, 12, 25, 10, 3); R(g, '#7a5030', 3, 6, 18, 18); O(g, '#8a6038', 12, 6, 9, 3); O(g, '#5b3a22', 12, 24, 9, 3); R(g, '#3a3a44', 3, 10, 18, 2); R(g, '#3a3a44', 3, 18, 18, 2); R(g, '#a07040', 6, 8, 3, 15); };
const crates = (g: G) => { shade(g, 16, 27, 14, 3); R(g, '#9a6a40', 3, 8, 24, 18); R(g, '#7a5030', 3, 8, 24, 3); R(g, '#7a5030', 3, 22, 24, 3); R(g, '#7a5030', 13, 8, 3, 18); R(g, '#b88650', 5, 12, 6, 2); };
const sacks = (g: G) => { shade(g, 16, 22, 14, 3); [[10, 14], [22, 14], [16, 8]].forEach(([x, y]) => { O(g, '#c9b27c', x, y + 3, 8, 8); O(g, '#dcc690', x - 2, y, 4, 4); R(g, '#8a6a3a', x - 2, y - 5, 4, 2); }); };
const camel = (blanket: string) => (g: G) => {
  shade(g, 36, 49, 27, 4); const body = '#c79a5b', dk = '#a67c44';
  [[18, 32], [24, 34], [44, 32], [50, 34]].forEach(([x, y], i) => { R(g, i % 2 ? dk : body, x, y, 4, 14); R(g, '#5a4026', x, y + 13, 5, 2); });
  O(g, body, 36, 28, 22, 10); O(g, dk, 38, 34, 20, 5); O(g, body, 28, 17, 7, 8); O(g, body, 42, 18, 6, 8);
  R(g, blanket, 22, 22, 24, 6); R(g, '#fff1c9', 22, 24, 24, 1); R(g, dk, 8, 26, 5, 4);
  g.fillStyle = body; g.beginPath(); g.moveTo(52, 26); g.lineTo(60, 8); g.lineTo(65, 10); g.lineTo(60, 28); g.fill();
  O(g, body, 64, 9, 6, 4); R(g, '#1d1420', 66, 7, 2, 2);
};
const dhow = (g: G) => {
  O(g, 'rgba(0,10,30,.35)', 96, 114, 82, 9);
  g.fillStyle = '#6b4426'; g.beginPath(); g.moveTo(14, 86); g.quadraticCurveTo(96, 112, 182, 78); g.lineTo(176, 98); g.quadraticCurveTo(96, 126, 24, 104); g.closePath(); g.fill();
  R(g, '#8a5a34', 22, 84, 150, 6); R(g, '#e8c46a', 20, 82, 6, 5); R(g, '#4a2e1a', 92, 10, 4, 76);
  g.fillStyle = '#f3e9cf'; g.beginPath(); g.moveTo(96, 12); g.lineTo(170, 76); g.lineTo(96, 80); g.closePath(); g.fill();
  g.fillStyle = '#e0d3b0'; g.beginPath(); g.moveTo(96, 12); g.lineTo(96, 80); g.lineTo(120, 78); g.closePath(); g.fill();
  g.strokeStyle = '#c8ba94'; g.lineWidth = 1; for (let i = 1; i < 5; i++) { g.beginPath(); g.moveTo(96, 14 + i * 13); g.lineTo(96 + 66 - i * 8, 76 - (4 - i) * 0 ); g.stroke(); }
  g.strokeStyle = '#3a2418'; g.beginPath(); g.moveTo(96, 12); g.lineTo(16, 84); g.stroke();
};
const banner = (c: string) => (g: G) => {
  shade(g, 16, 76, 8, 2); R(g, '#5b3a22', 14, 6, 4, 70); O(g, '#e8c46a', 16, 5, 3, 3);
  R(g, c, 18, 10, 12, 30); R(g, adj(c, -30), 18, 10, 3, 30); R(g, '#e8c46a', 18, 14, 12, 2); R(g, '#e8c46a', 18, 34, 12, 2);
  g.fillStyle = c; g.beginPath(); g.moveTo(18, 40); g.lineTo(24, 46); g.lineTo(30, 40); g.fill();
};
const lantern = (g: G) => {
  shade(g, 10, 52, 6, 2); R(g, '#3a2a22', 8, 14, 4, 38); R(g, '#3a2a22', 4, 10, 12, 3);
  R(g, '#e8c46a', 5, 13, 10, 12); R(g, '#fff0a0', 7, 15, 6, 8); R(g, '#3a2a22', 4, 25, 12, 2); R(g, '#3a2a22', 6, 8, 8, 3);
};
const cannon = (g: G) => {
  shade(g, 28, 32, 24, 3); R(g, '#5b3a22', 8, 20, 36, 6);
  g.save(); g.translate(14, 18); g.rotate(-0.15); R(g, '#2e2e38', 0, -6, 38, 12); R(g, '#4a4a58', 0, -6, 38, 3); R(g, '#1d1d24', 36, -7, 5, 14); g.restore();
  O(g, '#6b4426', 18, 28, 8, 8); O(g, '#3a2418', 18, 28, 3, 3); O(g, '#6b4426', 38, 28, 6, 6); O(g, '#3a2418', 38, 28, 2, 2);
  [[50, 30], [54, 28]].forEach(([x, y]) => O(g, '#2e2e38', x, y, 3, 3));
};

export const PROPS: Record<string, PropDef> = {
  oak: { w: 64, h: 80, fw: 14, fh: 10, draw: tree('#3f8a46') },
  olive: { w: 64, h: 80, fw: 14, fh: 10, draw: tree('#6f9a5a') },
  cypress: { w: 40, h: 88, fw: 12, fh: 10, draw: cypress },
  palm: { w: 80, h: 104, fw: 12, fh: 10, draw: palm },
  bush: { w: 36, h: 28, fw: 22, fh: 8, draw: bush },
  rock: { w: 28, h: 20, fw: 20, fh: 8, draw: rock },
  house_mud: { w: 128, h: 116, fw: 100, fh: 26, draw: house({ wall: '#c99b62', trim: '#8a5a34', roof: '#a8793e', door: '#5b3a22' }) },
  house_dome: { w: 128, h: 116, fw: 100, fh: 26, draw: house({ wall: '#e0cfa6', trim: '#3f7aa8', roof: '#c8b484', door: '#3f2a1e', dome: '#4a8a9a', shutters: '#3f7aa8' }) },
  house_coral: { w: 128, h: 116, fw: 100, fh: 26, draw: house({ wall: '#efe6d2', trim: '#2a8a9a', roof: '#d9ccb0', door: '#6a3a22', shutters: '#2a8a9a' }) },
  pavilion: { w: 144, h: 128, fw: 112, fh: 26, draw: pavilion },
  stall_red: { w: 72, h: 64, fw: 56, fh: 16, draw: stall('#b3302e', '#f3e9cf', ['#e8c46a', '#c43d3d', '#6a9a3a']) },
  stall_blue: { w: 72, h: 64, fw: 56, fh: 16, draw: stall('#2f5aa8', '#f3e9cf', ['#d9822b', '#e8c46a', '#8a5ad9']) },
  tent_a: { w: 88, h: 72, fw: 56, fh: 16, draw: tent('#b3302e', '#e8d9b0') },
  tent_b: { w: 88, h: 72, fw: 56, fh: 16, draw: tent('#2f7a6a', '#e8d9b0') },
  well: { w: 48, h: 52, fw: 32, fh: 14, draw: well },
  fountain: { w: 80, h: 72, fw: 56, fh: 18, draw: fountain },
  minaret: { w: 40, h: 140, fw: 24, fh: 14, draw: minaret },
  barrel: { w: 24, h: 28, fw: 18, fh: 10, draw: barrel },
  crates: { w: 32, h: 30, fw: 24, fh: 10, draw: crates },
  sacks: { w: 32, h: 26, fw: 24, fh: 10, draw: sacks },
  camel_a: { w: 72, h: 52, fw: 44, fh: 14, draw: camel('#b3302e') },
  camel_b: { w: 72, h: 52, fw: 44, fh: 14, draw: camel('#2f5aa8') },
  dhow: { w: 192, h: 128, fw: 0, fh: 0, draw: dhow, ol: false },
  banner_red: { w: 32, h: 80, fw: 8, fh: 6, draw: banner('#b3302e') },
  banner_blue: { w: 32, h: 80, fw: 8, fh: 6, draw: banner('#2f5aa8') },
  lantern: { w: 20, h: 56, fw: 8, fh: 6, draw: lantern },
  cannon: { w: 64, h: 36, fw: 40, fh: 12, draw: cannon },
};

export function buildAssets(scene: Phaser.Scene): void {
  if (scene.textures.exists('wave')) return;
  const add = (key: string, w: number, h: number, draw: (g: G) => void, ol = false) => {
    const [c, g] = mk(w, h); draw(g); if (ol) outline(g, w, h); scene.textures.addCanvas(key, c);
  };
  Object.entries(PROPS).forEach(([k, p]) => add('prop_' + k, p.w, p.h, p.draw, p.ol !== false));
  add('ico_scroll', 24, 24, (g) => {
    R(g, '#f1e3bd', 5, 5, 14, 14); R(g, '#d9c493', 5, 16, 14, 3); O(g, '#e8d4a2', 5, 12, 3, 7); O(g, '#e8d4a2', 19, 12, 3, 7);
    [8, 11, 14].forEach((y) => R(g, '#8a5a34', 8, y, y === 14 ? 6 : 8, 1)); R(g, '#b3302e', 10, 18, 4, 4);
  }, true);
  add('ico_book', 24, 24, (g) => {
    R(g, '#8f2d2a', 4, 4, 16, 17); R(g, '#b3402e', 4, 4, 16, 3); R(g, '#f1e3bd', 6, 7, 12, 12); R(g, '#e8c46a', 9, 10, 6, 1); R(g, '#e8c46a', 9, 13, 6, 1); R(g, '#5a1a18', 4, 4, 3, 17);
  }, true);
  add('ico_coin', 24, 24, (g) => { O(g, '#b8872a', 12, 12, 8, 8); O(g, '#e8c46a', 12, 12, 7, 7); O(g, '#f6e08f', 10, 10, 3, 3); R(g, '#b8872a', 11, 9, 2, 6); }, true);
  add('ico_gate', 28, 40, (g) => {
    g.fillStyle = '#e8c46a'; g.beginPath(); g.moveTo(4, 4); g.lineTo(24, 20); g.lineTo(4, 36); g.lineTo(10, 20); g.fill();
    g.fillStyle = '#8a5ad9'; g.beginPath(); g.moveTo(8, 10); g.lineTo(19, 20); g.lineTo(8, 30); g.lineTo(11, 20); g.fill();
  }, true);
  add('glow', 64, 64, (g) => {
    const gr = g.createRadialGradient(32, 32, 2, 32, 32, 32); gr.addColorStop(0, 'rgba(255,230,150,.9)'); gr.addColorStop(1, 'rgba(255,230,150,0)');
    g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
  });
  add('mote', 8, 8, (g) => {
    const gr = g.createRadialGradient(4, 4, 0, 4, 4, 4); gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr; g.fillRect(0, 0, 8, 8);
  });
  add('wave', 64, 64, (g) => {
    const r = rng(3); R(g, '#2f78b5', 0, 0, 64, 64);
    for (let i = 0; i < 26; i++) { const x = r() * 54, y = r() * 62 + 1; R(g, '#4e9ad0', x, y, 6 + r() * 10, 2); R(g, '#8ec9ea', x + 2, y - 1, 4 + r() * 5, 1); }
    for (let i = 0; i < 10; i++) R(g, '#1f5f98', r() * 56, r() * 64, 8, 1);
  });
}
