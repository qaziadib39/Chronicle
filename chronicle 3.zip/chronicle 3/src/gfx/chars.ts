// Procedural 4-direction walking sprites + dialogue portraits.
import Phaser from 'phaser';
import { mk, R, O, adj, outline, type G } from './art';

export interface Look {
  skin: string; hair: string; robe: string; trim: string;
  hat?: 'turban' | 'cap' | 'hood' | 'conical' | 'scarf' | 'fez'; hatColor?: string; beard?: boolean;
}
export const DIRS = ['down', 'left', 'right', 'up'] as const;
export const portraits: Record<string, string> = {};
export const PLAYER_LOOK: Look = { skin: '#e0b88a', hair: '#3a2418', robe: '#2f9e8f', trim: '#e8c46a', hat: 'scarf', hatColor: '#e8c46a' };

function frame(g: G, ox: number, oy: number, dir: number, step: number, L: Look): void {
  const X = (c: string, x: number, y: number, w: number, h: number) => R(g, c, ox + x, oy + y, w, h);
  O(g, 'rgba(0,0,0,.3)', ox + 12, oy + 29, 8, 3);
  const shoe = '#3a2a22', skinD = adj(L.skin, -25);
  if (dir === 1 || dir === 2) { const sw = step === 0 ? 0 : step === 1 ? 3 : -3; X(shoe, 10 + sw, 26, 4, 4); X(shoe, 10 - sw, 26, 4, 4); }
  else { X(shoe, 8, step === 1 ? 25 : 26, 4, 4); X(shoe, 13, step === 2 ? 25 : 26, 4, 4); }
  X(L.robe, 6, 12, 12, 14); X(adj(L.robe, -22), 6, 24, 12, 2); X(adj(L.robe, -18), 15, 12, 3, 14);
  if (dir !== 3) X(L.trim, 6, 12, 12, 2);
  X(L.trim, 6, 19, 12, 1); X(L.trim, 6, 25, 12, 1);
  const a1 = step === 1 ? -1 : step === 2 ? 1 : 0;
  if (dir === 0 || dir === 3) {
    X(adj(L.robe, -10), 3, 13 + a1, 3, 9); X(adj(L.robe, -10), 18, 13 - a1, 3, 9); X(L.skin, 3, 22 + a1, 3, 2); X(L.skin, 18, 22 - a1, 3, 2);
  } else {
    const ax = (dir === 1 ? 9 : 11) + (step === 1 ? -2 : step === 2 ? 2 : 0);
    X(adj(L.robe, -14), ax, 13, 4, 9); X(L.skin, ax, 22, 4, 2);
  }
  if (dir === 0) {
    X(L.skin, 7, 3, 10, 9); X(skinD, 7, 11, 10, 1); X(L.hair, 7, 2, 10, 3); X(L.hair, 6, 3, 1, 5); X(L.hair, 17, 3, 1, 5);
    X('#1d1420', 9, 7, 2, 2); X('#1d1420', 13, 7, 2, 2); if (L.beard) X(L.hair, 8, 10, 8, 3);
  } else if (dir === 3) { X(L.skin, 7, 3, 10, 9); X(L.hair, 6, 2, 12, 10); }
  else {
    X(L.skin, 7, 3, 10, 9); X(L.hair, dir === 1 ? 12 : 6, 2, 6, 10); X(L.hair, 7, 2, 10, 3);
    X('#1d1420', dir === 1 ? 8 : 15, 7, 2, 2); if (L.beard) X(L.hair, dir === 1 ? 7 : 12, 10, 5, 3);
  }
  const hc = L.hatColor ?? '#e8c46a';
  switch (L.hat) {
    case 'turban': X(hc, 6, 0, 12, 6); X(adj(hc, -25), 6, 4, 12, 2); X(adj(hc, 20), 8, 1, 6, 2); break;
    case 'cap': X(hc, 7, 1, 10, 4); X(adj(hc, -25), 7, 4, 10, 1); break;
    case 'hood': X(L.robe, 6, 1, 12, 7); X(adj(L.robe, -20), 6, 1, 12, 1); break;
    case 'conical': for (let r = 0; r < 7; r++) { const w = 4 + r * 2.4; X(r % 2 ? hc : adj(hc, -18), 12 - w / 2, r, w, 1); } break;
    case 'scarf': X(hc, 6, 1, 12, 5); X(hc, 6, 5, 3, 7); X(adj(hc, -25), 6, 5, 1, 7); break;
    case 'fez': X(hc, 8, 0, 9, 4); X(adj(hc, -25), 8, 3, 9, 1); X('#e8c46a', 16, 1, 1, 5); break;
    default: break;
  }
}

export function registerChar(scene: Phaser.Scene, key: string, look: Look): void {
  if (scene.textures.exists(key)) return;
  const [c, g] = mk(72, 128);
  for (let d = 0; d < 4; d++) for (let s = 0; s < 3; s++) frame(g, s * 24, d * 32, d, s, look);
  outline(g, 72, 128);
  const tex = scene.textures.addCanvas(key, c)!;
  for (let i = 0; i < 12; i++) tex.add(i, 0, (i % 3) * 24, Math.floor(i / 3) * 32, 24, 32);
  DIRS.forEach((name, d) => {
    const ak = `${key}-${name}`;
    if (!scene.anims.exists(ak)) scene.anims.create({ key: ak, frames: [1, 0, 2, 0].map((i) => ({ key, frame: d * 3 + i })), frameRate: 9, repeat: -1 });
  });
  const [pc, pg] = mk(64, 64);
  pg.fillStyle = '#3a2f4a'; pg.fillRect(0, 0, 64, 64); pg.imageSmoothingEnabled = false;
  pg.drawImage(c, 4, 0, 16, 16, 0, 0, 64, 64);
  portraits[key] = pc.toDataURL();
}
