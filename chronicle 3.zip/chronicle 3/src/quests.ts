import { state } from './state';

export interface Objective { text: string; done: () => boolean }
export interface Quest { id: string; title: string; objectives: Objective[] }

const seen = (id: string) => () => state.examined.includes(id);
const passed = (id: string) => () => state.passed.includes(id);
const flag = (id: string) => () => !!state.flags[id];

export const QUESTS: Quest[] = [
  { id: 'q1', title: 'Arrive at the Crossroads', objectives: [{ text: 'Speak with Layla the merchant', done: flag('talked_merchant') }] },
  { id: 'q2', title: 'Gather Evidence', objectives: [
    { text: "Examine the merchant's ledger", done: seen('ledger') },
    { text: 'Examine the silver coin', done: seen('coin') },
    { text: "Examine the traveler's letter", done: seen('letter') },
  ] },
  { id: 'q3', title: 'Make Your Argument', objectives: [{ text: "Pass Scribe Omar's evidence challenge", done: passed('c1') }] },
  { id: 'q4', title: 'Follow the Monsoon', objectives: [
    { text: 'Travel to the Indian Ocean port', done: flag('visited_port') },
    { text: 'Speak with Kamau the trader', done: flag('talked_kamau') },
  ] },
  { id: 'q5', title: 'Port Evidence', objectives: [
    { text: "Examine the pilot's notes", done: seen('monsoon') },
    { text: 'Examine the account of the port', done: seen('kilwa') },
    { text: 'Examine the copy of the fleet inscription', done: seen('stele') },
  ] },
  { id: 'q6', title: 'Analyze the Networks', objectives: [
    { text: 'Tag the evidence for Captain Ismail', done: passed('c2') },
    { text: "Pass Harbormaster Yusuf's short-answer exam", done: passed('c3') },
  ] },
  { id: 'q7', title: 'Empires of Gunpowder', objectives: [
    { text: 'Sail to the Imperial Bazaar', done: flag('visited_bazaar') },
    { text: 'Speak with Emre the spice seller', done: flag('talked_emre') },
  ] },
  { id: 'q8', title: 'Imperial Evidence', objectives: [
    { text: 'Examine the registry entry', done: seen('millet') },
    { text: "Examine the envoy's report", done: seen('army') },
    { text: 'Examine the court chronicle', done: seen('mughal') },
  ] },
  { id: 'q9', title: 'Compare the Empires', objectives: [{ text: 'Write a comparison essay (LEQ) for Rahim', done: passed('c5') }] },
  { id: 'q10', title: 'The Great Essay', objectives: [{ text: 'Write a DBQ essay for Selim', done: passed('c4') }] },
];

export const questDone = (q: Quest): boolean => q.objectives.every((o) => o.done());
