import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import { state, saveLocal, setSaveHook, replaceState, hasProgress, type State } from './state';

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;
export const cloudEnabled = !!(url && key);
const sb: SupabaseClient | null = cloudEnabled ? createClient(url!, key!) : null;
let uid: string | null = null;
let timer: number | undefined;
let pending = false;

/** Shows a message in the game (the HUD listens for this event). */
export function notify(msg: string): void {
  window.dispatchEvent(new CustomEvent('chronicle:notice', { detail: msg }));
}

/** Asked when a student signs in on a device that holds guest progress. */
let askKeepGuest: (xp: number) => Promise<boolean> = async () => false;
export function onGuestProgress(fn: (xp: number) => Promise<boolean>): void { askKeepGuest = fn; }

async function push(): Promise<void> {
  pending = false;
  if (!sb || !uid) return;
  const { error } = await sb.from('progress').upsert({ user_id: uid, data: state, updated_at: new Date().toISOString() });
  if (error) notify('Cloud save failed. Your progress is still saved on this device.');
}

function attach(): void {
  setSaveHook(() => { pending = true; window.clearTimeout(timer); timer = window.setTimeout(push, 1500); });
}

// Don't lose the last 1.5 s of progress when the tab is closed or hidden.
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'hidden' && pending) { window.clearTimeout(timer); void push(); }
});

/**
 * Makes the local save belong to this user. Rules:
 * - A save owned by someone else is never merged into this account (shared classroom computers).
 * - If the cloud has a save, it wins, unless this same user has newer local progress.
 * - If the cloud is empty and this device has guest progress, the student chooses.
 */
async function adopt(id: string): Promise<void> {
  if (!sb) return;
  const { data, error } = await sb.from('progress').select('data').eq('user_id', id).maybeSingle();
  if (error) {
    // Can't see the cloud copy, so don't risk overwriting it. Keep playing locally.
    if (state.owner !== id) replaceState(null);
    state.owner = id; saveLocal(); uid = null;
    notify('Could not reach cloud save. Playing on this device for now.');
    return;
  }
  uid = id;
  const remote = data?.data as Partial<State> | undefined;
  if (state.owner && state.owner !== id) replaceState(null);
  if (remote) {
    const localIsNewer = state.owner === id && state.updatedAt > (remote.updatedAt ?? 0);
    if (!localIsNewer) replaceState(remote);
  } else if (state.owner !== id && hasProgress()) {
    if (!(await askKeepGuest(state.xp))) replaceState(null);
  }
  state.owner = id;
  saveLocal(); attach(); await push();
}

export async function restoreSession(): Promise<string | null> {
  if (!sb) {
    // A save made while cloud was configured belongs to a student, not this guest.
    if (state.owner) { replaceState(null); saveLocal(); }
    return null;
  }
  const { data } = await sb.auth.getSession();
  const user = data.session?.user;
  if (!user) {
    if (state.owner) { replaceState(null); saveLocal(); }
    return null;
  }
  if (uid !== user.id) await adopt(user.id);
  return user.email ?? null;
}

/** Returns an error/info message, or null on success. */
export async function signIn(email: string, password: string): Promise<string | null> {
  if (!sb) return 'Cloud save is not configured.';
  const { data, error } = await sb.auth.signInWithPassword({ email, password });
  if (error) return error.message;
  await adopt(data.user.id); return null;
}

export async function signUp(email: string, password: string): Promise<string | null> {
  if (!sb) return 'Cloud save is not configured.';
  const { data, error } = await sb.auth.signUp({ email, password });
  if (error) return error.message;
  if (!data.session) return 'Account created. Check your email to confirm it, then sign in.';
  await adopt(data.user!.id); return null;
}

/** Saves, signs out, and clears this device so the next student starts clean. */
export async function signOut(): Promise<void> {
  if (!sb) return;
  window.clearTimeout(timer);
  if (uid) await push();
  await sb.auth.signOut();
  uid = null; setSaveHook(null);
  replaceState(null); saveLocal();
}

/** Stores the full text of an essay/SAQ attempt so a teacher can review it. */
export async function submitAttempt(challengeId: string, score: number, max: number, answer: unknown): Promise<void> {
  if (!sb || !uid) return;
  const { error } = await sb.from('submissions').insert({ user_id: uid, challenge_id: challengeId, score, max_score: max, answer });
  if (error) console.warn('submission not stored', error.message);
}

export const signedIn = (): boolean => !!uid;
