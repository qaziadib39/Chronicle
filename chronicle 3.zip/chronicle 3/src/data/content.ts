// All educational content lives here so it can later move to Supabase/JSON.
// NOTE: sources are ILLUSTRATIVE, written for gameplay and modeled on real records
// (see each source's `note`). Replace with real, cited excerpts before graded classroom use.
import { state } from '../state';
import type { Ground, PathSpec, Rect } from '../gfx/art';
import type { Look } from '../gfx/chars';
import type { Source, Challenge } from './types';

export type * from './types';

export interface Npc {
  id: string; name: string; x: number; y: number; look: Look;
  lines: () => string[];
  talkFlag?: string;
  offers?: { challengeId: string; ready: () => boolean };
}
export interface ObjectDef { id: string; label: string; x: number; y: number; sourceId: string; icon: 'scroll' | 'book' | 'coin' }
export interface Exit {
  label: string; x: number; y: number; to: string; spawn: [number, number];
  requires?: () => string | null;
}
export interface PropSpec { t: string; x: number; y: number }
export interface Area {
  id: string; name: string; w: number; h: number; ground: Ground; seed: number;
  paths: PathSpec[]; water?: Rect[]; props: PropSpec[];
  npcs: Npc[]; objects: ObjectDef[]; exits: Exit[]; spawn: [number, number];
  grade: string; mote: number;
}

const has = (...ids: string[]) => ids.every((i) => state.examined.includes(i));
const done = (id: string) => state.passed.includes(id);
const count = (...ids: string[]) => ids.filter((i) => state.examined.includes(i)).length;
const P = (t: string, x: number, y: number): PropSpec => ({ t, x, y });

/** Ranks are earned by milestones, so the top title marks the end of the chapter (not a lucky XP total). */
export const RANKS: { title: string; how: string; earned: () => boolean }[] = [
  { title: 'Curious Visitor', how: 'Begin your journey', earned: () => true },
  { title: 'Apprentice Historian', how: "Pass Scribe Omar's evidence challenge", earned: () => done('c1') },
  { title: 'Source Analyst', how: "Pass Captain Ismail's evidence tagging", earned: () => done('c2') },
  { title: 'Trade Route Scholar', how: "Pass Harbormaster Yusuf's short-answer exam", earned: () => done('c3') },
  { title: 'Empire Analyst', how: "Pass Rahim's comparison essay (LEQ)", earned: () => done('c5') },
  { title: 'Master Historian', how: "Pass Selim's Great Essay (DBQ)", earned: () => done('c4') },
];
export const rankIndex = (): number => RANKS.reduce((best, r, i) => (r.earned() ? i : best), 0);
export const rankTitle = (): string => RANKS[rankIndex()].title;

export const SOURCES: Record<string, Source> = {
  ledger: { id: 'ledger', title: "Merchant's Ledger (illustrative)", author: 'An unnamed Persian merchant', date: 'c. 1294', place: 'Tabriz', kind: 'Commercial record',
    text: "Received: 40 bolts silk from the east, 12 chests porcelain, pepper by the sack. Paid: tolls at three posts, each recorded with a Mongol stamp. This autumn the khan's officers ordered paper notes in place of silver, and the bazaar shut its doors. Within two months we were trading in silver again.",
    pov: 'A trader recording business for himself; interested in profit and safe passage, not in praising rulers.',
    note: "In 1294 the Ilkhanate (the Mongol state ruling Persia) tried to introduce paper money modeled on Yuan China's. Merchants refused it, trade in Tabriz stalled, and the notes were withdrawn within about two months.",
    facts: ['silk', 'porcelain', 'pepper', 'toll*', 'stamp*', 'post*', 'paper', 'note*', 'silver', 'shut', 'closed', 'refus*', 'bazaar'],
    who: ['merchant', 'trader', 'persian', 'private', 'business', 'ledger', 'his own'],
    sourcing: "Because the ledger is a private business record kept for the merchant's own use, it has little reason to flatter the khan. That makes its notes on tolls and the failed paper money more believable as evidence of how state policy actually affected trade." },
  coin: { id: 'coin', title: 'Silver Coin (illustrative)', author: 'Mint of a Mongol successor state', date: 'c. 1300', place: 'Central Asia', kind: 'Material artifact',
    text: 'The coin is inscribed in more than one script. One side names the ruling khan; the other carries a short religious phrase. Wear on the edges suggests it passed through many hands.',
    pov: 'Issued by a state to project authority and be accepted by diverse merchants.',
    note: 'Ilkhanid and Golden Horde coins often carried Arabic script alongside Mongol (Uyghur-script) legends.',
    facts: ['script*', 'khan', 'religious', 'phrase', 'wear*', 'worn', 'hands', 'inscri*'], who: ['state', 'mint', 'government', 'khan'],
    sourcing: 'Because a government mint designed the coin to be accepted by many peoples, it shows how rulers wanted to appear, not how ordinary people saw them.' },
  letter: { id: 'letter', title: "Traveler's Letter (illustrative)", author: 'A European traveler', date: 'c. 1280', place: 'Overland route to the east', kind: 'Personal letter',
    text: "The roads are safer than any I knew at home. Travelers carrying the khan's tablet of passage receive lodging and fresh horses. Yet I saw villages emptied by war and heavy tribute.",
    pov: 'An outsider impressed by order but aware of its costs; may exaggerate for a home audience.',
    note: "The \"tablet of passage\" is the paiza, a metal pass that entitled holders to the Mongol relay-station (yam) system.",
    facts: ['road*', 'safe*', 'tablet', 'passage', 'lodging', 'horse*', 'village*', 'war', 'tribute'], who: ['european', 'traveler', 'outsider', 'foreigner'],
    sourcing: 'Writing for readers at home, the traveler may exaggerate how safe and orderly the roads were to make his story impressive.' },
  monsoon: { id: 'monsoon', title: "Pilot's Notes (illustrative)", author: 'An Indian Ocean ship pilot', date: 'c. 1450', place: 'Arabian Sea', kind: 'Navigation record',
    text: 'We sail south and west when the winter winds blow, and wait in port until the summer winds turn and carry us home. A pilot who ignores the seasons loses his ship and his cargo.',
    pov: 'A practical expert writing for other sailors; focused on seasons and safety, not politics.',
    note: 'Arab and Indian pilots wrote real navigation manuals like this; the most famous is by Ahmad ibn Majid (late 1400s).',
    facts: ['wind*', 'season*', 'winter', 'summer', 'wait*', 'monsoon*', 'south', 'west', 'home', 'lose*', 'lost', 'cargo'],
    who: ['pilot', 'sailor*', 'navigator', 'expert', 'seaman'],
    sourcing: 'The pilot was writing practical advice for other sailors, so his purpose was safety rather than politics. That makes him reliable about the winds, and it also explains why he never mentions rulers at all.' },
  kilwa: { id: 'kilwa', title: 'Account of a Coastal Port (illustrative)', author: 'A visiting scholar', date: 'c. 1330', place: 'East African coast', kind: 'Travel account',
    text: "Merchants of many lands crowd the harbor. Gold and ivory leave for the north; cloth and porcelain arrive. The sultan's officials weigh each cargo and take their share. Houses are of stone, and the people speak a tongue that mixes local and Arabic words.",
    pov: 'An educated outsider impressed by wealth; likely describes elite districts more than ordinary life.',
    note: "Modeled on Ibn Battuta's description of Kilwa, which he visited in 1331. The mixed language is Swahili.",
    facts: ['harbor', 'gold', 'ivory', 'cloth', 'porcelain', 'sultan*', 'official*', 'weigh*', 'share', 'stone', 'tongue', 'language*', 'arabic', 'many lands', 'mix*'],
    who: ['scholar', 'outsider', 'visitor', 'traveler', 'educated', 'foreigner'],
    sourcing: 'As an educated outsider visiting a wealthy port, the scholar probably saw mostly the elite harbor district, so his account may overstate how prosperous and cosmopolitan life was for ordinary people.' },
  stele: { id: 'stele', title: 'Fleet Inscription (illustrative)', author: 'Officials of a Chinese emperor', date: 'c. 1431', place: 'Southern China', kind: 'Official inscription',
    text: 'Our great ships sailed to the western oceans carrying silks and gifts. Foreign envoys returned with us to pay respect to the emperor, and distant kings sent tribute.',
    pov: 'Written by the state to celebrate the emperor; stresses prestige and tribute over commerce.',
    note: "Based on the inscriptions Admiral Zheng He's officers set up in 1431 at Liujiagang and Changle. The Ming court ended the voyages in 1433.",
    facts: ['ship*', 'fleet*', 'silk*', 'gift*', 'envoy*', 'tribute', 'emperor', 'western ocean*', 'respect', 'king*'],
    who: ['official*', 'emperor', 'government', 'state', 'chinese', 'ming', 'imperial', 'court'],
    sourcing: 'The inscription was written by imperial officials to glorify the emperor, so it presents foreign contact as tribute and respect. Its purpose makes it useful for showing how the Ming state saw itself, but less reliable about what trade actually happened.' },
  millet: { id: 'millet', title: 'Provincial Registry Entry (illustrative)', author: 'An Ottoman clerk', date: 'c. 1550', place: 'Istanbul', kind: 'Government record',
    text: 'The Greek, Armenian and Jewish communities of this quarter keep their own courts and schools. In return each household pays the special tax to the treasury, and the elders answer to the governor for peace in their streets.',
    pov: 'A bureaucrat recording how the state organizes and taxes communities; focused on order and revenue.',
    note: 'The "special tax" is the jizya, paid by non-Muslim subjects. Historians debate how formal the "millet system" was before the 1800s.',
    facts: ['greek', 'armenian', 'jewish', 'court*', 'school*', 'tax*', 'jizya', 'household*', 'elder*', 'governor', 'communit*', 'treasury'],
    who: ['clerk', 'bureaucrat', 'official', 'government', 'ottoman', 'state', 'administrator'],
    sourcing: 'A government clerk recorded this to keep track of taxes and order, so the entry shows how the Ottoman state wanted communities to be organized, not how members of those communities felt about it.' },
  army: { id: 'army', title: "Ambassador's Report (illustrative)", author: 'A Venetian envoy', date: 'c. 1560', place: 'Istanbul', kind: 'Diplomatic report',
    text: "The sultan's soldiers are paid from the treasury and trained as a standing force. His cannon break walls that stood for centuries, and no neighboring prince can match the size of his army.",
    pov: "A rival state's diplomat writing to alert his government; may stress Ottoman strength to win support or funds.",
    note: 'Venetian ambassadors read formal reports (relazioni) to the Senate when they returned home. They are valuable but written for a rival government.',
    facts: ['soldier*', 'paid', 'treasury', 'standing', 'trained', 'cannon*', 'wall*', 'army', 'prince*', 'size'],
    who: ['venetian', 'envoy', 'ambassador', 'diplomat', 'rival', 'venice', 'foreign'],
    sourcing: 'The Venetian envoy was writing to his own government about a dangerous rival, so he may have exaggerated Ottoman strength to win attention or funding. His report should be weighed against Ottoman sources.' },
  mughal: { id: 'mughal', title: 'Court Chronicle (illustrative)', author: 'A Mughal court historian', date: 'c. 1590', place: 'Lahore', kind: 'Official chronicle',
    text: 'The emperor appoints officials by merit, whatever their faith, and assigns each a share of land revenue in return for military service. Scholars of many religions once debated in the House of Worship he built at Fatehpur Sikri.',
    pov: 'Written to glorify the emperor; likely idealizes his tolerance and administration.',
    note: "Modeled on the Akbarnama by Abu'l-Fazl. Akbar's court was based at Lahore from 1585 to 1598; the religious debates took place at Fatehpur Sikri in the late 1570s.",
    facts: ['merit', 'faith*', 'official*', 'land revenue', 'revenue', 'military service', 'service', 'scholar*', 'religion*', 'debat*', 'house of worship', 'fatehpur*'],
    who: ['court', 'historian', 'chronicler', 'emperor', 'mughal', 'official', 'royal'],
    sourcing: "A court historian wrote this chronicle to praise the emperor, so it likely idealizes his tolerance and fair administration. That purpose makes it strong evidence of the image Akbar wanted to project, but weaker evidence of how policy worked in practice." },
};

export const CHALLENGES: Record<string, Challenge> = {
  c1: { kind: 'mc', id: 'c1', title: 'Evidence Challenge', xp: 50, sourceIds: ['ledger', 'coin', 'letter'],
    prompt: 'Using all three sources, which claim about the late-13th-century Mongol world is BEST supported?',
    options: [
      'Mongol rule isolated Eurasian regions and halted long-distance trade.',
      'Mongol political unity and protected routes helped long-distance trade and exchange flourish, though Mongol power over trade had limits.',
      'Trade increased only because Europeans conquered Central Asia.',
      'Mongol rulers had complete control over how merchants did business.',
    ],
    correct: 1,
    feedback: [
      'Not quite. The ledger shows goods moving and tolls paid, and the letter describes safe roads, which contradicts isolation.',
      'Correct! The ledger (stamps, tolls, goods), coin (multilingual, widely accepted) and letter (safe roads, passage tablets) all point to state-supported trade. But the ledger also shows merchants rejecting the khan\'s paper money, and the letter mentions war and tribute: good historians notice limits and costs.',
      'Not quite. None of the sources mention European conquest; they describe Mongol-issued stamps, coins, and passes.',
      "Not quite. Look again at the ledger: when officials forced paper notes on the bazaar, merchants shut their shops and the policy was dropped.",
    ] },
  c2: { kind: 'tag', id: 'c2', title: 'Evidence Tagging', xp: 60, sourceIds: ['monsoon', 'kilwa', 'stele'],
    prompt: 'Claim: "Indian Ocean trade was carried on entirely by private merchants, with no involvement from rulers." Tag each source: does it support the claim, contradict it, or not bear on it?',
    answers: ['N', 'C', 'C'],
    feedback: [
      'The notes are about winds and seasons. They do not mention rulers either way, so they neither support nor contradict the claim. Silence is not evidence.',
      "This contradicts the claim: the sultan's officials weigh cargoes and take a share, so rulers were involved.",
      'This contradicts the claim: the state sent fleets and received tribute. Note its point of view, since it emphasizes prestige.',
    ],
    hints: [
      'Does the pilot say anything at all about who governs ports or the sea? If a source is silent on a topic, can it support or contradict a claim about it?',
      'Reread who weighs each cargo in the port account, and who takes a share.',
      'Who sent the great ships, and who received the envoys and tribute?',
    ] },
  c3: { kind: 'saq', id: 'c3', title: 'Short-Answer Exam', xp: 60, passMark: 2, sourceIds: ['monsoon', 'kilwa', 'stele'],
    prompt: 'Answer each part in one or two complete sentences, using the sources. Watch the task verb: identify, describe, or explain.',
    parts: [
      [
        { q: "A) Identify ONE way the monsoon winds shaped Indian Ocean trade, according to the pilot's notes.", verb: 'identify',
          concepts: ['season*', 'schedule*', 'timing', 'time of year', 'predictab*', 'revers*', 'direction*', 'wait*', 'winter', 'summer', 'turn*', 'calendar'],
          model: 'The winds reversed direction with the seasons, so ships sailed out in winter and had to wait in port for the summer winds to return.' },
        { q: "A) Describe ONE way sailors adapted to the natural environment of the Indian Ocean, according to the pilot's notes.", verb: 'describe',
          concepts: ['season*', 'schedule*', 'timing', 'time of year', 'predictab*', 'revers*', 'direction*', 'wait*', 'winter', 'summer', 'turn*', 'plan*', 'calendar'],
          model: 'Sailors planned their voyages around the seasonal monsoon winds, sailing out with the winter winds and waiting in port until the summer winds could carry them home.' },
      ],
      [
        { q: 'B) Identify ONE example of cultural blending in the account of the coastal port.', verb: 'identify',
          concepts: ['language*', 'tongue', 'arabic', 'swahili', 'mix*', 'blend*', 'words', 'speak', 'spoke'],
          model: "The port's people spoke a language that mixed local and Arabic words (Swahili)." },
        { q: 'B) Describe ONE way the account of the coastal port shows contact between peoples from different regions.', verb: 'describe',
          concepts: ['language*', 'tongue', 'arabic', 'swahili', 'mix*', 'blend*', 'many lands', 'merchants', 'gold', 'ivory', 'cloth', 'porcelain', 'harbor'],
          model: 'Merchants from many lands crowded the harbor, trading African gold and ivory for imported cloth and porcelain, and the local language mixed in Arabic words.' },
      ],
      [
        { q: 'C) Explain ONE way rulers took part in Indian Ocean OR Silk Road trade.', verb: 'explain',
          concepts: ['tax*', 'toll*', 'tribute', 'fleet*', 'sultan*', 'official*', 'stamp*', 'tablet', 'passage', 'protect*', 'envoy*', 'weigh*', 'share', 'ship*', 'paper', 'money'],
          model: "The sultan's officials weighed each cargo and took a share, so rulers profited from trade and had a reason to keep their ports open and safe." },
        { q: 'C) Explain ONE reason the fleet inscription presents foreign visits as tribute rather than trade.', verb: 'explain',
          concepts: ['prestige', 'power*', 'glor*', 'legitima*', 'superior*', 'status', 'respect*', 'image', 'impress*', 'propaganda', 'celebrat*', 'praise*', 'strong', 'great*'],
          model: "Imperial officials wrote it to glorify the emperor, so calling foreign visits \"tribute\" made China look superior and strengthened the emperor's prestige at home." },
      ],
    ] },
  c5: { kind: 'leq', id: 'c5', title: 'The Comparison Essay (LEQ)', xp: 50, passMark: 3, sourceIds: [],
    prompt: 'Develop an argument that compares the methods the Ottoman and Mughal empires used to legitimize and consolidate their power from 1450 to 1750.',
    subjects: {
      a: { label: 'Ottoman', aliases: ['ottoman*', 'turk*', 'istanbul', 'suleiman', 'süleyman', 'mehmed', 'sultans', 'janissar*', 'devshirme'] },
      b: { label: 'Mughal', aliases: ['mughal*', 'akbar', 'babur', 'aurangzeb', 'shah jahan', 'jahangir', 'mansab*'] },
    },
    context: {
      specific: ['gunpowder', 'cannon*', 'firearm*', 'musket*', 'mongol*', 'timur*', 'tamerlane', 'byzantine', 'constantinople', '1453', 'panipat', '1526', 'delhi sultanate', 'abbasid', 'caliph*', 'safavid*', 'central asia*', 'turkic', 'steppe', 'islam*', 'persia*', 'chinggis', 'genghis', 'portug*'],
      general: ['empire*', 'expan*', 'conquer*', 'conquest*', 'trade', 'century', 'centuries', '1400s', '1500s', 'land-based', 'muslim*', 'dynast*', 'rival*'],
      model: 'Both empires grew out of the Turkic and Mongol traditions of Central Asia and rose as the Mongol successor states declined. By the 1400s and 1500s, gunpowder weapons let land-based empires conquer and hold huge territories, as in the Ottoman capture of Constantinople in 1453 and Babur\'s victory at Panipat in 1526.',
    },
    evidence: [
      { label: 'Devshirme', empire: 'a', aliases: ['devshirme', 'devsirme', 'boy levy', 'blood tax'], note: 'The Ottoman practice of taking Christian boys from the Balkans, converting them, and training them as soldiers and officials loyal only to the sultan.' },
      { label: 'Janissaries', empire: 'a', aliases: ['janissar*', 'yeniçeri'], note: 'Elite Ottoman infantry, trained with firearms and paid from the treasury.' },
      { label: 'Millet communities', empire: 'a', aliases: ['millet*'], note: 'Non-Muslim communities managed many of their own affairs under their religious leaders in exchange for taxes and loyalty.' },
      { label: "Süleyman's law codes (kanun)", empire: 'a', aliases: ['kanun*', 'qanun*', 'lawgiver', 'law code*', 'legal code*'], note: 'Süleyman (r. 1520 to 1566), "the Lawgiver," issued imperial law codes alongside Islamic law.' },
      { label: 'Conversion of the Hagia Sophia', empire: 'a', aliases: ['hagia sophia', 'ayasofya', 'aya sofya'], note: 'Mehmed II turned the great Byzantine church into a mosque after taking Constantinople in 1453.' },
      { label: 'Süleymaniye Mosque', empire: 'a', aliases: ['suleymaniye', 'süleymaniye', 'sinan'], note: 'Monumental mosque built for Süleyman by the architect Sinan.' },
      { label: 'Topkapı Palace', empire: 'a', aliases: ['topkapi', 'topkapı'], note: 'The sultan\'s palace and center of government in Istanbul.' },
      { label: 'Capture of Constantinople (1453)', empire: 'a', aliases: ['constantinople', '1453', 'mehmed ii', 'mehmed the conqueror'], note: 'Mehmed II\'s conquest gave the Ottomans an imperial capital and prestige as heirs of Rome.' },
      { label: 'Claim to the caliphate / protector of Mecca and Medina', empire: 'a', aliases: ['caliph*', 'mecca', 'medina', 'holy cities', '1517'], note: 'After conquering Egypt in 1517, Ottoman sultans presented themselves as protectors of the holy cities and leaders of Sunni Islam.' },
      { label: 'Timar land grants', empire: 'a', aliases: ['timar*'], note: 'Cavalrymen received the revenue of land in exchange for military service.' },
      { label: 'Tax farming', empire: 'a', aliases: ['tax farm*', 'iltizam'], note: 'The Ottoman state sold the right to collect taxes to private bidders.' },
      { label: 'Mansabdari system', empire: 'b', aliases: ['mansab*'], note: 'Akbar ranked officials (mansabdars) by the troops they kept; ranks were not hereditary, which kept nobles dependent on the emperor.' },
      { label: 'Zamindars', empire: 'b', aliases: ['zamindar*'], note: 'Local landholders who collected land revenue for the Mughal state.' },
      { label: 'Taj Mahal', empire: 'b', aliases: ['taj mahal'], note: 'Shah Jahan\'s monumental tomb, a display of Mughal wealth and power.' },
      { label: 'Fatehpur Sikri', empire: 'b', aliases: ['fatehpur*'], note: 'Akbar\'s planned capital, home of his House of Worship debates.' },
      { label: 'Red Fort', empire: 'b', aliases: ['red fort'], note: 'Shah Jahan\'s palace-fortress in Delhi.' },
      { label: 'Din-i Ilahi / sulh-i kul', empire: 'b', aliases: ['din-i ilahi', 'din i ilahi', 'divine faith', 'sulh*', 'universal peace', 'universal tolerance'], note: 'Akbar\'s policy of universal peace among religions and his court circle built around loyalty to the emperor.' },
      { label: 'House of Worship (Ibadat Khana)', empire: 'b', aliases: ['ibadat khana', 'ibadat-khana', 'house of worship'], note: 'Akbar hosted debates among Muslim, Hindu, Jain, Zoroastrian and Christian scholars.' },
      { label: 'Alliances and marriages with Rajput princes', empire: 'b', aliases: ['rajput*', 'marriage alliance*', 'married hindu*', 'hindu wives', 'hindu princess*'], note: 'Akbar brought Hindu Rajput rulers into the nobility through marriage and high rank.' },
      { label: "Aurangzeb's religious policies", empire: 'b', aliases: ['aurangzeb'], note: 'Aurangzeb (r. 1658 to 1707) reimposed the jizya in 1679 and favored stricter Sunni rule, which cost the empire Hindu support.' },
      { label: 'Akbarnama', empire: 'b', aliases: ['akbarnama', "abu'l-fazl", 'abul fazl', 'abu al-fazl'], note: 'Official court history glorifying Akbar.' },
      { label: 'Jizya (tax on non-Muslims)', empire: 'both', aliases: ['jizya', 'jizyah', 'jizyah tax', 'tax on non-muslims', 'non-muslim tax'], note: 'Ottomans collected it from non-Muslims; Akbar abolished it in 1564 and Aurangzeb reimposed it in 1679.' },
      { label: 'Gunpowder armies and artillery', empire: 'both', aliases: ['gunpowder', 'cannon*', 'musket*', 'artillery', 'firearm*', 'panipat', 'chaldiran', 'mohacs', 'mohács'], note: 'Both empires used cannon and muskets to conquer and defend territory (e.g. Panipat 1526, Mohács 1526).' },
    ],
    vague: [
      { aliases: ['religion', 'religious tolerance', 'tolerance', 'tolerant', 'religious'], why: 'Name the specific policy, such as the millet communities, the abolition of the jizya, or sulh-i kul.' },
      { aliases: ['army', 'armies', 'military', 'soldiers'], why: 'Name the specific institution, such as the janissaries or the mansabdari system.' },
      { aliases: ['buildings', 'architecture', 'mosque', 'mosques', 'monuments', 'palace'], why: 'Name the building, such as the Süleymaniye Mosque or the Taj Mahal.' },
      { aliases: ['taxes', 'tax', 'bureaucracy', 'officials'], why: 'Name the tax or system, such as the jizya, timar grants, tax farming, or zamindars.' },
    ],
    methods: ['army', 'armies', 'military', 'religio*', 'tolera*', 'bureaucra*', 'tax*', 'law*', 'architect*', 'monument*', 'gunpowder', 'islam*', 'official*', 'administ*', 'allian*', 'conquest*', 'legitim*', 'loyal*', 'propaganda', 'janissar*', 'devshirme', 'mansab*', 'jizya'],
    models: {
      thesis: "Both the Ottoman and Mughal empires consolidated power through gunpowder armies and officials who depended on the ruler, but they legitimized rule differently: Ottoman sultans stressed their role as defenders of Sunni Islam, while Akbar's Mughal state won over a mostly Hindu population through religious tolerance and alliances with Rajput elites.",
      evidence: 'The Ottoman devshirme took Christian boys, converted them, and trained them as janissaries and officials loyal only to the sultan, which helped the sultans consolidate power without relying on the old nobility.',
      similarity: 'Both empires relied on officials whose positions depended on the ruler, such as the Ottoman devshirme-trained officials and the Mughal mansabdars, whose ranks were not hereditary, because rulers of huge and diverse lands needed administrators who could not build independent power bases.',
      difference: "While Ottoman sultans presented themselves as defenders of Sunni Islam and protectors of the holy cities, Akbar promoted sulh-i kul and abolished the jizya, because the Mughals ruled a largely Hindu population whose cooperation they needed.",
    } },
  c4: { kind: 'dbq', id: 'c4', title: 'The Great Essay (DBQ)', xp: 60, passMark: 4, sourceIds: ['ledger', 'monsoon', 'kilwa', 'stele', 'millet', 'army', 'mughal'],
    prompt: 'Evaluate the extent to which rulers and states shaped long-distance trade and cultural exchange in Afro-Eurasia, c. 1200 to 1600.',
    stances: ['To a great extent', 'To a moderate extent', 'To a limited extent'],
    reasons: [
      { id: 'protect', side: 'for', text: 'rulers protected trade routes and taxed or regulated merchants', docs: ['ledger', 'kilwa'] },
      { id: 'fleet', side: 'for', text: 'rulers sponsored fleets and demanded tribute from foreign powers', docs: ['stele'] },
      { id: 'army', side: 'for', text: 'empires used armies and gunpowder weapons to build large states that controlled trade cities', docs: ['army', 'mughal'] },
      { id: 'tolerance', side: 'for', text: 'rulers managed diverse peoples through tolerance and local autonomy, which kept exchange flowing', docs: ['millet', 'mughal'] },
      { id: 'nature', side: 'against', text: 'monsoon winds and geography set the rhythm of trade more than any ruler did', docs: ['monsoon'] },
      { id: 'merchants', side: 'against', text: 'merchants and ordinary people drove exchange, sometimes in spite of rulers', docs: ['ledger', 'kilwa'] },
    ],
    context: {
      specific: ['mongol*', 'khan*', 'pax mongolica', 'silk road*', 'dar al-islam', 'abbasid*', 'caliphate', 'song', 'yuan', 'ming', 'black death', 'plague', 'crusade*', 'indian ocean', 'caravan*', 'gunpowder', 'ottoman*', 'safavid*', 'mughal*', 'delhi sultanate', 'mali', 'swahili', 'constantinople', 'byzantine', 'compass', 'astrolabe', 'bills of exchange', 'paper money', 'islam*', 'muslim*', 'sufi*'],
      general: ['empire*', 'trade', 'network*', 'merchant*', 'century', 'centuries', '1200', '1300s', '1400s', '1500s', 'expan*', 'conquest*', 'religio*'],
      model: 'Before 1200, the Abbasid Caliphate and Song China had already built large trade networks linked by Muslim merchants and the Silk Roads. After 1200, the Mongol conquests united much of Eurasia under one set of rulers, while the Indian Ocean network kept growing along the monsoon routes. Later, new gunpowder empires such as the Ottomans and Mughals took control of key trade cities.',
    },
    outside: [
      { label: 'Pax Mongolica', aliases: ['pax mongolica'], note: 'The period of relative peace and protected travel across Mongol-ruled Eurasia in the 1200s and 1300s.' },
      { label: 'Kublai Khan / Yuan dynasty', aliases: ['kublai*', 'khubilai', 'yuan'], note: 'Mongol rule of China (1271 to 1368), which issued paper money and welcomed foreign merchants.' },
      { label: 'Genghis Khan', aliases: ['genghis', 'chinggis', 'temujin', 'temüjin'], note: 'Founder of the Mongol Empire.' },
      { label: 'Mansa Musa', aliases: ['mansa musa'], note: 'Ruler of Mali whose 1324 pilgrimage to Mecca showed West African gold wealth to the Islamic world.' },
      { label: 'Ibn Battuta', aliases: ['ibn battuta', 'ibn batuta', 'ibn battutah'], note: 'Moroccan scholar who traveled across Dar al-Islam in the 1300s, often serving local rulers as a judge.' },
      { label: 'Marco Polo', aliases: ['marco polo'], note: 'Venetian merchant who served at the court of Kublai Khan.' },
      { label: 'Black Death', aliases: ['black death', 'bubonic plague', 'plague'], note: 'Pandemic of the 1340s that spread along Mongol-era trade routes.' },
      { label: 'Sultanate of Malacca', aliases: ['malacca', 'melaka'], note: 'Port state whose rulers controlled the strait linking the Indian Ocean and South China Sea.' },
      { label: 'Portuguese in the Indian Ocean', aliases: ['portug*', 'vasco da gama', 'da gama', 'albuquerque', 'cartaz*'], note: 'From 1498 the Portuguese used armed ships and the cartaz pass system to force their way into Indian Ocean trade.' },
      { label: 'Ottoman conquest of Constantinople', aliases: ['constantinople', '1453', 'mehmed*'], note: 'In 1453 the Ottomans took control of a key crossroads of Mediterranean and Black Sea trade.' },
      { label: 'Devshirme / janissaries', aliases: ['devshirme', 'janissar*'], note: 'The Ottoman system that trained Christian-born boys as soldiers loyal to the sultan.' },
      { label: 'Süleyman the Magnificent', aliases: ['suleiman', 'süleyman', 'suleyman', 'kanun*'], note: 'Ottoman sultan (1520 to 1566) whose conquests and law codes extended state control over trade cities.' },
      { label: 'Great Zimbabwe', aliases: ['great zimbabwe', 'zimbabwe'], note: 'The inland state that supplied the gold traded through Swahili ports.' },
      { label: 'Mali and Timbuktu', aliases: ['mali', 'timbuktu', 'trans-saharan', 'trans saharan', 'sahara*'], note: 'Rulers of Mali taxed trans-Saharan gold and salt trade and sponsored Islamic scholarship in Timbuktu.' },
      { label: 'Mamluk Sultanate', aliases: ['mamluk*', 'karimi'], note: 'The Mamluks of Egypt controlled and taxed the Red Sea spice trade.' },
      { label: 'Safavid Empire', aliases: ['safavid*', 'shah abbas'], note: 'Persian empire whose rulers promoted the silk trade from Isfahan.' },
      { label: 'Delhi Sultanate', aliases: ['delhi sultanate'], note: 'Muslim rulers of northern India from 1206 who taxed trade and agriculture.' },
      { label: 'Champa rice / Song commerce', aliases: ['champa', 'song dynasty'], note: 'Song China\'s commercial economy grew before and alongside the Mongols.' },
    ],
    notOutside: [
      { aliases: ['zheng he', 'treasure fleet*', 'treasure ship*'], why: "Zheng He's voyages are the subject of Doc 4, so a reader would count this as document evidence, not outside evidence." },
      { aliases: ['swahili'], why: 'The mixed Swahili language is already described in Doc 3. Choose something the documents do not mention.' },
      { aliases: ['akbar', 'fatehpur*'], why: "Doc 7 already describes Akbar's court and policies. Choose evidence from beyond the documents." },
      { aliases: ['jizya', 'millet*'], why: "Doc 5 already describes the special tax and community courts. Choose evidence from beyond the documents." },
    ],
    models: {
      thesis: 'To a great extent, rulers and states shaped long-distance trade and exchange from 1200 to 1600, because they protected and taxed trade routes, and because empires used armies and gunpowder to control the cities where merchants met.',
      outside: 'The Pax Mongolica shows rulers shaping trade: after the Mongol conquests, protected roads and relay stations let merchants and missionaries cross Eurasia, which supports the argument that political unity made exchange easier.',
      complexity: 'However, Doc 2 complicates this argument, because the pilot plans every voyage around the monsoon winds and never mentions rulers. This suggests that even powerful states could not change when or how ships sailed, so geography limited how much rulers controlled trade.',
    } },
};

export const CHALLENGE_ORDER = ['c1', 'c2', 'c3', 'c5', 'c4'];

export const AREAS: Record<string, Area> = {
  crossroads: {
    id: 'crossroads', name: 'Silk Road Crossroads (c. 1290)', w: 1280, h: 800, ground: 'grass', seed: 1, spawn: [600, 500],
    grade: '#ffe6c4', mote: 0xffe9a8,
    paths: [[0, 368, 1280, 64, 'dirt'], [608, 0, 64, 800, 'dirt'], [544, 304, 192, 192, 'cobble']],
    props: [
      P('well', 640, 420), P('house_mud', 230, 290), P('house_dome', 1030, 290), P('house_mud', 260, 700),
      P('tent_a', 470, 650), P('tent_b', 1040, 670), P('stall_red', 430, 350), P('stall_blue', 830, 350), P('stall_red', 880, 560),
      P('camel_a', 350, 530), P('camel_b', 405, 552), P('barrel', 780, 352), P('crates', 806, 354),
      P('oak', 90, 130), P('oak', 130, 430), P('oak', 90, 720), P('oak', 1190, 140), P('oak', 1220, 500), P('oak', 1190, 740),
      P('oak', 430, 130), P('oak', 850, 130), P('oak', 540, 140), P('oak', 740, 140), P('cypress', 360, 170),
      P('bush', 150, 560), P('bush', 1150, 580), P('bush', 520, 740), P('bush', 760, 720),
      P('rock', 200, 530), P('rock', 980, 470), P('rock', 330, 730), P('rock', 1000, 160),
      P('lantern', 530, 450), P('lantern', 750, 360), P('banner_red', 520, 310), P('banner_blue', 760, 510),
    ],
    exits: [{ label: 'the Coast Road to the Indian Ocean port', x: 1240, y: 400, to: 'port', spawn: [90, 400],
      requires: () => (done('c1') ? null : 'The road east opens once you have made your argument to Omar.') }],
    npcs: [
      { id: 'merchant', name: 'Layla, Merchant', x: 480, y: 440, talkFlag: 'talked_merchant',
        look: { skin: '#c58b5b', hair: '#2b1a12', robe: '#d9822b', trim: '#fff1c9', hat: 'scarf', hatColor: '#7a2f8a' },
        lines: () => state.flags.talked_merchant
          ? ["Look around the crossroads: my ledger, a coin, and a traveler's letter will tell you more than I can.", 'When you have studied them, show the scribe what you have learned.']
          : ['Welcome to the crossroads, traveler! Caravans from China, Persia and Europe meet here.', "Historians argue about why trade flourished in this era. Do not take anyone's word for it: examine the evidence.", 'Check my ledger, the coin by the well, and the letter on the table.'] },
      { id: 'scribe', name: 'Omar, Scribe', x: 900, y: 310,
        look: { skin: '#b57b4e', hair: '#1d1420', robe: '#3b5bc4', trim: '#e8c46a', hat: 'turban', hatColor: '#f3e9cf', beard: true },
        offers: { challengeId: 'c1', ready: () => has('ledger', 'coin', 'letter') },
        lines: () => {
          if (done('c1')) return ['Excellent reasoning! Always corroborate sources and consider point of view.', 'The coast road to the east is open to you. Follow the monsoon trade!'];
          if (!has('ledger', 'coin', 'letter')) return ['I cannot judge an argument built on too little evidence.', `You have studied ${count('ledger', 'coin', 'letter')}/3 sources. Come back when you have seen them all.`];
          return ['You have studied the sources. Now: what do they tell us together? Choose carefully; a historian who guesses earns less.'];
        } },
    ],
    objects: [
      { id: 'o_ledger', label: "Merchant's ledger", x: 330, y: 470, sourceId: 'ledger', icon: 'book' },
      { id: 'o_coin', label: 'Silver coin', x: 700, y: 470, sourceId: 'coin', icon: 'coin' },
      { id: 'o_letter', label: "Traveler's letter", x: 1100, y: 480, sourceId: 'letter', icon: 'scroll' },
    ],
  },
  port: {
    id: 'port', name: 'Indian Ocean Port (c. 1450)', w: 1280, h: 800, ground: 'sand', seed: 2, spawn: [90, 400],
    grade: '#d8f0f2', mote: 0xfff3c4,
    paths: [[0, 368, 1280, 64, 'dirt'], [608, 0, 64, 592, 'dirt'], [0, 592, 1280, 48, 'plank']],
    water: [[0, 640, 1280, 160]],
    props: [
      P('house_coral', 240, 300), P('house_coral', 450, 290), P('house_coral', 800, 300), P('pavilion', 1040, 300),
      P('stall_blue', 345, 352), P('stall_red', 735, 352),
      P('palm', 90, 240), P('palm', 120, 520), P('palm', 560, 210), P('palm', 740, 210), P('palm', 1190, 250), P('palm', 1210, 530), P('palm', 380, 540), P('palm', 980, 550),
      P('barrel', 200, 622), P('barrel', 226, 624), P('crates', 420, 624), P('sacks', 800, 622), P('barrel', 1100, 622), P('crates', 1130, 624),
      P('dhow', 300, 770), P('dhow', 920, 780),
      P('banner_blue', 580, 360), P('lantern', 700, 460), P('lantern', 540, 470), P('rock', 140, 470), P('rock', 1000, 470), P('bush', 520, 330),
    ],
    exits: [
      { label: 'the road back to the Crossroads', x: 40, y: 400, to: 'crossroads', spawn: [1180, 400] },
      { label: 'the sea road to the Imperial Bazaar', x: 1240, y: 400, to: 'bazaar', spawn: [90, 400],
        requires: () => (done('c3') ? null : "Harbormaster Yusuf's exam must be passed before you can sail to the empires.") },
    ],
    npcs: [
      { id: 'kamau', name: 'Kamau, Trader', x: 210, y: 470, talkFlag: 'talked_kamau',
        look: { skin: '#7a4a30', hair: '#1d1420', robe: '#2f9e5a', trim: '#f5d76e', hat: 'cap', hatColor: '#e8c46a' },
        lines: () => ['Karibu! Welcome. Ships from Arabia, Gujarat, and beyond all call at this harbor.', "The pilot's notes, an account of this port, and a copy of an inscription from China's great fleets are around town.", 'Study them all, then speak with Captain Ismail.'] },
      { id: 'ismail', name: 'Captain Ismail', x: 900, y: 470,
        look: { skin: '#a8703f', hair: '#1d1420', robe: '#1f5fa8', trim: '#e8c46a', hat: 'cap', hatColor: '#f3e9cf', beard: true },
        offers: { challengeId: 'c2', ready: () => has('monsoon', 'kilwa', 'stele') },
        lines: () => {
          if (done('c2')) return ['Well tagged! Seeing what a source does NOT say is as important as what it says.', 'Harbormaster Yusuf has a final exam for you.'];
          if (!has('monsoon', 'kilwa', 'stele')) return ['Salaam! I sail from Cambay in Gujarat with cotton cloth, and return with gold and ivory.', 'Come back when you have studied all three port sources.'];
          return ['Let us test a claim against the evidence. Tag each source carefully: every retry costs you experience.'];
        } },
      { id: 'yusuf', name: 'Yusuf, Harbormaster', x: 1030, y: 540,
        look: { skin: '#a8703f', hair: '#cfcfcf', robe: '#6a4aa8', trim: '#e8c46a', hat: 'turban', hatColor: '#e9e1c8', beard: true },
        offers: { challengeId: 'c3', ready: () => done('c2') },
        lines: () => {
          if (done('c3')) return ['Outstanding! You can now explain how winds, cultures, and rulers shaped these networks.', 'Ships sail east to the Imperial Bazaar. The road is open.'];
          if (!done('c2')) return ['Speak with Captain Ismail first. I only examine those who can tag evidence.'];
          return ['Time for a short-answer exam, as on the AP test. Answer in full sentences, in your own words, and mind the task verb.'];
        } },
    ],
    objects: [
      { id: 'o_monsoon', label: "Pilot's notes", x: 470, y: 520, sourceId: 'monsoon', icon: 'scroll' },
      { id: 'o_kilwa', label: 'Account of the port', x: 780, y: 500, sourceId: 'kilwa', icon: 'book' },
      { id: 'o_stele', label: 'Copy of a fleet inscription', x: 1130, y: 480, sourceId: 'stele', icon: 'scroll' },
    ],
  },
  bazaar: {
    id: 'bazaar', name: 'Imperial Bazaar (c. 1550)', w: 1280, h: 800, ground: 'sand', seed: 3, spawn: [90, 400],
    grade: '#ffd9d0', mote: 0xffd9a0,
    paths: [[0, 368, 1280, 64, 'cobble'], [608, 0, 64, 704, 'cobble'], [512, 272, 256, 256, 'cobble']],
    water: [[0, 704, 1280, 96]],
    props: [
      P('fountain', 640, 420), P('minaret', 200, 240), P('minaret', 1090, 240), P('house_dome', 340, 310), P('house_dome', 960, 310),
      P('house_mud', 110, 660), P('house_mud', 1170, 660), P('stall_red', 450, 350), P('stall_blue', 830, 350), P('stall_blue', 420, 580), P('stall_red', 860, 580),
      P('cannon', 1000, 540), P('cannon', 1070, 552), P('camel_a', 260, 620), P('camel_b', 315, 640),
      P('cypress', 90, 140), P('cypress', 400, 140), P('cypress', 900, 140), P('cypress', 1200, 160), P('cypress', 100, 540), P('cypress', 1200, 560), P('cypress', 540, 650), P('cypress', 760, 660),
      P('banner_red', 520, 300), P('banner_red', 750, 300), P('lantern', 500, 460), P('lantern', 780, 460), P('lantern', 500, 360), P('lantern', 780, 360),
      P('barrel', 560, 600), P('barrel', 584, 602), P('crates', 700, 610), P('dhow', 600, 790),
    ],
    exits: [{ label: 'the sea road back to the port', x: 40, y: 400, to: 'port', spawn: [1180, 400] }],
    npcs: [
      { id: 'emre', name: 'Emre, Spice Seller', x: 210, y: 470, talkFlag: 'talked_emre',
        look: { skin: '#c08a5a', hair: '#2b1a12', robe: '#a83a2e', trim: '#e8c46a', hat: 'fez', hatColor: '#b3302e' },
        lines: () => ['Welcome to the Imperial Bazaar! Gunpowder, bureaucrats, and spice: this city has all three.', "A registry entry, a Venetian envoy's report, and a Mughal chronicle are all about town.", 'Study them. Rahim, the Mughal envoy, wants to test how well you can compare empires. Then Selim, the vizier\'s secretary, awaits with the Great Essay.'] },
      { id: 'marco', name: 'Marco, Venetian Envoy', x: 880, y: 480,
        look: { skin: '#e8bf9a', hair: '#6b4a2a', robe: '#2e5a8a', trim: '#e8c46a', hat: 'cap', hatColor: '#1d3b66' },
        lines: () => ["I write home about the sultan's army. Do read my report, but remember who I am writing to.", 'Every source has a point of view, even honest ones.'] },
      { id: 'rahim', name: 'Rahim, Mughal Envoy', x: 1160, y: 500,
        look: { skin: '#b57b4e', hair: '#1d1420', robe: '#1f7a6a', trim: '#e8c46a', hat: 'turban', hatColor: '#f0d78a', beard: true },
        offers: { challengeId: 'c5', ready: () => has('millet', 'army', 'mughal') },
        lines: () => {
          if (done('c5')) return ['A fine comparison! You saw what our empires shared and where they parted ways.', 'Selim waits by the fountain with the Great Essay.'];
          if (!has('millet', 'army', 'mughal')) return ["My emperor's court chronicle praises his tolerance. A chronicle is written to flatter, my friend.", 'Read the three sources in this bazaar, then come back. I will ask you to compare my empire with the Ottomans.'];
          return ['The long essay asks you to argue from your own knowledge, not from documents.', 'Compare how the Ottomans and we Mughals held power: what was alike, what was different, and why?'];
        } },
      { id: 'selim', name: "Selim, Vizier's Secretary", x: 640, y: 260,
        look: { skin: '#c58b5b', hair: '#2b1a12', robe: '#2a2a4a', trim: '#e8c46a', hat: 'fez', hatColor: '#7a1f2a', beard: true },
        offers: { challengeId: 'c4', ready: () => done('c5') && has('ledger', 'monsoon', 'kilwa', 'stele', 'millet', 'army', 'mughal') },
        lines: () => {
          if (done('c4')) return ['A fine essay! You argued with evidence, sourced it, and acknowledged complexity.', 'You have completed this chapter of Chronicle. More units are coming soon.'];
          if (!done('c5')) return ["Rahim the Mughal envoy has a comparison essay for you first. Show me you can argue without documents, then we will argue with them."];
          if (!has('ledger', 'monsoon', 'kilwa', 'stele', 'millet', 'army', 'mughal')) {
            const n = count('ledger', 'monsoon', 'kilwa', 'stele', 'millet', 'army', 'mughal');
            return ["The Great Essay needs all seven documents from your journey: the ledger, pilot's notes, port account, fleet inscription, registry, envoy report, and chronicle.", `You hold ${n}/7. Check your journal (J) and gather the rest.`];
          }
          return ['You have all seven documents. Build a thesis, context, evidence, sourcing, and complexity: write the Great Essay. Your draft is saved as you go.'];
        } },
    ],
    objects: [
      { id: 'o_millet', label: 'Registry entry', x: 330, y: 480, sourceId: 'millet', icon: 'book' },
      { id: 'o_army', label: "Envoy's report", x: 1030, y: 480, sourceId: 'army', icon: 'scroll' },
      { id: 'o_mughal', label: 'Court chronicle', x: 1130, y: 330, sourceId: 'mughal', icon: 'book' },
    ],
  },
};
