// Shared content types. Kept free of game/DOM imports so scoring can be unit-tested.

export interface Source {
  id: string; title: string; author: string; date: string; place: string;
  kind: string; text: string; pov: string;
  /** Specific content words a student would use when accurately describing this source. */
  facts: string[];
  /** Words that identify the author's position (used when checking point-of-view sourcing). */
  who: string[];
  /** Model sourcing sentence shown after scoring. */
  sourcing: string;
  /** Short historical note shown under the source. */
  note?: string;
}

interface Base { id: string; title: string; prompt: string; sourceIds: string[]; xp: number }

export interface McChallenge extends Base { kind: 'mc'; options: string[]; correct: number; feedback: string[] }

/** S = supports, C = contradicts, N = not relevant. One answer per source, in sourceIds order. */
export interface TagChallenge extends Base {
  kind: 'tag'; answers: ('S' | 'C' | 'N')[];
  /** Full explanation, shown once a row is answered correctly. */
  feedback: string[];
  /** Nudge shown on a wrong row, without giving the answer away. */
  hints: string[];
}

export type Verb = 'identify' | 'describe' | 'explain';
export interface SaqPart { q: string; verb: Verb; concepts: string[]; model: string }
export interface SaqChallenge extends Base {
  kind: 'saq'; passMark: number;
  /** parts[i] holds interchangeable versions of part i; a retry draws the next version. */
  parts: SaqPart[][];
}

export type Side = 'for' | 'against';
export interface DbqReason { id: string; text: string; side: Side; docs: string[] }
export interface BankItem { label: string; aliases: string[]; note: string }
export interface Excluded { aliases: string[]; why: string }
export interface ContextSpec { specific: string[]; general: string[]; model: string }

export interface DbqChallenge extends Base {
  kind: 'dbq'; passMark: number;
  stances: [string, string, string];
  reasons: DbqReason[];
  context: ContextSpec;
  outside: BankItem[];
  /** Things that look like outside evidence but are really the content of a document. */
  notOutside: Excluded[];
  models: { thesis: string; outside: string; complexity: string };
}

export interface LeqEvidence extends BankItem { empire: 'a' | 'b' | 'both' }
export interface LeqChallenge extends Base {
  kind: 'leq'; passMark: number;
  subjects: { a: { label: string; aliases: string[] }; b: { label: string; aliases: string[] } };
  context: ContextSpec;
  evidence: LeqEvidence[];
  /** General words that are not specific enough to count as evidence. */
  vague: Excluded[];
  methods: string[];
  models: { thesis: string; similarity: string; difference: string; evidence: string };
}

export type Challenge = McChallenge | TagChallenge | SaqChallenge | DbqChallenge | LeqChallenge;
