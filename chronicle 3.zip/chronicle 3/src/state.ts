const KEY = 'chronicle-save-v1';

/** One row per challenge in the Progress Report (journal). */
export interface AttemptRecord { attempts: number; best: number; max: number; passed: boolean }

export interface State {
  xp: number;
  flags: Record<string, boolean>;
  examined: string[];
  passed: string[];
  area: string;
  subject: string;
  /** Supabase user id this save belongs to, or null for a guest save. */
  owner: string | null;
  /** ms timestamp of the last local save; used to resolve cloud conflicts. */
  updatedAt: number;
  records: Record<string, AttemptRecord>;
  /** Work-in-progress answers, so leaving an essay never loses it. */
  drafts: Record<string, unknown>;
}

const fresh = (): State => ({
  xp: 0, flags: {}, examined: [], passed: [], area: 'crossroads', subject: 'apwh',
  owner: null, updatedAt: 0, records: {}, drafts: {},
});

/** Repairs saves made by older versions so nobody gets stuck. */
function migrate(s: State): State {
  const seen = (...ids: string[]) => ids.some((i) => s.examined.includes(i));
  // v0.3 never set these flags, which froze the quest tracker after the first area.
  if (s.area === 'port' || s.area === 'bazaar' || seen('monsoon', 'kilwa', 'stele') || s.passed.includes('c2')) s.flags.visited_port = true;
  if (s.area === 'bazaar' || seen('millet', 'army', 'mughal')) s.flags.visited_bazaar = true;
  s.records ??= {}; s.drafts ??= {};
  return s;
}

function parse(data: unknown): State {
  const d = (data && typeof data === 'object' ? data : {}) as Partial<State>;
  return migrate({ ...fresh(), ...d, flags: { ...(d.flags ?? {}) }, records: { ...(d.records ?? {}) }, drafts: { ...(d.drafts ?? {}) } });
}

function load(): State {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return parse(JSON.parse(raw));
  } catch { /* ignore */ }
  return fresh();
}

export const state: State = load();

let saveHook: (() => void) | null = null;
export function setSaveHook(fn: (() => void) | null): void { saveHook = fn; }

/** Writes to this browser only (no cloud push). */
export function saveLocal(): void {
  try { localStorage.setItem(KEY, JSON.stringify(state)); } catch { /* storage full or blocked */ }
}

export function save(): void {
  state.updatedAt = Date.now();
  saveLocal();
  saveHook?.();
}

let soon: number | undefined;
/** Debounced save for things that change on every keystroke (essay drafts). */
export function saveSoon(): void {
  window.clearTimeout(soon);
  soon = window.setTimeout(save, 600);
}

/** Replaces the whole save, e.g. when a different student signs in. */
export function replaceState(data: unknown | null): void {
  const next = data ? parse(data) : fresh();
  for (const k of Object.keys(state)) delete (state as unknown as Record<string, unknown>)[k];
  Object.assign(state, next);
}

export const hasProgress = (s: Pick<State, 'xp' | 'examined'> = state): boolean => s.xp > 0 || s.examined.length > 0;

export function resetProgress(): void {
  const owner = state.owner;
  replaceState(null);
  state.owner = owner;
  save();
}

export function recordAttempt(id: string, score: number, max: number, passed: boolean): AttemptRecord {
  const r = state.records[id] ?? { attempts: 0, best: 0, max, passed: false };
  r.attempts += 1; r.best = Math.max(r.best, score); r.max = max; r.passed ||= passed;
  state.records[id] = r;
  save();
  return r;
}

export const XP_PER_LEVEL = 50;
export const level = (): number => Math.floor(state.xp / XP_PER_LEVEL) + 1;
export function addXp(n: number): void { state.xp += n; save(); }
