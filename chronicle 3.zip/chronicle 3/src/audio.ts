// Tiny synthesized sound effects (no audio files needed).
let ctx: AudioContext | null = null;
let muted = false;

function ac(): AudioContext | null {
  if (!ctx) {
    const A = (window as unknown as { AudioContext?: typeof AudioContext; webkitAudioContext?: typeof AudioContext });
    const C = A.AudioContext ?? A.webkitAudioContext;
    if (C) ctx = new C();
  }
  return ctx;
}

function tone(f: number, at: number, dur: number, type: OscillatorType = 'triangle', vol = 0.07): void {
  const c = ac();
  if (!c || muted) return;
  const o = c.createOscillator(), g = c.createGain();
  o.type = type; o.frequency.value = f;
  const s = c.currentTime + at;
  g.gain.setValueAtTime(0.0001, s);
  g.gain.linearRampToValueAtTime(vol, s + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, s + dur);
  o.connect(g); g.connect(c.destination);
  o.start(s); o.stop(s + dur + 0.05);
}

export const sfx = {
  resume: () => { void ac()?.resume(); },
  click: () => tone(520, 0, 0.06, 'square', 0.025),
  pickup: () => [660, 880, 1320].forEach((f, i) => tone(f, i * 0.07, 0.2)),
  good: () => [523, 659, 784, 1047].forEach((f, i) => tone(f, i * 0.09, 0.28)),
  bad: () => { tone(200, 0, 0.22, 'sawtooth', 0.04); tone(150, 0.12, 0.28, 'sawtooth', 0.04); },
  level: () => [392, 523, 659, 784, 1047].forEach((f, i) => tone(f, i * 0.08, 0.35)),
  travel: () => [330, 262, 196].forEach((f, i) => tone(f, i * 0.1, 0.3)),
  toggleMute: (): boolean => { muted = !muted; return muted; },
};
