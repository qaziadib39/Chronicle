// LEQ scoring against the current College Board rubric (6 points):
//  A Thesis (1)  B Contextualization (1)
//  C Evidence (2: specific relevant examples / at least two examples used to support an argument)
//  D Historical reasoning (1: uses comparison to frame the argument)  Complexity (1)
// This LEQ asks for comparison, so complexity is earned by explaining both a similarity and a difference.
import type { LeqChallenge, LeqEvidence } from '../data/types';
import { CAUSAL, hits, isSentenceLike, LINK, newWords, wordCount } from './text';
import { finish, scoreContext, type Row, type Scorecard } from './rubric';

export type Empire = '' | 'a' | 'b' | 'both';
export interface LeqDraft {
  thesis: string; context: string;
  evidence: { empire: Empire; name: string; explain: string }[];
  similarity: string; difference: string;
}

export const emptyLeqDraft = (): LeqDraft => ({
  thesis: '', context: '', similarity: '', difference: '',
  evidence: [0, 1, 2, 3].map(() => ({ empire: '' as Empire, name: '', explain: '' })),
});

export function normalizeLeqDraft(raw: unknown): LeqDraft {
  const d = { ...emptyLeqDraft(), ...(raw && typeof raw === 'object' ? raw as Partial<LeqDraft> : {}) };
  if (!Array.isArray(d.evidence) || d.evidence.length !== 4) d.evidence = emptyLeqDraft().evidence;
  return d;
}

export const SIMILAR = ['both', 'similar*', 'likewise', 'alike', 'in common', 'same', 'shared', 'each', 'as well as', 'just as', 'also'];
export const DIFFERENT = ['whereas', 'while', 'unlike', 'differ*', 'in contrast', 'however', 'but', 'on the other hand', 'instead', 'rather than', 'contrast*'];

interface Ctx { c: LeqChallenge; d: LeqDraft }
const mentionsA = (c: LeqChallenge, t: string) => hits(t, c.subjects.a.aliases).length > 0;
const mentionsB = (c: LeqChallenge, t: string) => hits(t, c.subjects.b.aliases).length > 0;

function thesisRow({ c, d }: Ctx): Row {
  const notes: string[] = [];
  const t = d.thesis, n = wordCount(t);
  if (n < 15) notes.push(`Write a full-sentence thesis (15+ words); you wrote ${n}.`);
  else {
    if (!mentionsA(c, t) || !mentionsB(c, t)) notes.push(`A comparison thesis must name both empires (${c.subjects.a.label} and ${c.subjects.b.label}).`);
    if (!hits(t, [...SIMILAR, ...DIFFERENT]).length) notes.push('Make a comparative claim: say what was similar, different, or both ("both... but...", "while...").');
    if (!hits(t, c.methods).length) notes.push('Name the methods you will compare (for example armies, religious policy, officials, or law) to set up a line of reasoning.');
    if (newWords(t, c.prompt) < 5) notes.push('This mostly restates the prompt. Add your own claim about how they were alike or different.');
  }
  return { key: 'thesis', label: 'Thesis / claim', got: notes.length ? 0 : 1, max: 1, notes, model: c.models.thesis, step: 0 };
}

export interface EvidenceVerdict { i: number; item?: LeqEvidence; specific: boolean; attributed: boolean; explained: boolean; note: string }

export function evidenceVerdicts({ c, d }: Ctx): EvidenceVerdict[] {
  const out: EvidenceVerdict[] = [];
  d.evidence.forEach((e, i) => {
    if (!e.name.trim() && !e.explain.trim()) return;
    const item = c.evidence.find((x) => hits(e.name, x.aliases).length) ?? c.evidence.find((x) => hits(e.explain, x.aliases).length);
    const vague = c.vague.find((v) => hits(`${e.name} ${e.explain}`, v.aliases).length);
    const specific = !!item;
    const attributed = !!item && !!e.empire && (item.empire === 'both' || item.empire === e.empire);
    const explained = wordCount(e.explain) >= 12 && isSentenceLike(e.explain) && hits(e.explain, [...LINK, ...CAUSAL, 'legitim*', 'consolidat*', 'loyal*', 'control*', 'power', 'authority', 'unif*']).length > 0;
    let note: string;
    if (!specific) note = vague ? `Too general. ${vague.why}` : 'Name a specific, accurate example (a policy, institution, ruler\'s action, or building).';
    else if (!e.empire) note = 'Choose which empire this example belongs to.';
    else if (!attributed) note = `${item!.label} belongs to the ${item!.empire === 'a' ? c.subjects.a.label : c.subjects.b.label} Empire, not the one you chose.`;
    else if (!explained) note = 'Explain how this example helped the empire legitimize or consolidate power (12+ words, with "because", "this helped", "which allowed"...).';
    else note = 'Specific, accurate, and used to support your argument.';
    out.push({ i, item, specific, attributed, explained, note });
  });
  return out;
}

function evidenceRow(x: Ctx, v: EvidenceVerdict[]): Row {
  const { c } = x;
  const distinct = (list: EvidenceVerdict[]) => new Set(list.map((e) => e.item!.label)).size;
  const specific = v.filter((e) => e.specific);
  const good = v.filter((e) => e.specific && e.attributed && e.explained);
  const coversA = good.some((e) => e.item!.empire !== 'b' && (e.item!.empire === 'a' || x.d.evidence[e.i].empire !== 'b'));
  const coversB = good.some((e) => e.item!.empire !== 'a' && (e.item!.empire === 'b' || x.d.evidence[e.i].empire !== 'a'));
  const pt1 = distinct(specific) >= 2;
  const pt2 = distinct(good) >= 2 && coversA && coversB;
  const got = pt2 ? 2 : pt1 ? 1 : 0;
  const notes: string[] = [];
  if (!pt1) notes.push(`1 point: give at least two specific, relevant examples. You have ${distinct(specific)}.`);
  if (!pt2) notes.push(`2 points: use at least two specific examples to support your argument, explained, with evidence about both the ${c.subjects.a.label}s and the ${c.subjects.b.label}s.`);
  for (const e of v) if (!(e.specific && e.attributed && e.explained)) notes.push(`Example ${e.i + 1}: ${e.note}`);
  const model = `${c.models.evidence}\n\nOther strong examples: ${c.evidence.slice(0, 12).map((e) => e.label).join('; ')}.`;
  return { key: 'evidence', label: 'Evidence', got, max: 2, notes, model, step: 2 };
}

/** One comparison paragraph: names both empires, uses comparison language, and explains why. */
export function comparisonCheck(c: LeqChallenge, text: string, kind: 'similarity' | 'difference'): string | null {
  const n = wordCount(text);
  if (n < 18) return `Write at least two sentences' worth (18+ words); you wrote ${n}.`;
  if (!isSentenceLike(text)) return 'Write this as connected sentences.';
  const both = mentionsA(c, text) && mentionsB(c, text);
  if (kind === 'similarity' && !hits(text, SIMILAR).length) return 'Use comparison language that shows likeness ("both", "similarly", "like the...").';
  if (kind === 'difference' && !hits(text, DIFFERENT).length) return 'Use language that shows contrast ("whereas", "while", "unlike", "in contrast").';
  if (!both && !(kind === 'similarity' && hits(text, ['both']).length && (mentionsA(c, text) || mentionsB(c, text)))) {
    return `Refer to both the ${c.subjects.a.label}s and the ${c.subjects.b.label}s.`;
  }
  if (!hits(text, CAUSAL).length) return 'Explain WHY the similarity or difference existed ("because...", "since...", "in order to...").';
  return null;
}

function reasoningRows({ c, d }: Ctx): Row[] {
  const sim = comparisonCheck(c, d.similarity, 'similarity');
  const dif = comparisonCheck(c, d.difference, 'difference');
  const one = !sim || !dif;
  const notes1 = one ? [] : ['Use comparison to structure your argument: fully explain at least one similarity or one difference.', `Similarity: ${sim}`, `Difference: ${dif}`];
  const notes2 = !sim && !dif ? [] : ['Complexity: explain BOTH a similarity and a difference, and why each existed.',
    ...(sim ? [`Similarity: ${sim}`] : []), ...(dif ? [`Difference: ${dif}`] : [])];
  return [
    { key: 'reasoning', label: 'Historical reasoning (comparison)', got: one ? 1 : 0, max: 1, notes: notes1, model: `Similarity: ${c.models.similarity}`, step: 3 },
    { key: 'complexity', label: 'Complexity', got: !sim && !dif ? 1 : 0, max: 1, notes: notes2, model: `Difference: ${c.models.difference}`, step: 3 },
  ];
}

export interface LeqScore extends Scorecard { verdicts: EvidenceVerdict[] }

export function scoreLeq(c: LeqChallenge, draft: LeqDraft): LeqScore {
  const x: Ctx = { c, d: draft };
  const verdicts = evidenceVerdicts(x);
  const rows = [thesisRow(x), scoreContext(c.context, draft.context, c.prompt, 1), evidenceRow(x, verdicts), ...reasoningRows(x)];
  return { ...finish(rows, c.passMark), verdicts };
}

export function leqEssay(c: LeqChallenge, d: LeqDraft): string {
  const ev = d.evidence.filter((e) => e.name.trim() || e.explain.trim()).map((e) => `${e.name.trim()}: ${e.explain.trim()}`);
  return [c.title, `Prompt: ${c.prompt}`, '', `${d.context.trim()} ${d.thesis.trim()}`.trim(), '', ...ev.map((e) => e + '\n'),
    d.similarity.trim(), '', d.difference.trim()].join('\n').trim();
}
