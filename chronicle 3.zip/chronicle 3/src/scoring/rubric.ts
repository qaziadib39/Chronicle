// Pieces shared by the DBQ and LEQ scorers.
import type { ContextSpec } from '../data/types';
import { has, hits, isSentenceLike, newWords, TIME, wordCount } from './text';

/** One rubric row on a scorecard. `step` is the essay step to jump back to when revising. */
export interface Row { key: string; label: string; got: number; max: number; notes: string[]; model?: string; step: number }
export interface Scorecard { rows: Row[]; total: number; max: number; pass: boolean }

export const finish = (rows: Row[], passMark: number): Scorecard => {
  const total = rows.reduce((s, r) => s + r.got, 0);
  return { rows, total, max: rows.reduce((s, r) => s + r.max, 0), pass: total >= passMark };
};

/**
 * Contextualization (both essays): "describes a broader historical context relevant to the prompt",
 * and it must be more than a phrase or reference. We require 25+ words, a sentence, at least one
 * specific development, two different context ideas, and language that places it in time.
 */
export function scoreContext(spec: ContextSpec, text: string, prompt: string, step: number): Row {
  const notes: string[] = [];
  const specific = hits(text, spec.specific), general = hits(text, spec.general);
  const n = wordCount(text);
  if (n < 25) notes.push(`More than a phrase is required. Write two or three sentences (25+ words); you wrote ${n}.`);
  else if (!isSentenceLike(text)) notes.push('Write this as connected sentences, not a list of terms.');
  if (!specific.length) notes.push('Name at least one specific broader development (an empire, network, event, or technology) from before or during the period.');
  else if (specific.length + general.length < 2) notes.push('Connect at least two ideas: what came before, and how it led into the prompt\'s period.');
  if (!TIME.some((t) => has(text, t))) notes.push('Show when it happened relative to the prompt, with words like "before", "by 1200", "during", or "led to".');
  if (n >= 25 && newWords(text, prompt) < 8) notes.push('This mostly restates the prompt. Describe the wider developments around it.');
  return { key: 'context', label: 'Contextualization', got: notes.length ? 0 : 1, max: 1, notes, model: spec.model, step };
}
