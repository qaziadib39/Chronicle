// Small text-analysis helpers shared by the SAQ, LEQ and DBQ scorers.
// Matching rules for word lists: 'tax*' is a prefix (tax, taxes, taxed); anything else
// must match as a whole word or phrase ('silk road' will not match 'silky roads').

const reCache = new Map<string, RegExp>();
const L = '\\p{L}\\p{N}';

export function termRe(term: string): RegExp {
  let re = reCache.get(term);
  if (re) return re;
  const prefix = term.endsWith('*');
  const body = (prefix ? term.slice(0, -1) : term)
    .toLowerCase().replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\s+/g, '[\\s-]+');
  re = new RegExp(`(^|[^${L}])${body}${prefix ? '' : `(?![${L}])`}`, 'iu');
  reCache.set(term, re);
  return re;
}

export const has = (text: string, term: string): boolean => termRe(term).test(text);
/** Which of `terms` appear in `text` (each listed once). */
export const hits = (text: string, terms: readonly string[]): string[] => terms.filter((t) => has(text, t));

export const words = (text: string): string[] => text.toLowerCase().replace(/[’‘]/g, "'").match(/[\p{L}\p{N}][\p{L}\p{N}'-]*/gu) ?? [];
export const wordCount = (text: string): number => words(text).length;

/** Number of sentences that contain at least three words. */
export const sentenceCount = (text: string): number => text.split(/[.!?;]+/).filter((s) => words(s).length >= 3).length;

const STOP = new Set(('a an the and or but of to in on at by for from with as is are was were be been being it its this that these those ' +
  'they them their he she his her him we our you your i my so because which who whom than then there here not no had has have do did does ' +
  'into onto over under about after before during while when where why how can could would should may might will also more most very').split(' '));
export const isStop = (w: string): boolean => STOP.has(w);

/**
 * True if the text reads like a sentence rather than a pile of keywords:
 * it has function words and isn't the same few words repeated.
 */
export function isSentenceLike(text: string): boolean {
  const w = words(text);
  if (w.length < 4) return false;
  const stops = w.filter(isStop).length;
  const unique = new Set(w).size;
  return stops >= 2 && stops / w.length >= 0.15 && unique / w.length >= 0.55;
}

/** Content words (not stop words) in `text` that do not appear in `reference`. */
export function newWords(text: string, reference: string): number {
  const ref = new Set(words(reference));
  return new Set(words(text).filter((w) => !isStop(w) && w.length > 2 && !ref.has(w))).size;
}

/** True if `text` copies a run of `n` or more consecutive words from `source` (quoting instead of describing). */
export function copiesRun(text: string, source: string, n = 7): boolean {
  const t = ' ' + words(text).join(' ') + ' ';
  const s = words(source);
  for (let i = 0; i + n <= s.length; i++) {
    if (t.includes(' ' + s.slice(i, i + n).join(' ') + ' ')) return true;
  }
  return false;
}

/** Words that show a causal or explanatory link ("how or why"). */
export const CAUSAL = ['because', 'since', 'so', 'so that', 'as a result', 'which meant', 'this meant', 'meaning', 'therefore', 'thus', 'led to', 'leading to',
  'allowed', 'allowing', 'helped', 'helping', 'enabled', 'caused', 'in order to', 'due to', 'which made', 'made it', 'resulted in', 'which let', 'let them', 'gave'];

/** Words that place an argument in time (needed for contextualization). */
export const TIME = ['before', 'earlier', 'previously', 'prior', 'after', 'afterward*', 'during', 'since', 'by the', 'by 1*', 'already', 'began', 'begun',
  'following', 'at the same time', 'throughout', 'later', 'until', 'meanwhile', 'led to', 'centuries', 'century', 'era', 'period', 'rose', 'rise of', 'decline*', 'fall of'];

/** Words that qualify or complicate a claim. */
export const QUALIFY = ['however', 'although', 'though', 'even though', 'while', 'whereas', 'despite', 'yet', 'nevertheless', 'nonetheless', 'on the other hand',
  'but', 'complicat*', 'qualif*', 'limit*', 'not always', 'not entirely', 'in contrast', 'admittedly', 'still'];

/** Words that tie evidence to an argument. */
export const LINK = ['shows', 'show', 'showed', 'showing', 'because', 'support*', 'demonstrat*', 'example', 'proves', 'illustrat*', 'suggest*', 'reveal*', 'means',
  'indicat*', 'evidence', 'which', 'this', 'so', 'helped', 'allowed', 'led to'];

/** Plain-language list: "a, b and c". */
export const listOf = (xs: string[]): string => (xs.length <= 1 ? xs.join('') : `${xs.slice(0, -1).join(', ')} and ${xs[xs.length - 1]}`);
