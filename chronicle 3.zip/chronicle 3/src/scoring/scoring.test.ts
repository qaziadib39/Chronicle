import { describe, expect, it } from 'vitest';
import { CHALLENGES, SOURCES } from '../data/content';
import type { DbqChallenge, LeqChallenge, SaqChallenge } from '../data/types';
import { scoreSaqPart } from './saq';
import { emptyDbqDraft, scoreDbq, type DbqDraft } from './dbq';
import { emptyLeqDraft, scoreLeq, type LeqDraft } from './leq';
import { copiesRun, has, isSentenceLike } from './text';

const saq = CHALLENGES.c3 as SaqChallenge;
const dbq = CHALLENGES.c4 as DbqChallenge;
const leq = CHALLENGES.c5 as LeqChallenge;
const docs = dbq.sourceIds.map((id) => SOURCES[id]);
const row = (rows: { key: string; got: number }[], key: string) => rows.find((r) => r.key === key)!.got;

describe('text helpers', () => {
  it('matches whole words and prefixes', () => {
    expect(has('They paid taxes', 'tax*')).toBe(true);
    expect(has('syntax error', 'tax*')).toBe(false);
    expect(has('the Silk Road network', 'silk road')).toBe(true);
    expect(has('Süleyman ruled', 'süleyman')).toBe(true);
  });
  it('tells sentences from keyword lists', () => {
    expect(isSentenceLike('Ships had to wait in port until the summer winds turned.')).toBe(true);
    expect(isSentenceLike('season tax tribute fleet stamp wait winter summer')).toBe(false);
  });
  it('detects copied runs', () => {
    expect(copiesRun('He says traders from many places fill the harbor every day', SOURCES.kilwa.text)).toBe(false);
    expect(copiesRun('The sultan\'s officials weigh each cargo and take their share', SOURCES.kilwa.text)).toBe(true);
  });
});

describe('SAQ', () => {
  const [a, b, c] = saq.parts.map((v) => v[0]);
  it('credits genuine answers', () => {
    expect(scoreSaqPart(a, 'Ships could only sail out in winter and had to wait in port for the summer winds to bring them home.').ok).toBe(true);
    expect(scoreSaqPart(b, 'People in the port spoke a language that mixed local and Arabic words.').ok).toBe(true);
    expect(scoreSaqPart(c, "The sultan's officials weighed every cargo and took a share, so rulers profited from trade and kept ports open.").ok).toBe(true);
  });
  it('rejects keyword stuffing', () => {
    expect(scoreSaqPart(a, 'season wait winter summer direction timing schedule').ok).toBe(false);
    expect(scoreSaqPart(c, 'tax toll tribute fleet sultan officials stamp tablet passage protect envoy').ok).toBe(false);
  });
  it('requires a causal link for "explain"', () => {
    const r = scoreSaqPart(c, "The sultan's officials weighed every cargo in the harbor and took a share of the goods.");
    expect(r.ok).toBe(false);
    expect(r.notes.join(' ')).toMatch(/how or why/);
  });
  it('rejects answers that only repeat the question', () => {
    expect(scoreSaqPart(a, 'One way the monsoon winds shaped Indian Ocean trade according to the notes.').ok).toBe(false);
  });
});

const strongDbq = (): DbqDraft => ({
  ...emptyDbqDraft(),
  stance: 0, r1: 'protect', r2: 'army',
  thesis: 'To a great extent, rulers shaped long-distance trade from 1200 to 1600, because they protected and taxed trade routes, and because gunpowder empires used armies to control trade cities.',
  context: 'Before 1200, the Abbasid Caliphate and Song China had already linked Afro-Eurasia through Muslim merchants and the Silk Roads. After 1200, the Mongol conquests united much of Eurasia, and later gunpowder empires rose.',
  uses: {
    ledger: { use: 'r1', desc: 'The merchant paid tolls at three posts that were each marked with a Mongol stamp.' },
    kilwa: { use: 'r1', desc: 'In the port, officials working for the sultan weighed cargoes and kept part of them as a tax.' },
    army: { use: 'r2', desc: 'The Venetian says Ottoman soldiers were paid by the treasury and their cannon could smash old walls.' },
    mughal: { use: 'r2', desc: 'The Mughal emperor gave officials land revenue in exchange for military service.' },
    monsoon: { use: 'counter', desc: 'The pilot explains that ships had to wait for the winter and summer winds to change.' },
  },
  outside: 'The Pax Mongolica shows rulers shaping trade, because protected roads let merchants cross Eurasia safely under one empire.',
  sourcing: [
    { doc: 'army', hipp: 'purpose', text: 'The Venetian envoy wrote to warn his government about a rival, so he may exaggerate Ottoman strength to get support.' },
    { doc: 'mughal', hipp: 'pov', text: 'As a court historian paid by the emperor, the author likely idealizes the emperor and makes his rule sound fairer than it was.' },
  ],
  counterDoc: 'monsoon',
  counterText: 'However, Doc 2 complicates this argument. The pilot plans every voyage around the winter and summer winds and never mentions rulers, which suggests geography limited how much any state could control trade.',
});

describe('DBQ', () => {
  it('awards 7/7 to a strong essay', () => {
    const s = scoreDbq(dbq, docs, strongDbq());
    expect(s.rows.filter((r) => r.got < r.max).map((r) => [r.key, r.notes])).toEqual([]);
    expect(s.total).toBe(7);
  });

  it('closes the v0.3 shortcut (generic filler no longer passes)', () => {
    const d: DbqDraft = { ...emptyDbqDraft(), stance: 0, r1: 'protect', r2: 'nature',
      thesis: 'To a great extent rulers shaped trade because of reasons.',
      context: 'there was a lot of trade before this time period.',
      uses: Object.fromEntries(dbq.sourceIds.map((id) => [id, { use: 'r1' as const, desc: 'this document is about trade' }])),
      outside: 'trade was important',
      sourcing: [{ doc: 'ledger', hipp: 'pov', text: 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa' }, { doc: '', hipp: 'pov', text: '' }],
      counterDoc: 'stele', counterText: 'however this is complicated by other things in trade' };
    const s = scoreDbq(dbq, docs, d);
    expect(s.total).toBe(0);
    expect(s.pass).toBe(false);
  });

  it('flags a stance that contradicts its own reasons', () => {
    const d = { ...strongDbq(), r2: 'nature' };
    const s = scoreDbq(dbq, docs, d);
    expect(row(s.rows, 'thesis')).toBe(0);
    expect(s.rows[0].notes.join(' ')).toMatch(/pulls against/);
  });

  it('accepts a coherent "limited extent" argument using counterpoints', () => {
    const d: DbqDraft = { ...strongDbq(), stance: 2, r1: 'nature', r2: 'merchants',
      thesis: 'Rulers shaped trade only to a limited extent, because monsoon winds set the rhythm of voyages and merchants often drove exchange in spite of rulers.',
      uses: {
        monsoon: { use: 'r1', desc: 'The pilot explains that ships had to wait for the winter and summer winds to change.' },
        ledger: { use: 'r2', desc: 'When officers forced paper notes on the bazaar, merchants shut their shops until silver returned.' },
        kilwa: { use: 'r2', desc: 'Merchants from many lands met in the harbor and the local language mixed in Arabic words.' },
        stele: { use: 'counter', desc: 'Chinese officials boast that their fleet carried silks and gifts and brought back envoys with tribute.' },
      },
      counterDoc: 'stele',
      counterText: 'However, Doc 4 complicates this argument. Chinese officials sent huge fleets that carried silk and gifts and collected tribute, which shows some states could reshape exchange when they chose to.' };
    const s = scoreDbq(dbq, docs, d);
    expect(row(s.rows, 'thesis')).toBe(1);
    expect(row(s.rows, 'docs')).toBe(2);
    expect(row(s.rows, 'complexity')).toBe(1);
  });

  it('does not credit quoting a document instead of describing it', () => {
    const d = strongDbq();
    d.uses.kilwa.desc = "The sultan's officials weigh each cargo and take their share.";
    const s = scoreDbq(dbq, docs, d);
    expect(s.verdicts.find((v) => v.id === 'kilwa')!.described).toBe(false);
  });

  it('needs four supporting documents for the second evidence point', () => {
    const d = strongDbq();
    delete d.uses.mughal; delete d.uses.monsoon;
    expect(row(scoreDbq(dbq, docs, d).rows, 'docs')).toBe(1);
  });

  it('rejects outside evidence that is really a document', () => {
    const d = { ...strongDbq(), outside: 'Zheng He led huge treasure fleets for the Ming emperor, which shows rulers shaped trade across the ocean.' };
    const r = scoreDbq(dbq, docs, d).rows.find((x) => x.key === 'outside')!;
    expect(r.got).toBe(0);
    expect(r.notes.join(' ')).toMatch(/Doc 4/);
  });

  it('requires sourcing for two different documents', () => {
    const d = strongDbq();
    d.sourcing[1] = { ...d.sourcing[0] };
    expect(row(scoreDbq(dbq, docs, d).rows, 'sourcing')).toBe(0);
  });

  it('rejects a counterpoint document that agrees with the thesis', () => {
    const d = { ...strongDbq(), counterDoc: 'stele' };
    expect(row(scoreDbq(dbq, docs, d).rows, 'complexity')).toBe(0);
  });
});

const strongLeq = (): LeqDraft => ({
  ...emptyLeqDraft(),
  thesis: 'Both the Ottoman and Mughal empires used gunpowder armies and loyal officials to consolidate power, but the Ottomans legitimized rule through Sunni Islam while the Mughals relied on religious tolerance.',
  context: 'Both empires grew out of Turkic and Mongol traditions in Central Asia. By the 1400s, gunpowder weapons let land-based empires conquer huge territories, as when the Ottomans took Constantinople in 1453.',
  evidence: [
    { empire: 'a', name: 'Devshirme', explain: 'Christian boys were converted and trained as officials loyal only to the sultan, which helped consolidate power.' },
    { empire: 'b', name: 'Mansabdari system', explain: 'Akbar ranked nobles by the troops they kept and ranks were not hereditary, so nobles depended on the emperor.' },
    { empire: '', name: '', explain: '' }, { empire: '', name: '', explain: '' },
  ],
  similarity: 'Both the Ottomans and the Mughals relied on officials whose rank depended on the ruler, because rulers of huge and diverse lands needed administrators who could not build their own power.',
  difference: 'While Ottoman sultans presented themselves as defenders of Sunni Islam, Akbar abolished the jizya and promoted tolerance, because the Mughals ruled a mostly Hindu population.',
});

describe('LEQ', () => {
  it('awards 6/6 to a strong essay', () => {
    const s = scoreLeq(leq, strongLeq());
    expect(s.rows.filter((r) => r.got < r.max).map((r) => [r.key, r.notes])).toEqual([]);
    expect(s.total).toBe(6);
  });
  it('treats general terms as not specific', () => {
    const d = strongLeq();
    d.evidence[0] = { empire: 'a', name: 'religious tolerance', explain: 'They were tolerant of other religions, which helped them keep control of the empire.' };
    const s = scoreLeq(leq, d);
    expect(s.verdicts[0].specific).toBe(false);
    expect(s.verdicts[0].note).toMatch(/millet/);
  });
  it('catches evidence credited to the wrong empire', () => {
    const d = strongLeq();
    d.evidence[0].empire = 'b';
    const s = scoreLeq(leq, d);
    expect(s.verdicts[0].attributed).toBe(false);
    expect(row(s.rows, 'evidence')).toBe(1);
  });
  it('gives the reasoning point for one comparison but complexity only for both', () => {
    const d = { ...strongLeq(), difference: '' };
    const s = scoreLeq(leq, d);
    expect(row(s.rows, 'reasoning')).toBe(1);
    expect(row(s.rows, 'complexity')).toBe(0);
  });
  it('requires both empires in the thesis', () => {
    const d = { ...strongLeq(), thesis: 'The Ottoman Empire used gunpowder armies and the devshirme to consolidate power over a huge and diverse territory.' };
    expect(row(scoreLeq(leq, d).rows, 'thesis')).toBe(0);
  });
});
