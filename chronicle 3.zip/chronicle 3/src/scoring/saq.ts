// AP short-answer scoring. Each part is worth 1 point and is judged on the task verb:
//  identify = name a correct, relevant example;
//  describe = give relevant characteristics, more than naming;
//  explain  = say how or why, with a causal link.
import type { SaqPart } from '../data/types';
import { CAUSAL, hits, isSentenceLike, newWords, wordCount } from './text';

export const MIN_WORDS = { identify: 6, describe: 10, explain: 14 } as const;

export interface PartResult { ok: boolean; notes: string[] }

export function scoreSaqPart(p: SaqPart, answer: string): PartResult {
  const notes: string[] = [];
  const n = wordCount(answer);
  const min = MIN_WORDS[p.verb];
  if (!answer.trim()) return { ok: false, notes: ['No answer yet.'] };
  if (n < min) notes.push(`Too short. A complete "${p.verb}" answer needs at least ${min} words here; you wrote ${n}.`);
  else if (!isSentenceLike(answer)) notes.push('This reads like a list of keywords. Write it as a complete sentence that a reader can follow.');
  if (n >= min && newWords(answer, p.q) < 3) notes.push('Most of this repeats the question. Add the specific idea from the source in your own words.');
  if (!hits(answer, p.concepts).length) notes.push('Your answer does not include a specific, accurate idea from the sources yet.');
  if (p.verb === 'explain' && !hits(answer, CAUSAL).length) {
    notes.push('"Explain" means saying how or why. Connect your example to the question with "because", "so", or "which led to".');
  }
  return { ok: notes.length === 0, notes };
}

/** Picks the version of each part for a given attempt, so a retry is a fresh question. */
export const saqVersion = (variants: SaqPart[], attempt: number): SaqPart => variants[attempt % variants.length];
