// DBQ scoring against the current College Board rubric (7 points):
//  A Thesis (1)  B Contextualization (1)
//  C Evidence from documents (2: describe 3+ docs / use 4+ docs to support an argument)
//    Evidence beyond the documents (1)
//  D Sourcing for at least 2 documents (1)  Complexity (1)
// Automatic scoring is approximate practice; a teacher should read real essays.
import type { DbqChallenge, DbqReason, Side, Source } from '../data/types';
import { CAUSAL, copiesRun, hits, isSentenceLike, LINK, newWords, QUALIFY, sentenceCount, wordCount } from './text';
import { finish, scoreContext, type Row, type Scorecard } from './rubric';

export type Hipp = 'situation' | 'audience' | 'purpose' | 'pov';
export const HIPP_LABEL: Record<Hipp, string> = { situation: 'Historical situation', audience: 'Intended audience', purpose: 'Purpose', pov: 'Point of view' };
export type DocUse = '' | 'r1' | 'r2' | 'counter';

export interface DbqDraft {
  stance: number; r1: string; r2: string; thesis: string;
  context: string;
  uses: Record<string, { use: DocUse; desc: string }>;
  outside: string;
  sourcing: { doc: string; hipp: Hipp; text: string }[];
  counterDoc: string; counterText: string;
}

export function emptyDbqDraft(): DbqDraft {
  return { stance: 0, r1: '', r2: '', thesis: '', context: '', uses: {}, outside: '',
    sourcing: [{ doc: '', hipp: 'pov', text: '' }, { doc: '', hipp: 'purpose', text: '' }], counterDoc: '', counterText: '' };
}

/** Accepts anything from storage and returns a well-formed draft. */
export function normalizeDbqDraft(raw: unknown): DbqDraft {
  const d = { ...emptyDbqDraft(), ...(raw && typeof raw === 'object' ? raw as Partial<DbqDraft> : {}) };
  if (!Array.isArray(d.sourcing) || d.sourcing.length !== 2) d.sourcing = emptyDbqDraft().sourcing;
  d.uses = d.uses && typeof d.uses === 'object' ? d.uses : {};
  d.stance = [0, 1, 2].includes(d.stance) ? d.stance : 0;
  return d;
}

const DEGREE = ['great*', 'large*', 'significant*', 'moderate*', 'partly', 'partial*', 'some', 'somewhat', 'limited', 'little', 'mostly', 'largely', 'mainly',
  'primarily', 'extent', 'considerabl*', 'minor', 'major', 'heavily', 'strongly', 'only'];
const REASONING = ['because', 'since', 'as', 'due to', 'through', 'by', 'while', 'although', 'but', 'however', 'whereas'];

const HIPP_SIGNALS: Record<Hipp, string[]> = {
  pov: ['point of view', 'perspective', 'viewpoint', 'bias*', 'as a', 'as an', 'background', 'position', 'identity', 'who wrote', 'author', 'writer'],
  purpose: ['purpose', 'in order to', 'intended to', 'meant to', 'wanted to', 'trying to', 'tried to', 'to glorify', 'to praise', 'to persuade', 'to convince', 'to warn',
    'to record', 'to celebrate', 'to impress', 'to justify', 'to inform', 'to track', 'to keep track', 'to alert', 'to show', 'goal', 'aim*', 'so that', 'why it was written'],
  audience: ['audience', 'written for', 'reader*', 'intended for', 'addressed', 'for his', 'for her', 'for their', 'for other', 'home', 'government', 'public', 'sailors',
    'superiors', 'senate', 'people back', 'whoever read', 'for the emperor', 'for himself', 'own use'],
  situation: ['at the time', 'situation', 'context', 'during', 'period', 'era', 'time of', 'when it was', 'rivalry', 'rival*', 'war*', 'competition', 'expanding', 'expansion',
    'crisis', 'century', 'in 1*', 'after', 'before', 'threat*'],
};
const EFFECT = ['reliab*', 'unreliab*', 'useful*', 'bias*', 'exaggerat*', 'overstat*', 'understat*', 'idealiz*', 'idealis*', 'flatter*', 'trust*', 'believ*', 'credib*',
  'limit*', 'accura*', 'inaccura*', 'skew*', 'downplay*', 'emphasi*', 'stress*', 'one-sided', 'so it', 'which means', 'this means', 'might', 'may', 'likely', 'probably',
  'less', 'more', 'only shows', 'leaves out', 'ignores', 'omit*', 'does not mention', "doesn't mention", 'never mentions', 'focus*'];

interface Ctx { c: DbqChallenge; sources: Source[]; d: DbqDraft }

const docNo = (sources: Source[], id: string): string => `Doc ${sources.findIndex((s) => s.id === id) + 1}`;
const reasonOf = (c: DbqChallenge, id: string): DbqReason | undefined => c.reasons.find((r) => r.id === id);

/** The side a stance argues: great = rulers mattered most, limited = other forces mattered most. */
export const thesisSide = (stance: number): Side | null => (stance === 0 ? 'for' : stance === 2 ? 'against' : null);
export const docSides = (c: DbqChallenge, id: string): Side[] => [...new Set(c.reasons.filter((r) => r.docs.includes(id)).map((r) => r.side))];

/** Can this document serve as a counterpoint to the student's stance? */
export function isCounterDoc(c: DbqChallenge, stance: number, id: string): boolean {
  const side = thesisSide(stance);
  const sides = docSides(c, id);
  if (!sides.length) return false;
  return side === null ? true : sides.some((s) => s !== side);
}

export function thesisDraft(c: DbqChallenge, d: DbqDraft): string {
  const r1 = reasonOf(c, d.r1), r2 = reasonOf(c, d.r2);
  if (!r1 || !r2 || r1 === r2) return '';
  return `${c.stances[d.stance]}, rulers and states shaped long-distance trade and cultural exchange in Afro-Eurasia from 1200 to 1600, because ${r1.text}, and because ${r2.text}.`;
}

function thesisRow({ c, d }: Ctx): Row {
  const notes: string[] = [];
  const r1 = reasonOf(c, d.r1), r2 = reasonOf(c, d.r2);
  if (!r1 || !r2 || r1 === r2) notes.push('Choose two different reasons so your thesis has a line of reasoning.');
  else {
    const stance = c.stances[d.stance].toLowerCase();
    if (d.stance === 0) {
      const off = [r1, r2].filter((r) => r.side === 'against');
      if (off.length) notes.push(`"${off[0].text}" argues that forces other than rulers mattered, which pulls against "${stance}". Swap it for a reason about what rulers did, or change your stance.`);
    } else if (d.stance === 1 && r1.side === r2.side) {
      notes.push('A "moderate extent" claim needs one reason showing rulers mattered and one showing the limits of their power.');
    } else if (d.stance === 2 && r1.side === 'for' && r2.side === 'for') {
      notes.push('Both reasons argue that rulers mattered a lot, which contradicts "to a limited extent". Use at least one reason about other forces, like geography or merchants.');
    }
  }
  const t = d.thesis;
  const n = wordCount(t);
  if (n < 15) notes.push(`Write your thesis as a full sentence (15+ words); you wrote ${n}.`);
  else {
    if (!hits(t, DEGREE).length) notes.push('Say how much: "to a great extent", "partly", "largely", and so on. An "evaluate the extent" prompt needs a judgment.');
    if (!hits(t, REASONING).length) notes.push('Add your reasons with "because", "through", or "while" so the thesis sets up a line of reasoning.');
    if (newWords(t, c.prompt) < 6) notes.push('This mostly restates the prompt. Add your specific reasons.');
  }
  return { key: 'thesis', label: 'Thesis / claim', got: notes.length ? 0 : 1, max: 1, notes, model: c.models.thesis, step: 0 };
}

export interface DocVerdict { id: string; label: string; use: DocUse; described: boolean; linked: boolean; note: string }

export function docVerdicts({ c, sources, d }: Ctx): DocVerdict[] {
  const out: DocVerdict[] = [];
  for (const s of sources) {
    const u = d.uses[s.id];
    if (!u?.use) continue;
    const label = docNo(sources, s.id);
    const desc = u.desc ?? '';
    let described = false, note = '';
    if (wordCount(desc) < 8) note = 'Describe what the document says in a full sentence (8+ words).';
    else if (copiesRun(desc, s.text)) note = 'This copies the document word for word. The rubric requires describing the content in your own words, not quoting it.';
    else if (!isSentenceLike(desc)) note = 'Write the description as a sentence.';
    else if (!hits(desc, s.facts).length) note = 'This does not mention any specific content from the document yet.';
    else described = true;
    let linked = false;
    if (u.use === 'counter') linked = isCounterDoc(c, d.stance, s.id);
    else linked = !!reasonOf(c, u.use === 'r1' ? d.r1 : d.r2)?.docs.includes(s.id);
    if (described && !linked) {
      note = u.use === 'counter'
        ? 'This document mostly agrees with your stance, so it does not work as a counterpoint.'
        : 'Described accurately, but this document does not really support that reason. Try another reason, or use it as a counterpoint.';
    }
    if (described && linked) note = 'Accurately described and used to support your argument.';
    out.push({ id: s.id, label, use: u.use, described, linked, note });
  }
  return out;
}

function evidenceRow(x: Ctx, v: DocVerdict[]): Row {
  const described = v.filter((e) => e.described).length;
  const supporting = v.filter((e) => e.described && e.linked).length;
  const got = supporting >= 4 ? 2 : described >= 3 ? 1 : 0;
  const notes: string[] = [];
  if (got < 1) notes.push(`1 point: accurately describe the content of at least 3 documents. You have ${described}.`);
  if (got < 2) notes.push(`2 points: use at least 4 documents to support your argument (each accurately described and tied to a reason or counterpoint). You have ${supporting}.`);
  for (const e of v) if (!(e.described && e.linked)) notes.push(`${e.label}: ${e.note}`);
  return { key: 'docs', label: 'Evidence from the documents', got, max: 2, notes, step: 2 };
}

function outsideRow({ c, d }: Ctx): Row {
  const notes: string[] = [];
  const t = d.outside;
  const item = c.outside.find((o) => hits(t, o.aliases).length);
  const banned = c.notOutside.find((o) => hits(t, o.aliases).length);
  if (!t.trim()) notes.push('Add one specific piece of evidence that is not in the documents.');
  else if (!item && banned) notes.push(banned.why);
  else if (!item) notes.push('Name a specific person, event, policy, or place that is not in the documents (for example: Pax Mongolica, Mansa Musa, the Black Death, the Portuguese in the Indian Ocean).');
  if (t.trim() && wordCount(t) < 12) notes.push('Describe it and connect it to your argument in a full sentence or two; naming it is not enough.');
  else if (item && !hits(t, LINK).length) notes.push('Explain how this evidence supports your argument ("this shows...", "because...").');
  return { key: 'outside', label: 'Evidence beyond the documents', got: notes.length ? 0 : 1, max: 1, notes,
    model: item ? `${item.label}: ${item.note}\n\nExample: ${c.models.outside}` : c.models.outside, step: 2 };
}

export function sourcingCheck(s: Source | undefined, hipp: Hipp, text: string): string | null {
  if (!s) return 'Choose a document.';
  if (wordCount(text) < 15) return 'Explain in a full sentence or two (15+ words).';
  if (!isSentenceLike(text)) return 'Write the explanation as a sentence.';
  const signals = hipp === 'pov' ? [...HIPP_SIGNALS.pov, ...s.who] : HIPP_SIGNALS[hipp];
  if (!hits(text, signals).length) return `Identify the ${HIPP_LABEL[hipp].toLowerCase()} specifically (for example, who the author was writing for, why, or from what position).`;
  if (!hits(text, EFFECT).length) return 'Explain how or why this matters: does it make the document more reliable, less reliable, or useful for some things but not others?';
  return null;
}

function sourcingRow({ sources, d }: Ctx): Row {
  const notes: string[] = [];
  let good = 0;
  const seen = new Set<string>();
  d.sourcing.forEach((slot, i) => {
    const s = sources.find((x) => x.id === slot.doc);
    if (slot.doc && seen.has(slot.doc)) { notes.push(`Attempt ${i + 1}: source two different documents.`); return; }
    if (slot.doc) seen.add(slot.doc);
    const why = sourcingCheck(s, slot.hipp, slot.text);
    if (why) notes.push(`Attempt ${i + 1}${s ? ` (${docNo(sources, s.id)})` : ''}: ${why}`);
    else good++;
  });
  if (good < 2) notes.unshift(`The rubric requires explaining how or why the HIPP of at least two documents is relevant. You have ${good} that work.`);
  const models = d.sourcing.map((sl) => sources.find((x) => x.id === sl.doc)).filter((s): s is Source => !!s)
    .map((s) => `${docNo(sources, s.id)}: ${s.sourcing}`).join('\n\n');
  return { key: 'sourcing', label: 'Sourcing (HIPP)', got: good >= 2 ? 1 : 0, max: 1, notes, model: models || undefined, step: 3 };
}

function complexityRow({ c, sources, d }: Ctx): Row {
  const notes: string[] = [];
  const s = sources.find((x) => x.id === d.counterDoc);
  const t = d.counterText;
  if (!s) notes.push('Choose a document that complicates or qualifies your argument.');
  else if (!isCounterDoc(c, d.stance, s.id)) notes.push(`${docNo(sources, s.id)} mostly agrees with "${c.stances[d.stance].toLowerCase()}", so it can't qualify your argument. Pick a document that points the other way.`);
  const n = wordCount(t);
  if (n < 30 || sentenceCount(t) < 2) notes.push('Complexity has to be part of your argument, not a phrase. Write at least two sentences (30+ words).');
  else {
    if (!hits(t, QUALIFY).length) notes.push('Signal the qualification with words like "however", "although", or "this complicates...".');
    if (s && !hits(t, s.facts).length) notes.push(`Refer to what ${docNo(sources, s.id)} actually says.`);
    if (!hits(t, [...CAUSAL, 'shows', 'suggests', 'reveals', 'indicates', 'means']).length) {
      notes.push('Explain what the complication means for your thesis (for example, "this suggests rulers could not control...").');
    }
  }
  return { key: 'complexity', label: 'Complexity', got: notes.length ? 0 : 1, max: 1, notes, model: c.models.complexity, step: 4 };
}

export interface DbqScore extends Scorecard { verdicts: DocVerdict[] }

export function scoreDbq(c: DbqChallenge, sources: Source[], draft: DbqDraft): DbqScore {
  const x: Ctx = { c, sources, d: draft };
  const verdicts = docVerdicts(x);
  const rows = [thesisRow(x), scoreContext(c.context, draft.context, c.prompt, 1), evidenceRow(x, verdicts), outsideRow(x), sourcingRow(x), complexityRow(x)];
  return { ...finish(rows, c.passMark), verdicts };
}

/** The student's essay as plain text, ready to hand in to a teacher. */
export function dbqEssay(c: DbqChallenge, sources: Source[], d: DbqDraft): string {
  const para: string[] = [`${d.context.trim()} ${d.thesis.trim()}`.trim()];
  const body = (use: DocUse, head?: string) => {
    const lines = sources.filter((s) => d.uses[s.id]?.use === use && d.uses[s.id]?.desc.trim())
      .map((s) => `${d.uses[s.id].desc.trim()} (${docNo(sources, s.id)})`);
    if (lines.length) para.push([head, ...lines].filter(Boolean).join(' '));
  };
  const r1 = reasonOf(c, d.r1), r2 = reasonOf(c, d.r2);
  body('r1', r1 ? `First, ${r1.text}.` : undefined);
  body('r2', r2 ? `Second, ${r2.text}.` : undefined);
  if (d.outside.trim()) para.push(d.outside.trim());
  const src = d.sourcing.filter((s) => s.text.trim()).map((s) => `${s.text.trim()}${s.doc ? ` (${docNo(sources, s.doc)})` : ''}`);
  if (src.length) para.push(src.join(' '));
  body('counter');
  if (d.counterText.trim()) para.push(d.counterText.trim());
  return [`${c.title}`, `Prompt: ${c.prompt}`, '', ...para.map((p) => p + '\n')].join('\n').trim();
}

export const describeUse = (c: DbqChallenge, d: DbqDraft, u: DocUse): string =>
  u === 'r1' ? `Reason 1: ${reasonOf(c, d.r1)?.text ?? '(choose in step 1)'}` : u === 'r2' ? `Reason 2: ${reasonOf(c, d.r2)?.text ?? '(choose in step 1)'}` : u === 'counter' ? 'Counterpoint (shows the other side)' : 'Not used';

