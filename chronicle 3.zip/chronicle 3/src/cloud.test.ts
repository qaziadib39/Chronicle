// Shared-computer scenarios for cloud saves, run against a fake Supabase.
import { beforeEach, describe, expect, it, vi } from 'vitest';

type Row = { data: Record<string, unknown> };
const db = new Map<string, Row>();
let session: { user: { id: string; email: string } } | null = null;
const pushes: string[] = [];

vi.mock('@supabase/supabase-js', () => ({
  createClient: () => ({
    auth: {
      getSession: async () => ({ data: { session } }),
      signInWithPassword: async ({ email }: { email: string }) => {
        session = { user: { id: email.split('@')[0], email } };
        return { data: { user: session.user, session }, error: null };
      },
      signUp: async () => ({ data: { session: null, user: null }, error: null }),
      signOut: async () => { session = null; return { error: null }; },
    },
    from: () => ({
      select: () => ({ eq: (_c: string, id: string) => ({ maybeSingle: async () => ({ data: db.get(id) ?? null, error: null }) }) }),
      upsert: async (row: { user_id: string; data: Record<string, unknown> }) => {
        pushes.push(row.user_id); db.set(row.user_id, { data: JSON.parse(JSON.stringify(row.data)) }); return { error: null };
      },
      insert: async () => ({ error: null }),
    }),
  }),
}));

// Minimal browser globals for state.ts / cloud.ts.
const store = new Map<string, string>();
Object.assign(globalThis, {
  localStorage: { getItem: (k: string) => store.get(k) ?? null, setItem: (k: string, v: string) => store.set(k, v), removeItem: (k: string) => store.delete(k) },
  window: globalThis,
  document: { addEventListener: () => {}, visibilityState: 'visible' },
});

const KEY = 'chronicle-save-v1';
const saved = (s: Record<string, unknown>) => store.set(KEY, JSON.stringify(s));

async function boot() {
  vi.resetModules();
  vi.stubEnv('VITE_SUPABASE_URL', 'https://example.supabase.co');
  vi.stubEnv('VITE_SUPABASE_ANON_KEY', 'anon');
  const st = await import('./state');
  const cloud = await import('./cloud');
  return { ...st, ...cloud };
}

beforeEach(() => { db.clear(); store.clear(); session = null; pushes.length = 0; });

describe('cloud saves on shared computers', () => {
  it('signing out wipes this device for the next student', async () => {
    saved({ xp: 300, owner: 'ana', examined: ['ledger'], updatedAt: 5 });
    session = { user: { id: 'ana', email: 'ana@school.org' } };
    db.set('ana', { data: { xp: 300, owner: 'ana', examined: ['ledger'], updatedAt: 5 } });
    const m = await boot();
    await m.restoreSession();
    expect(m.state.xp).toBe(300);
    await m.signOut();
    expect(m.state.xp).toBe(0);
    expect(m.state.owner).toBeNull();
    expect(JSON.parse(store.get(KEY)!).xp).toBe(0);
  });

  it("never merges another student's save into a new account", async () => {
    saved({ xp: 400, owner: 'ana', examined: ['ledger', 'coin'], updatedAt: 9 });
    const m = await boot();
    // Ana's session expired without signing out: the device must not keep her progress.
    await m.restoreSession();
    expect(m.state.xp).toBe(0);
    await m.signIn('ben@school.org', 'pw');
    expect(m.state.xp).toBe(0);
    expect(m.state.owner).toBe('ben');
    expect(db.get('ben')!.data.xp).toBe(0);
  });

  it('loads the cloud save instead of whatever is on the device', async () => {
    saved({ xp: 400, owner: 'ana', updatedAt: 9 });
    db.set('ben', { data: { xp: 120, owner: 'ben', examined: ['monsoon'], updatedAt: 3 } });
    const m = await boot();
    session = { user: { id: 'ben', email: 'ben@school.org' } };
    await m.restoreSession();
    expect(m.state.xp).toBe(120);
    expect(m.state.examined).toEqual(['monsoon']);
  });

  it('asks before adding guest progress to an account', async () => {
    saved({ xp: 90, owner: null, examined: ['ledger'], updatedAt: 4 });
    let m = await boot();
    m.onGuestProgress(async () => false);
    await m.signIn('cara@school.org', 'pw');
    expect(m.state.xp).toBe(0);

    db.clear(); session = null;
    saved({ xp: 90, owner: null, examined: ['ledger'], updatedAt: 4 });
    m = await boot();
    m.onGuestProgress(async (xp) => xp === 90);
    await m.signIn('cara@school.org', 'pw');
    expect(m.state.xp).toBe(90);
    expect(db.get('cara')!.data.xp).toBe(90);
  });

  it("keeps the same student's newer offline progress", async () => {
    saved({ xp: 200, owner: 'dev', updatedAt: 50 });
    db.set('dev', { data: { xp: 150, owner: 'dev', updatedAt: 10 } });
    session = { user: { id: 'dev', email: 'dev@school.org' } };
    const m = await boot();
    await m.restoreSession();
    expect(m.state.xp).toBe(200);
    expect(db.get('dev')!.data.xp).toBe(200);
  });

  it('repairs v0.3 saves stuck on the quest tracker', async () => {
    saved({ xp: 300, area: 'bazaar', examined: ['monsoon', 'millet'], passed: ['c1', 'c2', 'c3'], flags: {} });
    const m = await boot();
    expect(m.state.flags.visited_port).toBe(true);
    expect(m.state.flags.visited_bazaar).toBe(true);
  });
});
