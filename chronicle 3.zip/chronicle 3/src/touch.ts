// On-screen controls for tablets and phones. The game scene reads `touch` every frame.
export const touch = { dx: 0, dy: 0, act: false, journal: false };

export const isTouchDevice = (): boolean =>
  (window.matchMedia?.('(pointer: coarse)').matches ?? false) || (navigator.maxTouchPoints ?? 0) > 0;

export function mountTouchControls(): void {
  if (!isTouchDevice() || document.getElementById('touch')) return;
  const wrap = document.getElementById('wrap')!;
  const root = document.createElement('div'); root.id = 'touch';

  const pad = document.createElement('div'); pad.className = 'pad';
  const dirs: [string, number, number, string][] = [['▲', 0, -1, 'up'], ['◀', -1, 0, 'left'], ['▶', 1, 0, 'right'], ['▼', 0, 1, 'down']];
  for (const [label, dx, dy, name] of dirs) {
    const b = document.createElement('button');
    b.type = 'button'; b.textContent = label; b.className = 'dir ' + name; b.setAttribute('aria-label', `Move ${name}`);
    const stop = () => { if (touch.dx === dx) touch.dx = 0; if (touch.dy === dy) touch.dy = 0; };
    b.addEventListener('pointerdown', (e) => { e.preventDefault(); b.setPointerCapture(e.pointerId); if (dx) touch.dx = dx; if (dy) touch.dy = dy; });
    ['pointerup', 'pointercancel', 'lostpointercapture'].forEach((ev) => b.addEventListener(ev, stop));
    pad.append(b);
  }

  const acts = document.createElement('div'); acts.className = 'acts';
  const mk = (label: string, key: 'act' | 'journal') => {
    const b = document.createElement('button');
    b.type = 'button'; b.textContent = label; b.className = 'act';
    b.addEventListener('pointerdown', (e) => { e.preventDefault(); touch[key] = true; });
    acts.append(b);
  };
  mk('Use', 'act'); mk('Journal', 'journal');

  root.append(pad, acts);
  wrap.append(root);
  // Tapping the "[E] Talk to…" prompt also works.
  document.getElementById('prompt')!.addEventListener('pointerdown', () => { touch.act = true; });
  const help = document.getElementById('help');
  if (help) help.textContent = 'Move: arrow pad • Talk / examine: Use, or tap the prompt • Journal: Journal button';
}
