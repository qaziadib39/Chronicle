import type { UI } from './ui';
import type { Challenge, Source, McChallenge, TagChallenge, SaqChallenge } from '../data/content';
import { state, recordAttempt, saveSoon } from '../state';
import { submitAttempt } from '../cloud';
import { scoreSaqPart, saqVersion, MIN_WORDS } from '../scoring/saq';
import { dbq } from './dbq';
import { leq } from './leq';
import { el, textArea, collapsible } from './essay';
import { sfx } from '../audio';

/** Outcome of a challenge session. `tries` counts graded attempts (wrong picks + 1 for multiple choice). */
export interface Result { passed: boolean; score: number; max: number; tries: number }
export type Done = (r: Result) => void;

/** XP for a first-time pass: guessing costs XP, and essays pay for every rubric point earned. */
export function xpFor(c: Challenge, r: Result): number {
  switch (c.kind) {
    case 'mc': return Math.max(20, c.xp - 15 * (r.tries - 1));
    case 'tag': return Math.max(25, c.xp - 15 * (r.tries - 1));
    case 'saq': return Math.max(25, Math.round((c.xp * r.score) / r.max) - 10 * (r.tries - 1));
    case 'leq': return c.xp + 12 * r.score;
    case 'dbq': return c.xp + 15 * r.score;
  }
}

export function runChallenge(ui: UI, c: Challenge, sources: Source[], done: Done): void {
  ui.clearKeys();
  ui.card.className = '';
  if (c.kind === 'dbq') { dbq(ui, c, sources, done); return; }
  if (c.kind === 'leq') { leq(ui, c, done); return; }
  const card = ui.card;
  card.innerHTML = '';
  card.append(el('h3', c.title), el('p', c.prompt));
  const bank = el('div', undefined, 'bank');
  sources.forEach((s, i) => {
    const d = el('div', undefined, 'srcline');
    d.append(el('b', `Source ${i + 1}: ${s.title}`), el('span', ` (${s.author}, ${s.date}). `), el('span', `"${s.text}"`));
    bank.append(d);
  });
  card.append(bank);
  const leave = () => { ui.close(); done({ passed: false, score: 0, max: 1, tries: 0 }); };
  if (c.kind === 'mc') mc(ui, c, done);
  else if (c.kind === 'tag') tag(ui, c, sources, done);
  else saq(ui, c, sources, done);
  card.append(ui.button('Leave', leave));
  ui.open();
  card.scrollTop = 0;
}

function mc(ui: UI, c: McChallenge, done: Done): void {
  const fb = el('div');
  fb.setAttribute('aria-live', 'polite');
  const btns: HTMLButtonElement[] = [];
  let wrong = 0;
  c.options.forEach((o, idx) => {
    const b = ui.button(o, () => {
      const ok = idx === c.correct;
      b.classList.add(ok ? 'good' : 'bad');
      fb.className = 'fb'; fb.textContent = c.feedback[idx];
      recordAttempt(c.id, ok ? 1 : 0, 1, ok);
      if (ok) {
        sfx.good();
        btns.forEach((x) => (x.disabled = true));
        fb.append(document.createElement('br'), ui.button('Continue', () => { ui.close(); done({ passed: true, score: 1, max: 1, tries: wrong + 1 }); }));
      } else { wrong++; sfx.bad(); b.disabled = true; }
    }, 'opt');
    btns.push(b); ui.card.append(b);
  });
  ui.card.append(fb);
}

function tag(ui: UI, c: TagChallenge, sources: Source[], done: Done): void {
  const holder = el('div');
  ui.card.append(holder);
  const opts: [string, string][] = [['S', 'Supports'], ['C', 'Contradicts'], ['N', 'Not relevant']];
  let tries = 0;
  const render = (keep: (string | null)[]) => {
    holder.replaceChildren();
    const picks = c.answers.map((_, i) => keep[i] ?? null);
    const rows: { fb: HTMLElement; btns: HTMLButtonElement[] }[] = [];
    const check = ui.button('Check answers', () => {
      tries++;
      let right = 0;
      picks.forEach((p, i) => {
        const ok = p === c.answers[i];
        if (ok) right++;
        rows[i].btns.forEach((b) => { b.disabled = true; });
        rows[i].fb.className = 'fb';
        rows[i].fb.textContent = ok ? `✔ ${c.feedback[i]}` : `✘ Not yet. Hint: ${c.hints[i]}`;
      });
      const passed = right === c.answers.length;
      recordAttempt(c.id, right, c.answers.length, passed);
      check.remove();
      if (passed) sfx.good(); else sfx.bad();
      holder.append(passed
        ? ui.button('Continue', () => { ui.close(); done({ passed: true, score: right, max: c.answers.length, tries }); })
        : ui.button('Try again (correct tags are kept)', () => render(picks.map((p, i) => (p === c.answers[i] ? p : null)))));
    });
    sources.forEach((s, i) => {
      const row = el('div', undefined, 'row');
      row.append(el('b', `Source ${i + 1}: ${s.title}`));
      const btns: HTMLButtonElement[] = [];
      const wrap = el('div');
      opts.forEach(([v, label]) => {
        const b = ui.button(label, () => {
          picks[i] = v;
          btns.forEach((x) => { x.classList.remove('sel'); x.setAttribute('aria-pressed', 'false'); });
          b.classList.add('sel'); b.setAttribute('aria-pressed', 'true');
          check.disabled = picks.some((p) => p === null);
        }, 'tg' + (picks[i] === v ? ' sel' : ''));
        btns.push(b); wrap.append(b);
      });
      const fb = el('div');
      if (keep[i]) { btns.forEach((b) => (b.disabled = true)); fb.className = 'fb'; fb.textContent = `✔ ${c.feedback[i]}`; }
      row.append(wrap, fb); rows.push({ fb, btns }); holder.append(row);
    });
    check.disabled = picks.some((p) => p === null);
    holder.append(check);
  };
  render([]);
}

interface SaqDraft { attempt: number; answers: string[] }

function saq(ui: UI, c: SaqChallenge, sources: Source[], done: Done): void {
  const attempt = state.records[c.id]?.attempts ?? 0;
  const saved = state.drafts[c.id] as SaqDraft | undefined;
  const draft: SaqDraft = saved && saved.attempt === attempt ? saved : { attempt, answers: c.parts.map(() => '') };
  state.drafts[c.id] = draft;
  const parts = c.parts.map((v) => saqVersion(v, attempt));
  const holder = el('div');
  if (attempt > 0) holder.append(el('p', `Attempt ${attempt + 1}: these are new versions of the questions.`, 'tip'));
  parts.forEach((p, i) => {
    holder.append(el('p', p.q, 'qpart'), el('div', `Task verb: ${p.verb.toUpperCase()}. ${verbHelp[p.verb]}`, 'meta'));
    holder.append(textArea(draft.answers[i], 'Your answer, in complete sentences…', (v) => { draft.answers[i] = v; saveSoon(); }, MIN_WORDS[p.verb], 3));
  });
  const out = el('div');
  out.setAttribute('aria-live', 'polite');
  const submit = ui.button('Submit answers', () => {
    const results = parts.map((p, i) => scoreSaqPart(p, draft.answers[i]));
    const score = results.filter((r) => r.ok).length;
    const pass = score >= c.passMark;
    const rec = recordAttempt(c.id, score, parts.length, pass);
    void submitAttempt(c.id, score, parts.length, { questions: parts.map((p) => p.q), answers: draft.answers });
    delete state.drafts[c.id]; saveSoon();
    holder.querySelectorAll('textarea').forEach((t) => (t.disabled = true));
    submit.remove();
    out.innerHTML = '';
    results.forEach((r, i) => {
      const box = el('div', undefined, 'fb rowcard ' + (r.ok ? 'full' : 'none'));
      box.append(el('b', `${r.ok ? '✔ Point earned' : '✘ No point yet'}: Part ${String.fromCharCode(65 + i)}`));
      if (r.notes.length) { const ul = el('ul'); r.notes.forEach((n) => ul.append(el('li', n))); box.append(ul); }
      box.append(collapsible('See a model answer', parts[i].model, !r.ok));
      out.append(box);
    });
    out.append(el('p', `Score: ${score}/${parts.length}. ${pass ? 'Passed!' : `You need ${c.passMark} to pass.`}`, 'total'));
    if (pass) sfx.good(); else sfx.bad();
    out.append(pass
      ? ui.button('Continue', () => { ui.close(); done({ passed: true, score, max: parts.length, tries: rec.attempts }); })
      : ui.button('Try new versions of the questions', () => runChallenge(ui, c, sources, done)));
  });
  ui.card.append(holder, submit, out);
}

const verbHelp = {
  identify: 'Name one correct, specific example.',
  describe: 'Give the relevant details of what happened; more than just naming it.',
  explain: 'Say how or why, using "because" or "so" to connect your evidence to the question.',
};
