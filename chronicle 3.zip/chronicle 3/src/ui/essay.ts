// Building blocks shared by the SAQ, LEQ and DBQ screens.
import type { UI } from './ui';
import type { Scorecard } from '../scoring/rubric';
import { wordCount } from '../scoring/text';

export const el = <K extends keyof HTMLElementTagNameMap>(tag: K, text?: string, cls?: string): HTMLElementTagNameMap[K] => {
  const e = document.createElement(tag);
  if (text) e.textContent = text;
  if (cls) e.className = cls;
  return e;
};

/** Textarea with a live word count, so students can see what "more than a phrase" means. */
export function textArea(value: string, placeholder: string, onInput: (v: string) => void, minWords = 0, rows = 3): HTMLElement {
  const wrap = el('div', undefined, 'ta');
  const t = el('textarea'); t.placeholder = placeholder; t.value = value; t.rows = rows; t.spellcheck = true;
  const count = el('div', '', 'wc');
  const upd = () => {
    const n = wordCount(t.value);
    count.textContent = minWords ? `${n} word${n === 1 ? '' : 's'} (aim for ${minWords}+)` : `${n} word${n === 1 ? '' : 's'}`;
    count.classList.toggle('ok', !minWords || n >= minWords);
  };
  t.oninput = () => { onInput(t.value); upd(); };
  upd();
  wrap.append(t, count);
  return wrap;
}

export function select(opts: [string, string][], val: string, on: (v: string) => void, label?: string): HTMLSelectElement {
  const s = el('select');
  opts.forEach(([v, t]) => { const o = el('option', t); o.value = v; s.append(o); });
  s.value = val; s.onchange = () => on(s.value);
  if (label) s.setAttribute('aria-label', label);
  return s;
}

export function labeled(text: string, ...kids: HTMLElement[]): HTMLElement {
  const wrap = el('div', undefined, 'field');
  wrap.append(el('label', text), ...kids);
  return wrap;
}

export function collapsible(summary: string, body: string | HTMLElement, open = false): HTMLDetailsElement {
  const d = el('details'); d.open = open;
  d.append(el('summary', summary));
  if (typeof body === 'string') body.split('\n\n').forEach((p) => d.append(el('p', p, 'meta')));
  else d.append(body);
  return d;
}

export function tip(text: string): HTMLElement { return el('p', text, 'tip'); }

/** Step tabs across the top of an essay; any step can be reopened. */
export function stepTabs(names: string[], current: number, go: (i: number) => void): HTMLElement {
  const row = el('div', undefined, 'tabs');
  names.forEach((n, i) => {
    const b = el('button', `${i + 1}. ${n}`, 'tab' + (i === current ? ' on' : ''));
    b.type = 'button'; b.onclick = () => go(i);
    if (i === current) b.setAttribute('aria-current', 'step');
    row.append(b);
  });
  return row;
}

/** Renders a rubric scorecard. `revise(step)` reopens the essay at that step. */
export function renderScorecard(ui: UI, sc: Scorecard, revise: (step: number) => void): HTMLElement {
  const box = el('div');
  box.append(el('p', `Score: ${sc.total}/${sc.max}`, 'total'));
  for (const r of sc.rows) {
    const mark = r.got === r.max ? '✔' : r.got ? '◐' : '✘';
    const item = el('div', undefined, 'fb rowcard ' + (r.got === r.max ? 'full' : r.got ? 'part' : 'none'));
    const head = el('div', undefined, 'rowhead');
    head.append(el('b', `${mark} ${r.label}: ${r.got}/${r.max}`));
    if (r.got < r.max) head.append(ui.button('Revise', () => revise(r.step), 'mini'));
    item.append(head);
    if (r.notes.length) { const ul = el('ul'); r.notes.forEach((n) => ul.append(el('li', n))); item.append(ul); }
    else item.append(el('div', 'Meets the rubric.', 'meta'));
    if (r.model) item.append(collapsible('See a model', r.model));
    box.append(item);
  }
  return box;
}

export function copyButton(ui: UI, text: () => string): HTMLButtonElement {
  const b = ui.button('Copy essay text', async () => {
    const t = text();
    try { await navigator.clipboard.writeText(t); b.textContent = 'Copied!'; }
    catch {
      const ta = el('textarea'); ta.value = t; ta.style.position = 'fixed'; ta.style.opacity = '0'; document.body.append(ta);
      ta.select(); try { document.execCommand('copy'); b.textContent = 'Copied!'; } catch { b.textContent = 'Copy failed'; } ta.remove();
    }
    window.setTimeout(() => (b.textContent = 'Copy essay text'), 1800);
  });
  return b;
}

export const disclaimer = (): HTMLElement =>
  el('p', 'Practice scoring is automatic and approximate. It checks for the moves the AP rubric rewards, but it cannot judge historical accuracy the way a teacher can. Copy your essay and share it with your teacher for real feedback.', 'meta small');
