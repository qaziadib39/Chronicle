import { cloudEnabled, restoreSession, signIn, signUp, signOut, onGuestProgress } from '../cloud';
import { state, resetProgress, hasProgress } from '../state';

const SUBJECTS = [
  { id: 'apwh', name: 'AP World History: Modern', on: true },
  { id: 'apush', name: 'AP U.S. History' }, { id: 'apeuro', name: 'AP European History' },
  { id: 'apgov', name: 'AP U.S. Government' }, { id: 'apbio', name: 'AP Biology' },
  { id: 'apcalc', name: 'AP Calculus AB' }, { id: 'appsych', name: 'AP Psychology' },
];

const BG = `<svg viewBox="0 0 960 600" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
<defs><linearGradient id="sk" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1c1233"/><stop offset=".45" stop-color="#6b2f5a"/><stop offset=".75" stop-color="#d9693f"/><stop offset="1" stop-color="#f3b45a"/></linearGradient>
<symbol id="cam" viewBox="0 0 66 46"><ellipse cx="28" cy="20" rx="18" ry="8"/><ellipse cx="22" cy="11" rx="5" ry="6"/><ellipse cx="34" cy="12" rx="5" ry="6"/><path d="M44 20 L53 5 L60 7 L57 13 L51 15 L49 24Z"/><rect x="12" y="24" width="3" height="20"/><rect x="20" y="24" width="3" height="20"/><rect x="34" y="24" width="3" height="20"/><rect x="42" y="24" width="3" height="20"/></symbol></defs>
<rect width="960" height="600" fill="url(#sk)"/>
<g fill="#fff">${Array.from({ length: 40 }, (_, i) => `<circle class="star" style="animation-delay:${(i % 7) * 0.4}s" cx="${(i * 97) % 960}" cy="${(i * 53) % 260}" r="${i % 3 ? 1 : 1.6}"/>`).join('')}</g>
<circle cx="700" cy="330" r="70" fill="#ffd98a" opacity=".92"/><circle cx="700" cy="330" r="96" fill="#ffd98a" opacity=".15"/>
<polygon points="0,420 140,380 320,415 520,370 720,410 960,375 960,600 0,600" fill="#8a3a4a"/>
<g class="caravan" fill="#1a1022"><use href="#cam" x="0" y="372" width="66" height="46"/><use href="#cam" x="78" y="378" width="60" height="42"/><use href="#cam" x="150" y="372" width="66" height="46"/></g>
<polygon points="0,470 200,430 420,470 640,425 960,465 960,600 0,600" fill="#5c2447"/>
<polygon points="0,530 260,500 520,535 760,505 960,530 960,600 0,600" fill="#2a1233"/></svg>`;

export async function showTitle(onPlay: () => Promise<void> | void): Promise<void> {
  const root = document.getElementById('title') as HTMLElement;
  root.style.display = 'flex';
  let panel: HTMLElement;
  let auth: HTMLElement;

  const add = <K extends keyof HTMLElementTagNameMap>(tag: K, text = '', parent: HTMLElement = panel) => {
    const e = document.createElement(tag); e.textContent = text; parent.append(e); return e;
  };

  // Signing in on a device that has someone's guest progress: let the student decide.
  onGuestProgress((xp) => new Promise<boolean>((resolve) => {
    auth.replaceChildren();
    add('p', `This device has guest progress (${xp} XP) that isn't saved to any account. Is it yours?`, auth).className = 'fb';
    const yes = add('button', "Yes, it's mine: add it to my account", auth);
    const no = add('button', 'No, start my account fresh', auth);
    yes.onclick = () => resolve(true);
    no.onclick = () => resolve(false);
  }));

  const start = async (fresh: boolean, btn: HTMLButtonElement) => {
    if (fresh) resetProgress();
    state.subject = 'apwh';
    btn.disabled = true; btn.textContent = 'Loading…';
    await onPlay();
    root.style.display = 'none';
  };

  const render = (msg = '') => {
    root.innerHTML = '';
    const bg = document.createElement('div'); bg.className = 'bg'; bg.innerHTML = BG; root.append(bg);
    panel = document.createElement('div'); panel.className = 'panel'; root.append(panel);
    add('h1', 'Chronicle');
    add('p', 'Learn history by investigating it.').className = 'tag';
    add('h3', 'Choose a subject');
    const subj = add('div');
    SUBJECTS.forEach((s) => {
      const b = add('button', s.on ? s.name : `${s.name} (coming soon)`, subj);
      b.className = 'subj' + (s.on ? ' on' : ''); b.disabled = !s.on;
    });

    auth = add('div'); auth.className = 'auth';
    if (!cloudEnabled) {
      add('p', 'Cloud save is not set up. Progress is saved in this browser only.', auth).className = 'meta';
    } else if (email) {
      add('p', `Signed in as ${email}. Progress syncs to the cloud.`, auth).className = 'meta';
      add('button', 'Sign out', auth).onclick = async () => { await signOut(); email = null; render('Signed out. This device is ready for the next student.'); };
    } else {
      const form = add('form', '', auth);
      form.onsubmit = (e) => e.preventDefault();
      const em = add('input', '', form); em.type = 'email'; em.placeholder = 'Email'; em.autocomplete = 'username'; em.setAttribute('aria-label', 'Email');
      const pw = add('input', '', form); pw.type = 'password'; pw.placeholder = 'Password (6+ characters)'; pw.autocomplete = 'current-password'; pw.setAttribute('aria-label', 'Password');
      const go = (fn: typeof signIn, b: HTMLButtonElement) => async () => {
        b.disabled = true;
        const err = await fn(em.value.trim(), pw.value);
        if (err) { render(err); return; }
        email = await restoreSession(); render();
      };
      const si = add('button', 'Sign in', form); si.type = 'submit'; si.onclick = go(signIn, si);
      const su = add('button', 'Create account', form); su.type = 'button'; su.onclick = go(signUp, su);
      add('p', 'Or just play as a guest below. On a shared computer, sign out when you finish.', auth).className = 'meta';
    }
    if (msg) add('p', msg, auth).className = 'fb';

    const play = add('div'); play.className = 'play';
    if (hasProgress()) {
      const cont = add('button', 'Continue', play); cont.onclick = () => start(false, cont);
      const ng = add('button', 'New game', play);
      ng.onclick = () => { if (confirm('Erase your progress and start over?')) void start(true, ng); };
    } else {
      const st = add('button', 'Start', play); st.onclick = () => start(false, st);
    }
  };

  let email: string | null = null;
  render('Checking for a saved game…');
  email = await restoreSession();
  render();
}
