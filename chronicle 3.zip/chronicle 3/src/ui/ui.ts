import { state, level, XP_PER_LEVEL } from '../state';
import { AREAS, rankTitle } from '../data/content';
import { QUESTS, questDone } from '../quests';
import { sfx } from '../audio';
import type { Source } from '../data/content';

const $ = (id: string) => document.getElementById(id) as HTMLElement;
const reducedMotion = () => window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;

export class UI {
  modal = $('modal');
  card = $('card');
  closedAt = 0;
  keyHandler: ((e: KeyboardEvent) => void) | null = null;
  typer: number | undefined;
  /** Set by the game scene: pause movement and stop it from swallowing keystrokes while a panel is open. */
  onOpen: (() => void) | null = null;
  onClose: (() => void) | null = null;

  constructor() {
    window.addEventListener('chronicle:notice', (e) => this.toast((e as CustomEvent<string>).detail));
  }

  isOpen(): boolean { return this.modal.style.display === 'flex'; }
  open(): void {
    const was = this.isOpen();
    this.modal.style.display = 'flex';
    if (!was) this.onOpen?.();
  }

  close(): void {
    window.clearInterval(this.typer);
    this.modal.style.display = 'none';
    this.card.innerHTML = ''; this.card.className = '';
    this.closedAt = performance.now();
    this.clearKeys();
    this.onClose?.();
  }

  clearKeys(): void {
    if (this.keyHandler) { document.removeEventListener('keydown', this.keyHandler); this.keyHandler = null; }
  }

  /** Keyboard shortcut for the current panel. Ignored while typing in a text field. */
  onKeys(keys: string[], fn: () => void): void {
    this.clearKeys();
    this.keyHandler = (e) => {
      const t = e.target as HTMLElement | null;
      if (t && /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName)) return;
      // A focused button already clicks itself on Space/Enter; don't fire twice.
      if (t?.tagName === 'BUTTON' && (e.key === ' ' || e.key === 'Enter')) return;
      if (keys.includes(e.key)) { e.preventDefault(); fn(); }
    };
    document.addEventListener('keydown', this.keyHandler);
  }
  onAdvance(fn: () => void): void { this.onKeys(['e', 'E', ' ', 'Enter', 'Escape'], fn); }

  button(label: string, fn: () => void, cls = ''): HTMLButtonElement {
    const b = document.createElement('button');
    b.type = 'button';
    b.textContent = label; b.className = cls; b.onclick = () => { sfx.click(); fn(); };
    return b;
  }

  showDialogue(name: string, lines: string[], done: () => void, portrait?: string): void {
    let i = 0;
    const render = () => {
      window.clearInterval(this.typer);
      this.card.innerHTML = ''; this.card.className = 'dlgcard';
      const wrap = document.createElement('div'); wrap.className = 'dlg';
      if (portrait) { const img = document.createElement('img'); img.src = portrait; img.alt = ''; wrap.append(img); }
      const box = document.createElement('div'); box.style.flex = '1';
      const h = document.createElement('h3'); h.textContent = name;
      const p = document.createElement('p'); p.setAttribute('aria-live', 'polite');
      box.append(h, p); wrap.append(box);
      const full = lines[i], last = i === lines.length - 1;
      let n = 0, typing = !reducedMotion();
      const next = () => {
        if (typing) { window.clearInterval(this.typer); p.textContent = full; typing = false; return; }
        if (last) { this.close(); done(); } else { i++; render(); }
      };
      if (typing) {
        this.typer = window.setInterval(() => {
          n += 2; p.textContent = full.slice(0, n);
          if (n >= full.length) { window.clearInterval(this.typer); typing = false; }
        }, 16);
      } else p.textContent = full;
      const btn = this.button(last ? 'Close' : 'Next ▸', next);
      this.card.append(wrap, btn);
      this.onAdvance(next);
      btn.focus({ preventScroll: true });
    };
    this.open(); render();
  }

  showSource(s: Source, done: () => void): void {
    this.card.innerHTML = ''; this.card.className = 'parch';
    const tag = document.createElement('div'); tag.className = 'stamp'; tag.textContent = 'PRIMARY SOURCE';
    const h = document.createElement('h3'); h.textContent = s.title;
    const meta = document.createElement('div'); meta.className = 'meta';
    meta.textContent = `${s.kind} • ${s.author} • ${s.place}, ${s.date}`;
    const q = document.createElement('blockquote'); q.textContent = s.text;
    const pov = document.createElement('p'); pov.className = 'pov';
    const b = document.createElement('b'); b.textContent = 'Point of view: ';
    pov.append(b, document.createTextNode(s.pov));
    const close = () => { this.close(); done(); };
    this.card.append(tag, h, meta, q, pov);
    if (s.note) {
      const note = document.createElement('p'); note.className = 'note';
      const nb = document.createElement('b'); nb.textContent = 'History note: ';
      note.append(nb, document.createTextNode(s.note));
      this.card.append(note);
    }
    const btn = this.button('Close', close);
    this.card.append(btn);
    this.open(); this.onAdvance(close);
    btn.focus({ preventScroll: true });
  }

  renderHud(): void {
    const into = state.xp % XP_PER_LEVEL;
    const area = AREAS[state.area];
    const active = QUESTS.find((q) => !questDone(q));
    const hud = $('hud');
    hud.replaceChildren();
    const h = document.createElement('h4'); h.textContent = rankTitle();
    const sp = document.createElement('span'); sp.textContent = `Lv ${level()} • ${state.xp} XP`; h.append(sp);
    const bar = document.createElement('div'); bar.id = 'xpbar';
    const fill = document.createElement('div'); fill.id = 'xpfill'; fill.style.width = `${(into / XP_PER_LEVEL) * 100}%`; bar.append(fill);
    const where = document.createElement('div'); where.className = 'where'; where.textContent = `📍 ${area.name}`;
    const sub = document.createElement('div'); sub.className = 'sub';
    sub.textContent = `Quests ${QUESTS.filter(questDone).length}/${QUESTS.length} • J Journal • M Sound`;
    hud.append(h, bar, where, sub);
    if (active) {
      const q = document.createElement('div'); q.className = 'q'; q.textContent = `◇ ${active.title}`;
      const ul = document.createElement('ul');
      for (const o of active.objectives) {
        const li = document.createElement('li'); const d = o.done();
        li.className = d ? 'done' : ''; li.textContent = `${d ? '☑' : '☐'} ${o.text}`; ul.append(li);
      }
      hud.append(q, ul);
    } else {
      const q = document.createElement('div'); q.className = 'q done'; q.textContent = '✔ Chapter complete!'; hud.append(q);
    }
  }

  prompt(text: string | null): void {
    const el = $('prompt');
    el.style.display = text ? 'block' : 'none';
    if (text) el.textContent = text;
  }

  toast(msg: string): void {
    const el = $('toast'); el.textContent = msg; el.style.display = 'block';
    el.classList.remove('pop'); void el.offsetWidth; el.classList.add('pop');
    window.clearTimeout((el as unknown as { _t?: number })._t);
    (el as unknown as { _t?: number })._t = window.setTimeout(() => (el.style.display = 'none'), 3200);
  }
}
