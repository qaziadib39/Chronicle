import type { UI } from './ui';
import type { LeqChallenge } from '../data/content';
import type { Done } from './challenges';
import { state, saveSoon, recordAttempt } from '../state';
import { submitAttempt } from '../cloud';
import { sfx } from '../audio';
import { normalizeLeqDraft, scoreLeq, leqEssay, type Empire, type LeqDraft } from '../scoring/leq';
import { el, textArea, select, labeled, collapsible, tip, stepTabs, renderScorecard, copyButton, disclaimer } from './essay';

const STEPS = ['Thesis', 'Context', 'Evidence', 'Comparison'];

export function leq(ui: UI, c: LeqChallenge, done: Done): void {
  const d: LeqDraft = normalizeLeqDraft(state.drafts[c.id]);
  state.drafts[c.id] = d;
  const changed = () => saveSoon();
  const A = c.subjects.a.label, B = c.subjects.b.label;
  let step = 0;

  // A long essay has no documents. These reminders point back to what the student read in the bazaar.
  const notes = () => collapsible('Memory jog (what you read in the bazaar)', [
    'Registry entry (Ottoman): Greek, Armenian and Jewish communities kept their own courts and schools in return for a special tax.',
    "Venetian envoy (Ottoman): the sultan's soldiers were paid from the treasury as a standing army, with cannon that broke old walls.",
    'Court chronicle (Mughal): the emperor appointed officials by merit whatever their faith, paid them with land revenue for military service, and hosted debates among religions.',
    'An LEQ is scored on your own knowledge, so go beyond these: name specific institutions, policies, rulers, and buildings.',
  ].join('\n\n'));

  const frame = (hint: string): HTMLElement => {
    ui.clearKeys(); ui.card.innerHTML = ''; ui.card.className = 'essay';
    ui.card.append(el('h3', c.title), el('p', c.prompt, 'prompt'), stepTabs(STEPS, step, go), notes(), tip(hint));
    const body = el('div'); ui.card.append(body);
    return body;
  };
  const go = (i: number) => { step = i; render(); ui.card.scrollTop = 0; };
  const nav = () => {
    const row = el('div', undefined, 'nav');
    if (step > 0) row.append(ui.button('◂ Back', () => go(step - 1)));
    if (step < STEPS.length - 1) row.append(ui.button('Next ▸', () => go(step + 1)));
    row.append(ui.button('Score my essay', score, step === STEPS.length - 1 ? '' : 'ghost'));
    row.append(ui.button('Leave (draft is saved)', () => { ui.close(); done({ passed: false, score: 0, max: 6, tries: 0 }); }, 'ghost'));
    ui.card.append(row);
  };

  const thesis = () => {
    const body = frame(`This is a comparison prompt. A strong thesis names both empires, makes a claim about how their methods were similar and/or different, and previews which methods you will compare.`);
    body.append(labeled('Your thesis', textArea(d.thesis, `Both the ${A} and ${B} empires…, but… while…`, (v) => { d.thesis = v; changed(); }, 15, 3)));
    nav();
  };

  const context = () => {
    const body = frame('Describe the broader developments that set the stage: where these empires came from and what made large land-based empires possible in this era. More than a phrase.');
    body.append(labeled('Contextualization', textArea(d.context, 'Both empires grew out of… By the 1400s, …', (v) => { d.context = v; changed(); }, 25, 4)));
    nav();
  };

  const evidence = () => {
    const body = frame(`Give at least two specific examples, and cover both empires. "Religious tolerance" is too general; "Akbar's policy of sulh-i kul" is specific. For each, explain how it helped the empire legitimize or consolidate power.`);
    const opts: [Empire, string][] = [['', '(which empire?)'], ['a', A], ['b', B], ['both', 'Both']];
    d.evidence.forEach((e, i) => {
      const row = el('div', undefined, 'row');
      const name = el('input'); name.type = 'text'; name.value = e.name; name.placeholder = 'Specific example (e.g. the devshirme)';
      name.setAttribute('aria-label', `Example ${i + 1}`);
      name.oninput = () => { e.name = name.value; changed(); };
      row.append(el('b', `Example ${i + 1}${i >= 2 ? ' (optional)' : ''}`),
        select(opts, e.empire, (v) => { e.empire = v as Empire; changed(); }, `Example ${i + 1} empire`), name,
        textArea(e.explain, 'How did it help the ruler legitimize or consolidate power?', (v) => { e.explain = v; changed(); }, 12, 2));
      body.append(row);
    });
    nav();
  };

  const comparison = () => {
    const body = frame('Use comparison to frame your argument. Explaining one similarity or difference earns the reasoning point. Explaining both, and why each existed, shows the complex understanding that earns the final point.');
    body.append(
      labeled('A key similarity, and why it existed', textArea(d.similarity, `Both the ${A}s and the ${B}s… because…`, (v) => { d.similarity = v; changed(); }, 18, 3)),
      labeled('A key difference, and why it existed', textArea(d.difference, `While the ${A}s…, the ${B}s… because…`, (v) => { d.difference = v; changed(); }, 18, 3)),
    );
    nav();
  };

  const score = () => {
    const sc = scoreLeq(c, d);
    const rec = recordAttempt(c.id, sc.total, sc.max, sc.pass);
    void submitAttempt(c.id, sc.total, sc.max, { essay: leqEssay(c, d), draft: d });
    ui.clearKeys(); ui.card.innerHTML = ''; ui.card.className = 'essay';
    ui.card.append(el('h3', 'Essay scorecard'), el('p', c.prompt, 'prompt'), renderScorecard(ui, sc, go));
    ui.card.append(el('p', sc.pass ? `Passed! (${c.passMark} points needed)` : `You need ${c.passMark} points to pass. Use the Revise buttons; your draft is saved.`, 'total'), disclaimer());
    if (sc.pass) sfx.good(); else sfx.bad();
    const row = el('div', undefined, 'nav');
    if (sc.pass) row.append(ui.button('Continue', () => { delete state.drafts[c.id]; saveSoon(); ui.close(); done({ passed: true, score: sc.total, max: sc.max, tries: rec.attempts }); }));
    row.append(ui.button('Back to my essay', () => go(0), sc.pass ? 'ghost' : ''), copyButton(ui, () => leqEssay(c, d)));
    if (!sc.pass) row.append(ui.button('Leave (draft is saved)', () => { ui.close(); done({ passed: false, score: sc.total, max: sc.max, tries: rec.attempts }); }, 'ghost'));
    ui.card.append(row);
    ui.card.scrollTop = 0;
  };

  const steps = [thesis, context, evidence, comparison];
  const render = () => steps[step]();
  ui.open(); render();
}
