import { state, level } from '../state';
import { SOURCES, RANKS, rankIndex, CHALLENGES, CHALLENGE_ORDER } from '../data/content';
import type { UI } from './ui';
import { el } from './essay';

type Tab = 'evidence' | 'ranks' | 'report';

export function showJournal(ui: UI, tab: Tab = 'evidence'): void {
  ui.clearKeys();
  const card = ui.card;
  card.innerHTML = ''; card.className = '';
  const tabs = el('div', undefined, 'tabs');
  ([['evidence', 'Evidence'], ['ranks', 'Ranks'], ['report', 'Progress report']] as [Tab, string][]).forEach(([t, label]) => {
    const b = ui.button(label, () => showJournal(ui, t), 'tab' + (t === tab ? ' on' : ''));
    tabs.append(b);
  });
  card.append(el('h3', "Historian's Journal"), tabs);
  const body = el('div');

  if (tab === 'evidence') {
    const total = Object.keys(SOURCES).length;
    body.append(el('p', `Sources collected: ${state.examined.length}/${total}`));
    state.examined.forEach((id) => {
      const s = SOURCES[id]; if (!s) return;
      body.append(ui.button(`${s.title} (${s.date})`, () => ui.showSource(s, () => showJournal(ui, 'evidence')), 'opt'));
    });
    if (!state.examined.length) body.append(el('p', 'Nothing yet. Examine artifacts in the world to collect evidence.', 'meta'));
  } else if (tab === 'ranks') {
    const cur = rankIndex();
    body.append(el('p', `Level ${level()} • ${state.xp} XP. Ranks are earned by passing challenges.`, 'meta'));
    RANKS.forEach((r, i) => {
      body.append(el('div', `${i <= cur ? '★' : '☆'} ${r.title}: ${r.how}${i === cur ? ' (current)' : ''}`, 'meta'));
    });
  } else {
    body.append(el('p', 'Your attempts and best scores. Show this to your teacher or mentor.', 'meta'));
    const table = el('table', undefined, 'report');
    const head = el('tr');
    ['Challenge', 'Status', 'Attempts', 'Best'].forEach((h) => head.append(el('th', h)));
    table.append(head);
    for (const id of CHALLENGE_ORDER) {
      const c = CHALLENGES[id], r = state.records[id];
      const tr = el('tr');
      const status = state.passed.includes(id) ? 'Passed' : r ? 'In progress' : state.drafts[id] ? 'Draft saved' : 'Not started';
      [c.title, status, String(r?.attempts ?? 0), r ? `${r.best}/${r.max}` : '–'].forEach((v) => tr.append(el('td', v)));
      table.append(tr);
    }
    body.append(table);
  }
  const close = ui.button('Close', () => ui.close());
  card.append(body, close);
  ui.open();
  ui.onKeys(['j', 'J', 'Escape', 'e', 'E'], () => ui.close());
}
