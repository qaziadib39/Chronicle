import type { UI } from './ui';
import type { DbqChallenge, Source } from '../data/content';
import type { Done } from './challenges';
import { state, saveSoon, recordAttempt } from '../state';
import { submitAttempt } from '../cloud';
import { sfx } from '../audio';
import {
  normalizeDbqDraft, scoreDbq, thesisDraft, dbqEssay, describeUse, HIPP_LABEL, type DbqDraft, type DocUse, type Hipp,
} from '../scoring/dbq';
import { el, textArea, select, labeled, collapsible, tip, stepTabs, renderScorecard, copyButton, disclaimer } from './essay';

const STEPS = ['Thesis', 'Context', 'Evidence', 'Sourcing', 'Complexity'];

export function dbq(ui: UI, c: DbqChallenge, sources: Source[], done: Done): void {
  const d: DbqDraft = normalizeDbqDraft(state.drafts[c.id]);
  state.drafts[c.id] = d;
  const changed = () => saveSoon();
  let step = 0;
  const docNo = (id: string) => `Doc ${sources.findIndex((s) => s.id === id) + 1}`;
  const docOpts = (blank: string): [string, string][] => [['', blank], ...sources.map((s) => [s.id, `${docNo(s.id)}: ${s.title}`] as [string, string])];

  const bank = (open: boolean) => {
    const box = el('div');
    sources.forEach((s, i) => {
      const p = el('div', undefined, 'srcline');
      p.append(el('b', `Doc ${i + 1}. `), el('span', `Source: ${s.author}, ${s.kind.toLowerCase()}, ${s.place}, ${s.date}. `), el('span', `"${s.text}"`));
      box.append(p);
    });
    return collapsible('Document set (7 documents)', box, open);
  };

  const frame = (hint: string, bankOpen = false): HTMLElement => {
    ui.clearKeys(); ui.card.innerHTML = ''; ui.card.className = 'essay';
    ui.card.append(el('h3', c.title), el('p', c.prompt, 'prompt'), stepTabs(STEPS, step, go), bank(bankOpen), tip(hint));
    const body = el('div'); ui.card.append(body);
    return body;
  };
  const go = (i: number) => { step = i; render(); ui.card.scrollTop = 0; };
  const nav = () => {
    const row = el('div', undefined, 'nav');
    if (step > 0) row.append(ui.button('◂ Back', () => go(step - 1)));
    if (step < STEPS.length - 1) row.append(ui.button('Next ▸', () => go(step + 1)));
    row.append(ui.button('Score my essay', score, step === STEPS.length - 1 ? '' : 'ghost'));
    row.append(ui.button('Leave (draft is saved)', () => { ui.close(); done({ passed: false, score: 0, max: 7, tries: 0 }); }, 'ghost'));
    ui.card.append(row);
  };

  const thesis = () => {
    const body = frame('A thesis makes a claim that answers "to what extent" and previews a line of reasoning. Check that your two reasons actually fit the stance you chose.');
    const rOpts: [string, string][] = [['', '(choose a reason)'], ...c.reasons.map((r) => [r.id, r.text] as [string, string])];
    const fill = ui.button('Fill in a draft from my choices', () => {
      const t = thesisDraft(c, d);
      if (t) { d.thesis = t; changed(); render(); }
    }, 'ghost');
    body.append(
      labeled('Stance', select(c.stances.map((s, i) => [String(i), s] as [string, string]), String(d.stance), (v) => { d.stance = Number(v); changed(); }, 'Stance')),
      labeled('Reason 1', select(rOpts, d.r1, (v) => { d.r1 = v; changed(); }, 'Reason 1')),
      labeled('Reason 2', select(rOpts, d.r2, (v) => { d.r2 = v; changed(); }, 'Reason 2')),
      fill,
      labeled('Your thesis (put it in your own words)', textArea(d.thesis, 'To a ___ extent, rulers and states shaped trade and exchange because… and because…', (v) => { d.thesis = v; changed(); }, 15, 3)),
    );
    nav();
  };

  const context = () => {
    const body = frame('Describe the bigger picture: developments before or during 1200 to 1600 that help explain the prompt (for example, earlier empires and trade networks, the Mongol conquests, or the rise of gunpowder empires). It must be more than a phrase.');
    body.append(labeled('Contextualization', textArea(d.context, 'Before 1200, … After 1200, …', (v) => { d.context = v; changed(); }, 25, 4)));
    nav();
  };

  const evidence = () => {
    const body = frame('For each document you use, choose which part of your argument it supports, then describe what it says in your own words. Copying the document\'s words does not count. 3 described documents earn 1 point; 4 used to support your argument earn 2.');
    const useOpts: [DocUse, string][] = (['', 'r1', 'r2', 'counter'] as DocUse[]).map((u) => [u, describeUse(c, d, u)]);
    sources.forEach((s) => {
      const u = (d.uses[s.id] ??= { use: '', desc: '' });
      const row = el('div', undefined, 'row');
      row.append(el('b', `${docNo(s.id)}: ${s.title}`), el('div', `${s.author}, ${s.date}: "${s.text}"`, 'quote'));
      row.append(select(useOpts, u.use, (v) => { u.use = v as DocUse; changed(); render(); }, `${docNo(s.id)} use`));
      if (u.use) row.append(textArea(u.desc, `In your own words, what does ${docNo(s.id)} show?`, (v) => { u.desc = v; changed(); }, 8, 2));
      body.append(row);
    });
    const used = sources.filter((s) => d.uses[s.id]?.use).length;
    body.append(el('p', `Documents in use: ${used}/7`, 'meta'));
    body.append(labeled('Evidence beyond the documents: one specific person, event, or development NOT in the documents, and how it supports your argument',
      textArea(d.outside, 'e.g. The Pax Mongolica… This shows…', (v) => { d.outside = v; changed(); }, 12, 3)));
    nav();
  };

  const sourcing = () => {
    const body = frame('Pick two different documents. For each, explain how or why its historical situation, intended audience, purpose, or point of view affects how you can use it, for example, whether it is reliable, exaggerated, or only useful for some questions.', true);
    const hippOpts = Object.entries(HIPP_LABEL) as [Hipp, string][];
    d.sourcing.forEach((slot, i) => {
      const row = el('div', undefined, 'row');
      row.append(el('b', `Sourcing ${i + 1}`),
        labeled('Document', select(docOpts('(choose a document)'), slot.doc, (v) => { slot.doc = v; changed(); }, `Sourcing ${i + 1} document`)),
        labeled('HIPP element', select(hippOpts, slot.hipp, (v) => { slot.hipp = v as Hipp; changed(); }, `Sourcing ${i + 1} element`)),
        textArea(slot.text, 'Because the author was… / Because it was written for…, it may…', (v) => { slot.text = v; changed(); }, 15, 3));
      body.append(row);
    });
    nav();
  };

  const complexity = () => {
    const body = frame('Show a complex understanding by qualifying your argument: choose a document that points the other way, explain what it shows, and explain how it limits or modifies your thesis. Two or more sentences.', true);
    body.append(
      labeled('Document that complicates your argument', select(docOpts('(choose a document)'), d.counterDoc, (v) => { d.counterDoc = v; changed(); }, 'Counter document')),
      textArea(d.counterText, 'However, Doc _ complicates this argument, because… This suggests…', (v) => { d.counterText = v; changed(); }, 30, 4),
    );
    nav();
  };

  const score = () => {
    const sc = scoreDbq(c, sources, d);
    const rec = recordAttempt(c.id, sc.total, sc.max, sc.pass);
    void submitAttempt(c.id, sc.total, sc.max, { essay: dbqEssay(c, sources, d), draft: d });
    ui.clearKeys(); ui.card.innerHTML = ''; ui.card.className = 'essay';
    ui.card.append(el('h3', 'Essay scorecard'), el('p', c.prompt, 'prompt'));
    ui.card.append(renderScorecard(ui, sc, go));
    ui.card.append(el('p', sc.pass ? `Passed! (${c.passMark} points needed)` : `You need ${c.passMark} points to pass. Use the Revise buttons to improve any row; your draft is saved.`, 'total'));
    ui.card.append(disclaimer());
    if (sc.pass) sfx.good(); else sfx.bad();
    const row = el('div', undefined, 'nav');
    if (sc.pass) row.append(ui.button('Continue', () => { delete state.drafts[c.id]; saveSoon(); ui.close(); done({ passed: true, score: sc.total, max: sc.max, tries: rec.attempts }); }));
    row.append(ui.button('Back to my essay', () => go(0), sc.pass ? 'ghost' : ''), copyButton(ui, () => dbqEssay(c, sources, d)));
    if (!sc.pass) row.append(ui.button('Leave (draft is saved)', () => { ui.close(); done({ passed: false, score: sc.total, max: sc.max, tries: rec.attempts }); }, 'ghost'));
    ui.card.append(row);
    ui.card.scrollTop = 0;
  };

  const steps = [thesis, context, evidence, sourcing, complexity];
  const render = () => steps[step]();
  ui.open(); render();
}
