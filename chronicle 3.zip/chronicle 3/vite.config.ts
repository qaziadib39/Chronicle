import { defineConfig } from 'vite';

export default defineConfig({
  base: './',
  // Phaser itself is ~1.2 MB minified; it is loaded on demand after the title screen.
  build: { chunkSizeWarningLimit: 1600 },
  test: { environment: 'node' },
} as Parameters<typeof defineConfig>[0]);
