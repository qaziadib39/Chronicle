# Chronicle: educational RPG (prototype)

A 2D top-down browser RPG for AP World History: Modern, built by MORE students with **Phaser 3 + TypeScript + Vite**.

## Run
```bash
npm install
npm run dev        # http://localhost:5173
npm test           # scoring + cloud-save unit tests
npm run build      # type-check + tests + production build into dist/
```
Deploy `dist/` to GitHub Pages, Netlify, or Vercel (`base: './'` is already set).

Reset progress: run `localStorage.removeItem('chronicle-save-v1')` in the browser console, or use **New game** on the title screen.

## What's in the game
Three areas (Silk Road crossroads c. 1290, Indian Ocean port c. 1450, imperial bazaar c. 1550), 9 primary sources, and 5 challenges:

| # | Challenge | Who | Skill |
|---|---|---|---|
| c1 | Evidence challenge (multiple choice) | Omar | Corroborating sources |
| c2 | Evidence tagging | Captain Ismail | Supports / contradicts / not relevant |
| c3 | Short-answer exam (SAQ) | Yusuf | Identify / describe / explain |
| c5 | Comparison essay (LEQ) | Rahim | Comparison, own-knowledge evidence |
| c4 | The Great Essay (DBQ) | Selim | Full 7-point DBQ |

Controls: WASD/arrows, E or Space to interact, J journal, M sound, Esc closes panels. On tablets and phones an on-screen pad appears automatically.

## Project structure
- `src/data/content.ts`: all NPCs, sources, challenges, ranks. `src/data/types.ts`: the content types.
- `src/scoring/`: **pure scoring functions** for SAQ, LEQ and DBQ (no game or DOM code), with tests in `scoring.test.ts`.
- `src/ui/`: the HUD and dialogue (`ui.ts`), challenge screens (`challenges.ts`, `dbq.ts`, `leq.ts`), shared essay widgets (`essay.ts`), journal and progress report (`journal.ts`), title screen (`title.ts`).
- `src/state.ts`: save data, migration of old saves, attempt records, essay drafts.
- `src/cloud.ts`: Supabase sign-in, cloud saves, and essay submissions. Tests in `cloud.test.ts`.
- `src/scenes/GameScene.ts`: world, movement, interaction. `src/touch.ts`: touch controls.
- `src/gfx/`: all art is generated in code (no asset files).

## How scoring works
Scoring follows the current College Board rubrics. It is automatic and approximate: it checks for the moves the rubric rewards, and students are told to share their essay with a teacher. Every scorecard row explains what was missing, links back to the step to revise, and has a model answer.

**SAQ (1 point per part).** The task verb sets the bar. *Identify* needs a correct specific idea; *describe* needs more detail; *explain* also needs a causal link ("because", "so", "led to"). Answers must read as sentences (keyword lists fail), add ideas beyond the question, and meet a minimum length. A retry draws new versions of the questions, so copying the model answers from a failed attempt doesn't work.

**DBQ (7 points, pass at 4).**
- *Thesis (1):* the stance and both reasons must agree. For example, "to a great extent" can't rest on "monsoon winds mattered more than rulers"; "moderate" needs one reason on each side. The written thesis must make a judgment of extent, set up reasoning, and go beyond restating the prompt.
- *Context (1):* 25+ words, at least one specific development, placed in time.
- *Document evidence (2):* 1 point for accurately describing 3 documents; 2 points for using 4 to support the argument. Each description must use the document's actual content, in the student's own words (copying 7+ words in a row from the document doesn't count), and be tied to a reason it really supports, or used as a counterpoint that cuts against the stance.
- *Outside evidence (1):* a specific item not in the documents, explained. Items that are really document content (Zheng He, Swahili, Akbar, jizya) get a specific explanation of why they don't count.
- *Sourcing (1):* HIPP explained for **two** different documents, naming the element and its effect on reliability or usefulness.
- *Complexity (1):* a document that genuinely points the other way, with a 2+ sentence explanation of how it qualifies the thesis.

**LEQ (6 points, pass at 3).** The thesis must name both empires, make a comparative claim and name methods. Context works as in the DBQ. Evidence: 1 point for two specific examples; 2 points for two examples correctly attributed and explained, covering both empires. Vague terms like "religious tolerance" or "the army" are flagged with a suggestion of what specific means. Reasoning: 1 point for one fully explained similarity or difference; complexity for both, each with a reason why.

To add or change content, edit the word lists in `content.ts` (`facts`, `who`, `concepts`, `context`, `outside`, `evidence`). A term ending in `*` is a prefix (`tax*` matches taxes, taxed); everything else must match as a whole word or phrase. Add a test in `scoring.test.ts` for any new essay so a strong answer still earns full credit.

**XP and ranks.** Guessing costs XP (multiple choice and tagging lose 15 XP per wrong try), SAQ XP scales with the score, and essays earn XP per rubric point. Ranks (Curious Visitor through Master Historian) are earned by passing challenges, so the top rank marks the end of the chapter.

## Cloud saves and teacher review (optional)
1. In Supabase > SQL Editor, run `supabase/schema.sql` (safe to re-run when upgrading).
2. Copy `.env.example` to `.env`, fill in the two values from Project Settings > API, restart `npm run dev`.

Without these values the game runs in guest mode (saves in the browser only).

Built for shared classroom computers:
- **Sign out** saves, then clears the device for the next student.
- A save that belongs to another student is never merged into a new account. If a session expired without signing out, the device is cleared on the next visit.
- If a student signs in on a device with guest progress, they're asked whether it's theirs.
- If the same student has newer progress on the device than in the cloud (they played offline), the newer copy wins.

Every SAQ, LEQ and DBQ submission is stored with the full answer text in the `submissions` table. Teachers can read it in the Supabase Table Editor, or through the `teacher.recent_submissions` view (it includes student emails and is not exposed to students). Scores are computed in the browser, so treat them as practice data and use the essay text for grading. Students can also copy their essay text from any scorecard, and the journal's **Progress report** tab lists attempts and best scores.

## Content notes
Sources are **illustrative**, written for gameplay and modeled on real records. Each source has a history note naming the real record it imitates (Ibn Battuta on Kilwa, the 1431 Zheng He inscriptions, the Akbarnama, Venetian relazioni, the Ilkhanate's 1294 paper-money failure). Replace them with real, cited excerpts before graded classroom use.

## Changelog
### v0.4
- **Fixed:** students couldn't type W, A, S, D, E, J, M or space into answers (Phaser was capturing those keys globally). Keys are now released whenever a panel is open.
- **Fixed:** the quest tracker froze after the first area (`visited_port` and `visited_bazaar` were never set). Old saves are repaired on load.
- **Fixed:** shared-computer save mixing (see above).
- Rebuilt SAQ and DBQ scoring to the current rubrics; added the LEQ (Rahim, Ottoman vs. Mughal comparison).
- Essay drafts save as you type and survive leaving. Step tabs, live word counts, Revise buttons, model answers, copy-essay button. Essays open full-window.
- Tagging gives hints instead of answers on a wrong try and keeps correct tags on retry.
- History fixes: Tabriz paper money (1294) now matches the record; the Mughal chronicle is set in Lahore with the debates at Fatehpur Sikri; the port's Chinese captain (an anachronism after 1433) is now Captain Ismail, a Gujarati shipmaster; every source has a history note.
- Ranks by milestone, progress report in the journal, touch controls, larger text, Esc and J close panels, reduced-motion support, focus outlines.
- The game engine loads after the title screen (first download about 8 KB instead of 1.5 MB).
- Supabase: `submissions` table, teacher view, server-side timestamp and size and XP limits.
- 27 unit tests (scoring and cloud saves); `npm run build` runs them.

### v0.3
Generated graphics, third unit (imperial bazaar), DBQ challenge, typewriter dialogue, sound effects.

### v0.2
Title screen, second area, tagging and SAQ challenges, journal, Supabase cloud saves.
