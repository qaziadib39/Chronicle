const KEY = 'chronicle-save-v1';

export interface State {
  xp: number;
  flags: Record<string, boolean>;
  examined: string[];
  passed: string[];
}

const fresh = (): State => ({ xp: 0, flags: {}, examined: [], passed: [] });

function load(): State {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return { ...fresh(), ...JSON.parse(raw) };
  } catch { /* ignore */ }
  return fresh();
}

export const state: State = load();

export function save(): void {
  try { localStorage.setItem(KEY, JSON.stringify(state)); } catch { /* ignore */ }
}

export function resetProgress(): void {
  Object.assign(state, fresh());
  save();
}

export const XP_PER_LEVEL = 50;
export const level = (): number => Math.floor(state.xp / XP_PER_LEVEL) + 1;
export function addXp(n: number): void { state.xp += n; save(); }
