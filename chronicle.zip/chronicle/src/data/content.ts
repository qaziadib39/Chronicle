// All educational content lives here so it can later move to Supabase/JSON.
// NOTE: sources below are ILLUSTRATIVE, written for gameplay. Replace with real,
// cited primary sources before using in a classroom.
import { state } from '../state';

export interface Source {
  id: string; title: string; author: string; date: string; place: string;
  kind: string; text: string; pov: string;
}
export interface Challenge {
  id: string; prompt: string; sourceIds: string[]; options: string[];
  correct: number; feedback: string[];
}
export interface Npc {
  id: string; name: string; x: number; y: number; color: number;
  lines: () => string[];
}
export interface ObjectDef { id: string; label: string; x: number; y: number; sourceId: string }

export const SOURCES: Record<string, Source> = {
  ledger: {
    id: 'ledger', title: "Merchant's Ledger (illustrative)", author: 'An unnamed Persian merchant',
    date: 'c. 1290', place: 'Tabriz', kind: 'Commercial record',
    text: 'Received: 40 bolts silk from the east, 12 chests porcelain, pepper by the sack. Paid: tolls at three posts, each recorded with a Mongol stamp. Sold: paper notes accepted at the caravanserai without dispute.',
    pov: 'A trader recording business; interested in profit and safe passage, not in praising rulers.',
  },
  coin: {
    id: 'coin', title: 'Silver Coin (illustrative)', author: 'Mint of a Mongol successor state',
    date: 'c. 1300', place: 'Central Asia', kind: 'Material artifact',
    text: 'The coin is inscribed in more than one script. One side names the ruling khan; the other carries a short religious phrase. Wear on the edges suggests it passed through many hands.',
    pov: 'Issued by a state to project authority and be accepted by diverse merchants.',
  },
  letter: {
    id: 'letter', title: "Traveler's Letter (illustrative)", author: 'A European traveler',
    date: 'c. 1280', place: 'Overland route to the east', kind: 'Personal letter',
    text: "The roads are safer than any I knew at home. Travelers carrying the khan's tablet of passage receive lodging and fresh horses. Yet I saw villages emptied by war and heavy tribute.",
    pov: 'An outsider impressed by order but aware of its costs; may exaggerate for a home audience.',
  },
};

export const CHALLENGES: Record<string, Challenge> = {
  c1: {
    id: 'c1', sourceIds: ['ledger', 'coin', 'letter'],
    prompt: 'Using all three sources, which claim about the 13th-century Mongol Empire is BEST supported?',
    options: [
      'Mongol rule isolated Eurasian regions and halted long-distance trade.',
      'Mongol political unity and protected routes helped long-distance trade and exchange flourish.',
      'Trade increased only because Europeans conquered Central Asia.',
      'Mongol rule had no connection to trade patterns.',
    ],
    correct: 1,
    feedback: [
      'Not quite. The ledger shows tolls paid and goods moving, and the letter describes safe roads, which contradicts isolation.',
      'Correct! The ledger (stamps, tolls, goods), coin (multilingual, widely accepted) and letter (safe roads, passage tablets) all point to state-supported trade. The letter also hints at costs: sourcing and point of view matter.',
      'Not quite. None of the sources mention European conquest; they describe Mongol-issued stamps, coins, and passage.',
      "Not quite. Each source ties Mongol authority (stamps, a khan on the coin, the khan's tablet) directly to trade.",
    ],
  },
};

export const NPCS: Npc[] = [
  {
    id: 'merchant', name: 'Layla, Merchant', x: 280, y: 330, color: 0xd9822b,
    lines: () => state.flags.talked_merchant
      ? ["Look around the crossroads: my ledger, a coin, and a traveler's letter will tell you more than I can.", 'When you have studied them, show the scribe what you have learned.']
      : ['Welcome to the crossroads, traveler! Caravans from China, Persia and Europe meet here.', "Historians argue about why trade flourished in this era. Do not take anyone's word for it: examine the evidence.", 'Check my ledger, the coin by the well, and the letter on the table.'],
  },
  {
    id: 'scribe', name: 'Omar, Scribe', x: 640, y: 180, color: 0x4a6fd9,
    lines: () => {
      if (state.passed.includes('c1')) return ['Excellent reasoning! Always corroborate sources and consider point of view.', 'More chapters of Chronicle will come soon.'];
      if (state.examined.length < 3) return ['I cannot judge an argument built on too little evidence.', `You have studied ${state.examined.length}/3 sources. Come back when you have seen them all.`];
      return ['You have studied the sources. Now: what do they tell us together?'];
    },
  },
];

export const OBJECTS: ObjectDef[] = [
  { id: 'o_ledger', label: "Merchant's ledger", x: 220, y: 200, sourceId: 'ledger' },
  { id: 'o_coin', label: 'Silver coin', x: 480, y: 440, sourceId: 'coin' },
  { id: 'o_letter', label: "Traveler's letter", x: 700, y: 400, sourceId: 'letter' },
];
