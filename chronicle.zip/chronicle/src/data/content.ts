// All educational content lives here so it can later move to Supabase/JSON.
// NOTE: sources below are ILLUSTRATIVE, written for gameplay. Replace with real,
// cited primary sources before using in a classroom.
import { state } from '../state';

export interface Source {
  id: string; title: string; author: string; date: string; place: string;
  kind: string; text: string; pov: string;
}
interface Base { id: string; title: string; prompt: string; sourceIds: string[]; xp: number }
export interface McChallenge extends Base { kind: 'mc'; options: string[]; correct: number; feedback: string[] }
/** S = supports, C = contradicts, N = not relevant. One answer per source, in sourceIds order. */
export interface TagChallenge extends Base { kind: 'tag'; answers: ('S' | 'C' | 'N')[]; feedback: string[] }
export interface SaqChallenge extends Base {
  kind: 'saq'; passMark: number;
  parts: { q: string; keywords: string[]; model: string }[];
}
export type Challenge = McChallenge | TagChallenge | SaqChallenge;

export interface Npc {
  id: string; name: string; x: number; y: number; color: number;
  lines: () => string[];
  talkFlag?: string;
  offers?: { challengeId: string; ready: () => boolean };
}
export interface ObjectDef { id: string; label: string; x: number; y: number; sourceId: string }
export interface Exit {
  label: string; x: number; y: number; to: string; spawn: [number, number];
  requires?: () => string | null;
}
export interface Area {
  id: string; name: string; bg: number; path: number;
  blocks: [number, number, number, number, number?][]; // x,y,w,h,tint
  trees: [number, number][]; npcs: Npc[]; objects: ObjectDef[]; exits: Exit[]; spawn: [number, number];
}

export const TITLES = ['Curious Visitor', 'Apprentice Historian', 'Source Analyst', 'Trade Route Scholar', 'Master Historian'];

const has = (...ids: string[]) => ids.every((i) => state.examined.includes(i));
const done = (id: string) => state.passed.includes(id);

export const SOURCES: Record<string, Source> = {
  ledger: { id: 'ledger', title: "Merchant's Ledger (illustrative)", author: 'An unnamed Persian merchant', date: 'c. 1290', place: 'Tabriz', kind: 'Commercial record',
    text: 'Received: 40 bolts silk from the east, 12 chests porcelain, pepper by the sack. Paid: tolls at three posts, each recorded with a Mongol stamp. Sold: paper notes accepted at the caravanserai without dispute.',
    pov: 'A trader recording business; interested in profit and safe passage, not in praising rulers.' },
  coin: { id: 'coin', title: 'Silver Coin (illustrative)', author: 'Mint of a Mongol successor state', date: 'c. 1300', place: 'Central Asia', kind: 'Material artifact',
    text: 'The coin is inscribed in more than one script. One side names the ruling khan; the other carries a short religious phrase. Wear on the edges suggests it passed through many hands.',
    pov: 'Issued by a state to project authority and be accepted by diverse merchants.' },
  letter: { id: 'letter', title: "Traveler's Letter (illustrative)", author: 'A European traveler', date: 'c. 1280', place: 'Overland route to the east', kind: 'Personal letter',
    text: "The roads are safer than any I knew at home. Travelers carrying the khan's tablet of passage receive lodging and fresh horses. Yet I saw villages emptied by war and heavy tribute.",
    pov: 'An outsider impressed by order but aware of its costs; may exaggerate for a home audience.' },
  monsoon: { id: 'monsoon', title: "Pilot's Notes (illustrative)", author: 'An Indian Ocean ship pilot', date: 'c. 1450', place: 'Arabian Sea', kind: 'Navigation record',
    text: 'We sail south and west when the winter winds blow, and wait in port until the summer winds turn and carry us home. A pilot who ignores the seasons loses his ship and his cargo.',
    pov: 'A practical expert writing for other sailors; focused on seasons and safety, not politics.' },
  kilwa: { id: 'kilwa', title: 'Account of a Coastal Port (illustrative)', author: 'A visiting scholar', date: 'c. 1330', place: 'East African coast', kind: 'Travel account',
    text: 'Merchants of many lands crowd the harbor. Gold and ivory leave for the north; cloth and porcelain arrive. The sultan\'s officials weigh each cargo and take their share. Houses are of stone, and the people speak a tongue that mixes local and Arabic words.',
    pov: 'An educated outsider impressed by wealth; likely describes elite districts more than ordinary life.' },
  stele: { id: 'stele', title: 'Fleet Inscription (illustrative)', author: 'Officials of a Chinese emperor', date: 'c. 1430', place: 'Southern China', kind: 'Official inscription',
    text: 'Our great ships sailed to the western oceans carrying silks and gifts. Foreign envoys returned with us to pay respect to the emperor, and distant kings sent tribute.',
    pov: 'Written by the state to celebrate the emperor; stresses prestige and tribute over commerce.' },
};

export const CHALLENGES: Record<string, Challenge> = {
  c1: { kind: 'mc', id: 'c1', title: 'Evidence Challenge', xp: 50, sourceIds: ['ledger', 'coin', 'letter'],
    prompt: 'Using all three sources, which claim about the 13th-century Mongol Empire is BEST supported?',
    options: [
      'Mongol rule isolated Eurasian regions and halted long-distance trade.',
      'Mongol political unity and protected routes helped long-distance trade and exchange flourish.',
      'Trade increased only because Europeans conquered Central Asia.',
      'Mongol rule had no connection to trade patterns.',
    ],
    correct: 1,
    feedback: [
      'Not quite. The ledger shows tolls paid and goods moving, and the letter describes safe roads, which contradicts isolation.',
      'Correct! The ledger (stamps, tolls, goods), coin (multilingual, widely accepted) and letter (safe roads, passage tablets) all point to state-supported trade. The letter also hints at costs: sourcing and point of view matter.',
      'Not quite. None of the sources mention European conquest; they describe Mongol-issued stamps, coins, and passage.',
      "Not quite. Each source ties Mongol authority (stamps, a khan on the coin, the khan's tablet) directly to trade.",
    ] },
  c2: { kind: 'tag', id: 'c2', title: 'Evidence Tagging', xp: 60, sourceIds: ['monsoon', 'kilwa', 'stele'],
    prompt: 'Claim: "Indian Ocean trade was carried on entirely by private merchants, with no involvement from rulers." Tag each source: does it support the claim, contradict it, or not bear on it?',
    answers: ['N', 'C', 'C'],
    feedback: [
      'The notes are about winds and seasons. They do not mention rulers either way, so they neither support nor contradict the claim.',
      "This contradicts the claim: the sultan's officials weigh cargoes and take a share, so rulers were involved.",
      'This contradicts the claim: the state sent fleets and received tribute. Note its point of view, since it emphasizes prestige.',
    ] },
  c3: { kind: 'saq', id: 'c3', title: 'Short-Answer Exam', xp: 60, passMark: 2, sourceIds: ['monsoon', 'kilwa', 'stele'],
    prompt: 'Answer each part in a sentence or two, using the sources.',
    parts: [
      { q: 'A) Identify ONE way the monsoon winds shaped Indian Ocean trade.',
        keywords: ['season', 'schedule', 'timing', 'predictable', 'reverse', 'direction', 'wait', 'winter', 'summer'],
        model: 'Seasonal winds reversed direction, so ships had to follow set seasons to sail out and return.' },
      { q: 'B) Identify ONE example of cultural blending in the sources.',
        keywords: ['language', 'swahili', 'arabic', 'mix', 'blend', 'tongue', 'multiple', 'many lands', 'foreign'],
        model: 'The coastal port\'s people spoke a language mixing local and Arabic words, showing blending of cultures.' },
      { q: 'C) Explain ONE way rulers took part in Indian Ocean OR Silk Road trade.',
        keywords: ['tax', 'toll', 'tribute', 'fleet', 'sultan', 'officials', 'stamp', 'tablet', 'passage', 'protect', 'envoy'],
        model: 'Rulers took part by taxing cargoes (the sultan\'s officials) or by sending state fleets and collecting tribute.' },
    ] },
};

export const AREAS: Record<string, Area> = {
  crossroads: {
    id: 'crossroads', name: 'Silk Road Crossroads (c. 1290)', bg: 0x3f7a46, path: 0xcdb27a, spawn: [400, 300],
    blocks: [[150, 110, 160, 90], [620, 90, 150, 80], [140, 440, 130, 70], [660, 480, 140, 60]],
    trees: [[60, 260], [340, 90], [520, 230], [350, 500], [760, 380]],
    exits: [{ label: 'the Coast Road to the Indian Ocean port', x: 770, y: 300, to: 'port', spawn: [60, 300],
      requires: () => (done('c1') ? null : 'The road east opens once you have made your argument to Omar.') }],
    npcs: [
      { id: 'merchant', name: 'Layla, Merchant', x: 280, y: 330, color: 0xd9822b, talkFlag: 'talked_merchant',
        lines: () => state.flags.talked_merchant
          ? ["Look around the crossroads: my ledger, a coin, and a traveler's letter will tell you more than I can.", 'When you have studied them, show the scribe what you have learned.']
          : ['Welcome to the crossroads, traveler! Caravans from China, Persia and Europe meet here.', "Historians argue about why trade flourished in this era. Do not take anyone's word for it: examine the evidence.", 'Check my ledger, the coin by the well, and the letter on the table.'] },
      { id: 'scribe', name: 'Omar, Scribe', x: 640, y: 180, color: 0x4a6fd9,
        offers: { challengeId: 'c1', ready: () => has('ledger', 'coin', 'letter') },
        lines: () => {
          if (done('c1')) return ['Excellent reasoning! Always corroborate sources and consider point of view.', 'The coast road to the east is open to you. Follow the monsoon trade!'];
          if (!has('ledger', 'coin', 'letter')) return ['I cannot judge an argument built on too little evidence.', `You have studied ${['ledger', 'coin', 'letter'].filter((i) => state.examined.includes(i)).length}/3 sources. Come back when you have seen them all.`];
          return ['You have studied the sources. Now: what do they tell us together?'];
        } },
    ],
    objects: [
      { id: 'o_ledger', label: "Merchant's ledger", x: 220, y: 200, sourceId: 'ledger' },
      { id: 'o_coin', label: 'Silver coin', x: 480, y: 440, sourceId: 'coin' },
      { id: 'o_letter', label: "Traveler's letter", x: 700, y: 400, sourceId: 'letter' },
    ],
  },
  port: {
    id: 'port', name: 'Indian Ocean Port (c. 1450)', bg: 0xd8c48a, path: 0xf0e3b8, spawn: [60, 300],
    blocks: [[180, 120, 150, 80], [600, 110, 160, 90], [400, 520, 800, 60, 0x2a6fb0]],
    trees: [[300, 60], [520, 440], [90, 180], [740, 250]],
    exits: [{ label: 'the road back to the Crossroads', x: 30, y: 300, to: 'crossroads', spawn: [740, 300] }],
    npcs: [
      { id: 'kamau', name: 'Kamau, Trader', x: 150, y: 340, color: 0x2f9e5a, talkFlag: 'talked_kamau',
        lines: () => ['Karibu! Welcome. Ships from Arabia, India, and China all call at this harbor.', "The pilot's notes, an account of this port, and an inscription from a Chinese fleet are around town.", 'Study them all, then speak with Captain Mei.'] },
      { id: 'mei', name: 'Captain Mei', x: 430, y: 220, color: 0xc43d3d,
        offers: { challengeId: 'c2', ready: () => has('monsoon', 'kilwa', 'stele') },
        lines: () => {
          if (done('c2')) return ['Well tagged! Seeing what a source does NOT say is as important as what it says.', 'Harbormaster Yusuf has a final exam for you.'];
          if (!has('monsoon', 'kilwa', 'stele')) return ['Come back when you have studied all three port sources.'];
          return ['Let us test a claim against the evidence. Tag each source carefully.'];
        } },
      { id: 'yusuf', name: 'Yusuf, Harbormaster', x: 660, y: 300, color: 0x7a4ad9,
        offers: { challengeId: 'c3', ready: () => done('c2') },
        lines: () => {
          if (done('c3')) return ['Outstanding! You can now explain how winds, cultures, and rulers shaped these networks.', 'More chapters of Chronicle are coming.'];
          if (!done('c2')) return ['Speak with Captain Mei first. I only examine those who can tag evidence.'];
          return ['Time for a short-answer exam, as on the AP test. Answer in your own words using the sources.'];
        } },
    ],
    objects: [
      { id: 'o_monsoon', label: "Pilot's notes", x: 250, y: 430, sourceId: 'monsoon' },
      { id: 'o_kilwa', label: 'Account of the port', x: 520, y: 330, sourceId: 'kilwa' },
      { id: 'o_stele', label: 'Fleet inscription', x: 700, y: 410, sourceId: 'stele' },
    ],
  },
};
