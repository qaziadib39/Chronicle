import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import { state, save, setSaveHook, type State } from './state';

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;
export const cloudEnabled = !!(url && key);
const sb: SupabaseClient | null = cloudEnabled ? createClient(url!, key!) : null;
let uid: string | null = null;
let timer: number | undefined;

async function push(): Promise<void> {
  if (!sb || !uid) return;
  await sb.from('progress').upsert({ user_id: uid, data: state, updated_at: new Date().toISOString() });
}

async function pull(): Promise<void> {
  if (!sb || !uid) return;
  const { data } = await sb.from('progress').select('data').eq('user_id', uid).maybeSingle();
  const remote = data?.data as Partial<State> | undefined;
  if (remote && (remote.xp ?? 0) > state.xp) { Object.assign(state, remote); save(); } else { await push(); }
}

function attach(): void {
  setSaveHook(() => { window.clearTimeout(timer); timer = window.setTimeout(push, 1500); });
}

export async function restoreSession(): Promise<string | null> {
  if (!sb) return null;
  const { data } = await sb.auth.getSession();
  uid = data.session?.user.id ?? null;
  if (uid) { await pull(); attach(); }
  return data.session?.user.email ?? null;
}

/** Returns an error/info message, or null on success. */
export async function signIn(email: string, password: string): Promise<string | null> {
  if (!sb) return 'Cloud save is not configured.';
  const { data, error } = await sb.auth.signInWithPassword({ email, password });
  if (error) return error.message;
  uid = data.user.id; await pull(); attach(); return null;
}

export async function signUp(email: string, password: string): Promise<string | null> {
  if (!sb) return 'Cloud save is not configured.';
  const { data, error } = await sb.auth.signUp({ email, password });
  if (error) return error.message;
  if (!data.session) return 'Account created. Check your email to confirm it, then sign in.';
  uid = data.user!.id; await pull(); attach(); return null;
}

export async function signOut(): Promise<void> {
  if (!sb) return;
  await sb.auth.signOut(); uid = null; setSaveHook(() => {});
}
