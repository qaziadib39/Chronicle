import Phaser from 'phaser';
import { UI } from '../ui/ui';
import { runChallenge } from '../ui/challenges';
import { showJournal } from '../ui/journal';
import { state, save, addXp, level } from '../state';
import { QUESTS, questDone } from '../quests';
import { AREAS, SOURCES, CHALLENGES, TITLES, type Area } from '../data/content';

interface Interactable { label: string; sprite: Phaser.GameObjects.Sprite; act: () => void }

export class GameScene extends Phaser.Scene {
  private ui!: UI;
  private player!: Phaser.Physics.Arcade.Sprite;
  private keys!: Record<string, Phaser.Input.Keyboard.Key>;
  private things: Interactable[] = [];
  private area: Area = AREAS.crossroads;
  private spawn?: [number, number];

  constructor() { super('Game'); }

  init(data: { spawn?: [number, number] }): void {
    this.area = AREAS[state.area] ?? AREAS.crossroads;
    this.spawn = data?.spawn;
    this.things = [];
  }

  preload(): void {
    const tex = (key: string, w: number, h: number, draw: (g: Phaser.GameObjects.Graphics) => void) => {
      if (this.textures.exists(key)) return;
      const g = this.make.graphics({ x: 0, y: 0 }, false); draw(g); g.generateTexture(key, w, h); g.destroy();
    };
    tex('player', 20, 28, (g) => { g.fillStyle(0xf2d6a0).fillCircle(10, 8, 7); g.fillStyle(0x2f9e8f).fillRect(3, 14, 14, 14); });
    tex('npc', 20, 28, (g) => { g.fillStyle(0xf2d6a0).fillCircle(10, 8, 7); g.fillStyle(0xffffff).fillRect(3, 14, 14, 14); });
    tex('artifact', 16, 16, (g) => { g.fillStyle(0xe8c46a).fillRect(0, 0, 16, 16); g.lineStyle(2, 0x7a5a1a).strokeRect(1, 1, 14, 14); });
    tex('gate', 20, 28, (g) => { g.fillStyle(0x8a5ad9).fillTriangle(0, 0, 0, 28, 20, 14); });
    tex('wall', 32, 32, (g) => { g.fillStyle(0xffffff).fillRect(0, 0, 32, 32); g.lineStyle(2, 0x777777).strokeRect(0, 0, 32, 32); });
    tex('tree', 32, 32, (g) => { g.fillStyle(0x6b4a2a).fillRect(13, 18, 6, 14); g.fillStyle(0x2d6b34).fillCircle(16, 14, 13); });
    tex('path', 32, 32, (g) => { g.fillStyle(0xffffff).fillRect(0, 0, 32, 32); });
  }

  create(): void {
    this.ui = this.ui ?? new UI();
    const a = this.area, W = 800, H = 540;
    state.flags[`visited_${a.id}`] = true;
    this.cameras.main.setBackgroundColor(a.bg);
    this.physics.world.setBounds(0, 0, W, H);

    this.add.tileSprite(W / 2, 300, W, 64, 'path').setTint(a.path);
    this.add.tileSprite(400, H / 2, 64, H, 'path').setTint(a.path);

    const walls = this.physics.add.staticGroup();
    a.blocks.forEach(([x, y, w, h, tint]) => {
      const s = walls.create(x, y, 'wall') as Phaser.Physics.Arcade.Sprite;
      s.setTint(tint ?? 0x8a6a4a).setDisplaySize(w, h).refreshBody();
    });
    a.trees.forEach(([x, y]) => { (walls.create(x, y, 'tree') as Phaser.Physics.Arcade.Sprite).refreshBody(); });

    for (const n of a.npcs) {
      const s = this.add.sprite(n.x, n.y, 'npc').setTint(n.color);
      this.add.text(n.x, n.y - 24, n.name, { fontSize: '11px', color: '#fff', backgroundColor: '#0008' }).setOrigin(0.5);
      this.things.push({ label: `Talk to ${n.name}`, sprite: s, act: () => this.talk(n.id) });
    }
    for (const o of a.objects) {
      const s = this.add.sprite(o.x, o.y, 'artifact');
      this.tweens.add({ targets: s, y: o.y - 3, yoyo: true, repeat: -1, duration: 700 });
      this.things.push({ label: `Examine ${o.label}`, sprite: s, act: () => this.examine(o.sourceId) });
    }
    for (const e of a.exits) {
      const s = this.add.sprite(e.x, e.y, 'gate');
      this.things.push({ label: `Travel to ${e.label}`, sprite: s, act: () => this.travel(e) });
    }

    const [sx, sy] = this.spawn ?? a.spawn;
    this.player = this.physics.add.sprite(sx, sy, 'player');
    this.player.setCollideWorldBounds(true);
    (this.player.body as Phaser.Physics.Arcade.Body).setSize(14, 14).setOffset(3, 14);
    this.physics.add.collider(this.player, walls);

    this.keys = this.input.keyboard!.addKeys('W,A,S,D,UP,DOWN,LEFT,RIGHT,E,SPACE,J') as Record<string, Phaser.Input.Keyboard.Key>;
    this.refresh();
    this.ui.toast(a.name);
  }

  update(): void {
    const body = this.player.body as Phaser.Physics.Arcade.Body;
    const kb = this.input.keyboard!;
    if (this.ui.isOpen()) { kb.enabled = false; body.setVelocity(0); this.ui.prompt(null); return; }
    if (!kb.enabled) { kb.enabled = true; kb.resetKeys(); }

    const k = this.keys;
    const dx = (k.D.isDown || k.RIGHT.isDown ? 1 : 0) - (k.A.isDown || k.LEFT.isDown ? 1 : 0);
    const dy = (k.S.isDown || k.DOWN.isDown ? 1 : 0) - (k.W.isDown || k.UP.isDown ? 1 : 0);
    body.setVelocity(dx, dy);
    if (dx || dy) body.velocity.normalize().scale(150);

    let near: Interactable | null = null, best = 44;
    for (const t of this.things) {
      const d = Phaser.Math.Distance.Between(this.player.x, this.player.y, t.sprite.x, t.sprite.y);
      if (d < best) { best = d; near = t; }
    }
    this.ui.prompt(near ? `[E] ${near.label}` : null);

    const ready = performance.now() - this.ui.closedAt > 250;
    if (ready && Phaser.Input.Keyboard.JustDown(k.J)) { showJournal(this.ui); return; }
    const pressed = Phaser.Input.Keyboard.JustDown(k.E) || Phaser.Input.Keyboard.JustDown(k.SPACE);
    if (pressed && near && ready) near.act();
  }

  private travel(e: Area['exits'][number]): void {
    const msg = e.requires?.();
    if (msg) { this.ui.toast(msg); return; }
    state.area = e.to; save();
    this.scene.restart({ spawn: e.spawn });
  }

  private talk(id: string): void {
    const npc = this.area.npcs.find((n) => n.id === id)!;
    this.ui.showDialogue(npc.name, npc.lines(), () => {
      if (npc.talkFlag && !state.flags[npc.talkFlag]) { state.flags[npc.talkFlag] = true; this.gain(10, `Met ${npc.name}`); }
      const o = npc.offers;
      if (o && o.ready() && !state.passed.includes(o.challengeId)) this.challenge(o.challengeId);
      this.refresh();
    });
  }

  private examine(sourceId: string): void {
    const s = SOURCES[sourceId];
    this.ui.showSource(s, () => {
      if (!state.examined.includes(sourceId)) { state.examined.push(sourceId); this.gain(10, `Collected: ${s.title}`); }
      this.refresh();
    });
  }

  private challenge(id: string): void {
    const c = CHALLENGES[id];
    runChallenge(this.ui, c, c.sourceIds.map((i) => SOURCES[i]), (ok) => {
      if (ok && !state.passed.includes(id)) { state.passed.push(id); this.gain(c.xp, `${c.title} passed!`); }
      this.refresh();
    });
  }

  private gain(xp: number, msg: string): void {
    const before = level();
    addXp(xp);
    const up = level() > before ? `  ★ Level ${level()}: ${TITLES[Math.min(level(), TITLES.length) - 1]}!` : '';
    this.ui.toast(`+${xp} XP: ${msg}${up}`);
  }

  private refresh(): void {
    for (const q of QUESTS) {
      const key = `done_${q.id}`;
      if (questDone(q) && !state.flags[key]) {
        state.flags[key] = true;
        this.time.delayedCall(900, () => this.ui.toast(`Quest complete: ${q.title}`));
      }
    }
    save(); this.ui.renderHud();
  }
}
