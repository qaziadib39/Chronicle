import Phaser from 'phaser';
import { UI } from '../ui/ui';
import { state, save, addXp, level } from '../state';
import { QUESTS, questDone } from '../quests';
import { NPCS, OBJECTS, SOURCES, CHALLENGES } from '../data/content';

interface Interactable { label: string; sprite: Phaser.GameObjects.Sprite; act: () => void }

export class GameScene extends Phaser.Scene {
  private ui!: UI;
  private player!: Phaser.Physics.Arcade.Sprite;
  private keys!: Record<string, Phaser.Input.Keyboard.Key>;
  private things: Interactable[] = [];

  constructor() { super('Game'); }

  preload(): void {
    const tex = (key: string, w: number, h: number, draw: (g: Phaser.GameObjects.Graphics) => void) => {
      const g = this.make.graphics({ x: 0, y: 0 }, false); draw(g); g.generateTexture(key, w, h); g.destroy();
    };
    tex('player', 20, 28, (g) => { g.fillStyle(0xf2d6a0).fillCircle(10, 8, 7); g.fillStyle(0x2f9e8f).fillRect(3, 14, 14, 14); });
    tex('npc', 20, 28, (g) => { g.fillStyle(0xf2d6a0).fillCircle(10, 8, 7); g.fillStyle(0xffffff).fillRect(3, 14, 14, 14); });
    tex('artifact', 16, 16, (g) => { g.fillStyle(0xe8c46a).fillRect(0, 0, 16, 16); g.lineStyle(2, 0x7a5a1a).strokeRect(1, 1, 14, 14); });
    tex('wall', 32, 32, (g) => { g.fillStyle(0x8a6a4a).fillRect(0, 0, 32, 32); g.lineStyle(2, 0x5a4028).strokeRect(0, 0, 32, 32); });
    tex('tree', 32, 32, (g) => { g.fillStyle(0x6b4a2a).fillRect(13, 18, 6, 14); g.fillStyle(0x2d6b34).fillCircle(16, 14, 13); });
    tex('path', 32, 32, (g) => { g.fillStyle(0xcdb27a).fillRect(0, 0, 32, 32); });
  }

  create(): void {
    this.ui = new UI();
    const W = 800, H = 540;
    this.physics.world.setBounds(0, 0, W, H);

    this.add.tileSprite(W / 2, 300, W, 64, 'path');
    this.add.tileSprite(400, H / 2, 64, H, 'path');

    const walls = this.physics.add.staticGroup();
    const block = (x: number, y: number, w: number, h: number) => {
      const s = walls.create(x, y, 'wall') as Phaser.Physics.Arcade.Sprite;
      s.setDisplaySize(w, h).refreshBody();
    };
    block(150, 110, 160, 90); block(620, 90, 150, 80); block(140, 440, 130, 70); block(660, 480, 140, 60);
    [[60, 260], [340, 90], [520, 230], [350, 500], [760, 300]].forEach(([x, y]) => {
      const t = walls.create(x, y, 'tree') as Phaser.Physics.Arcade.Sprite; t.refreshBody();
    });

    for (const n of NPCS) {
      const s = this.add.sprite(n.x, n.y, 'npc').setTint(n.color);
      this.add.text(n.x, n.y - 24, n.name, { fontSize: '11px', color: '#fff', backgroundColor: '#0008' }).setOrigin(0.5);
      this.things.push({ label: `Talk to ${n.name}`, sprite: s, act: () => this.talk(n.id) });
    }
    for (const o of OBJECTS) {
      const s = this.add.sprite(o.x, o.y, 'artifact');
      this.tweens.add({ targets: s, y: o.y - 3, yoyo: true, repeat: -1, duration: 700 });
      this.things.push({ label: `Examine ${o.label}`, sprite: s, act: () => this.examine(o.sourceId) });
    }

    this.player = this.physics.add.sprite(400, 300, 'player');
    this.player.setCollideWorldBounds(true);
    (this.player.body as Phaser.Physics.Arcade.Body).setSize(14, 14).setOffset(3, 14);
    this.physics.add.collider(this.player, walls);

    this.keys = this.input.keyboard!.addKeys('W,A,S,D,UP,DOWN,LEFT,RIGHT,E,SPACE') as Record<string, Phaser.Input.Keyboard.Key>;

    this.ui.renderHud();
    this.ui.toast('Welcome to the Silk Road Crossroads');
  }

  update(): void {
    const body = this.player.body as Phaser.Physics.Arcade.Body;
    if (this.ui.isOpen()) { body.setVelocity(0); this.ui.prompt(null); return; }

    const k = this.keys;
    const dx = (k.D.isDown || k.RIGHT.isDown ? 1 : 0) - (k.A.isDown || k.LEFT.isDown ? 1 : 0);
    const dy = (k.S.isDown || k.DOWN.isDown ? 1 : 0) - (k.W.isDown || k.UP.isDown ? 1 : 0);
    body.setVelocity(dx, dy);
    if (dx || dy) body.velocity.normalize().scale(150);

    let near: Interactable | null = null, best = 44;
    for (const t of this.things) {
      const d = Phaser.Math.Distance.Between(this.player.x, this.player.y, t.sprite.x, t.sprite.y);
      if (d < best) { best = d; near = t; }
    }
    this.ui.prompt(near ? `[E] ${near.label}` : null);

    const pressed = Phaser.Input.Keyboard.JustDown(k.E) || Phaser.Input.Keyboard.JustDown(k.SPACE);
    if (pressed && near && performance.now() - this.ui.closedAt > 250) near.act();
  }

  private talk(id: string): void {
    const npc = NPCS.find((n) => n.id === id)!;
    this.ui.showDialogue(npc.name, npc.lines(), () => {
      if (id === 'merchant' && !state.flags.talked_merchant) {
        state.flags.talked_merchant = true; this.gain(10, 'Met Layla');
      }
      if (id === 'scribe' && state.examined.length >= 3 && !state.passed.includes('c1')) this.challenge('c1');
      this.refresh();
    });
  }

  private examine(sourceId: string): void {
    const s = SOURCES[sourceId];
    this.ui.showSource(s, () => {
      if (!state.examined.includes(sourceId)) { state.examined.push(sourceId); this.gain(10, `Examined: ${s.title}`); }
      this.refresh();
    });
  }

  private challenge(id: string): void {
    const c = CHALLENGES[id];
    this.ui.showChallenge(c, c.sourceIds.map((i) => SOURCES[i]), (ok) => {
      if (ok && !state.passed.includes(id)) { state.passed.push(id); this.gain(50, 'Challenge passed!'); }
      this.refresh();
    });
  }

  private gain(xp: number, msg: string): void {
    const before = level();
    addXp(xp);
    this.ui.toast(`+${xp} XP: ${msg}${level() > before ? `  ★ Level ${level()}!` : ''}`);
  }

  private refresh(): void {
    for (const q of QUESTS) {
      const key = `done_${q.id}`;
      if (questDone(q) && !state.flags[key]) {
        state.flags[key] = true;
        this.time.delayedCall(900, () => this.ui.toast(`Quest complete: ${q.title}`));
      }
    }
    save(); this.ui.renderHud();
  }
}
