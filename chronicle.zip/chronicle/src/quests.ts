import { state } from './state';

export interface Objective { text: string; done: () => boolean }
export interface Quest { id: string; title: string; objectives: Objective[] }

const seen = (id: string) => () => state.examined.includes(id);
const passed = (id: string) => () => state.passed.includes(id);

export const QUESTS: Quest[] = [
  { id: 'q1', title: 'Arrive at the Crossroads',
    objectives: [{ text: 'Speak with Layla the merchant', done: () => !!state.flags.talked_merchant }] },
  { id: 'q2', title: 'Gather Evidence',
    objectives: [
      { text: "Examine the merchant's ledger", done: seen('ledger') },
      { text: 'Examine the silver coin', done: seen('coin') },
      { text: "Examine the traveler's letter", done: seen('letter') },
    ] },
  { id: 'q3', title: 'Make Your Argument',
    objectives: [{ text: "Pass Scribe Omar's evidence challenge", done: passed('c1') }] },
  { id: 'q4', title: 'Follow the Monsoon',
    objectives: [
      { text: 'Travel to the Indian Ocean port', done: () => !!state.flags.visited_port },
      { text: 'Speak with Kamau the trader', done: () => !!state.flags.talked_kamau },
    ] },
  { id: 'q5', title: 'Port Evidence',
    objectives: [
      { text: "Examine the pilot's notes", done: seen('monsoon') },
      { text: 'Examine the account of the port', done: seen('kilwa') },
      { text: 'Examine the fleet inscription', done: seen('stele') },
    ] },
  { id: 'q6', title: 'Analyze the Networks',
    objectives: [
      { text: "Tag the evidence for Captain Mei", done: passed('c2') },
      { text: "Complete Harbormaster Yusuf's short-answer exam", done: passed('c3') },
    ] },
];

export const questDone = (q: Quest): boolean => q.objectives.every((o) => o.done());
