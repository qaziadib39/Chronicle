import { state } from './state';

export interface Objective { text: string; done: () => boolean }
export interface Quest { id: string; title: string; objectives: Objective[] }

export const QUESTS: Quest[] = [
  {
    id: 'q1', title: 'Arrive at the Crossroads',
    objectives: [{ text: 'Speak with Layla the merchant', done: () => !!state.flags.talked_merchant }],
  },
  {
    id: 'q2', title: 'Gather Evidence',
    objectives: [
      { text: "Examine the merchant's ledger", done: () => state.examined.includes('ledger') },
      { text: 'Examine the silver coin', done: () => state.examined.includes('coin') },
      { text: "Examine the traveler's letter", done: () => state.examined.includes('letter') },
    ],
  },
  {
    id: 'q3', title: 'Make Your Argument',
    objectives: [{ text: "Pass Scribe Omar's evidence challenge", done: () => state.passed.includes('c1') }],
  },
];

export const questDone = (q: Quest): boolean => q.objectives.every((o) => o.done());
