import { state, level } from '../state';
import { SOURCES, TITLES } from '../data/content';
import type { UI } from './ui';

export function showJournal(ui: UI, tab: 'evidence' | 'titles' = 'evidence'): void {
  ui.clearKeys();
  const card = ui.card;
  card.innerHTML = '';
  const h = document.createElement('h3'); h.textContent = 'Historian\'s Journal';
  card.append(h,
    ui.button('Evidence', () => showJournal(ui, 'evidence'), tab === 'evidence' ? 'sel' : ''),
    ui.button('Titles & Rewards', () => showJournal(ui, 'titles'), tab === 'titles' ? 'sel' : ''));
  const body = document.createElement('div');
  if (tab === 'evidence') {
    const total = Object.keys(SOURCES).length;
    const p = document.createElement('p'); p.textContent = `Sources collected: ${state.examined.length}/${total}`;
    body.append(p);
    state.examined.forEach((id) => {
      const s = SOURCES[id]; if (!s) return;
      const b = ui.button(`${s.title} (${s.date})`, () => ui.showSource(s, () => showJournal(ui, 'evidence')), 'opt');
      body.append(b);
    });
    if (!state.examined.length) body.append(document.createTextNode('Nothing yet. Examine artifacts in the world to collect evidence.'));
  } else {
    TITLES.forEach((t, i) => {
      const d = document.createElement('div'); d.className = 'meta';
      const unlocked = level() >= i + 1;
      d.textContent = `${unlocked ? '★' : '☆'} ${t} (Level ${i + 1})${level() === i + 1 ? ' – current' : ''}`;
      body.append(d);
    });
  }
  card.append(body, ui.button('Close', () => ui.close()));
  ui.open();
}
