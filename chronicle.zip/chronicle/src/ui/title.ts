import { cloudEnabled, restoreSession, signIn, signUp, signOut } from '../cloud';
import { state, resetProgress } from '../state';

const SUBJECTS = [
  { id: 'apwh', name: 'AP World History: Modern', on: true },
  { id: 'apush', name: 'AP U.S. History' }, { id: 'apeuro', name: 'AP European History' },
  { id: 'apgov', name: 'AP U.S. Government' }, { id: 'apbio', name: 'AP Biology' },
  { id: 'apcalc', name: 'AP Calculus AB' }, { id: 'appsych', name: 'AP Psychology' },
];

export async function showTitle(onPlay: () => void): Promise<void> {
  const root = document.getElementById('title') as HTMLElement;
  root.style.display = 'flex';
  let email: string | null = await restoreSession();

  const start = (fresh: boolean) => {
    if (fresh) resetProgress();
    state.subject = 'apwh';
    root.style.display = 'none';
    onPlay();
  };

  const render = (msg = '') => {
    root.innerHTML = '';
    const add = <K extends keyof HTMLElementTagNameMap>(tag: K, text = '', parent: HTMLElement = root) => {
      const e = document.createElement(tag); e.textContent = text; parent.append(e); return e;
    };
    add('h1', 'Chronicle');
    add('p', 'Learn history by investigating it.');
    add('h3', 'Choose a subject');
    const subj = add('div');
    SUBJECTS.forEach((s) => {
      const b = add('button', s.on ? s.name : `${s.name} (coming soon)`, subj);
      b.className = 'subj' + (s.on ? ' on' : ''); b.disabled = !s.on;
    });

    const auth = add('div'); auth.className = 'auth';
    if (!cloudEnabled) {
      add('p', 'Cloud save is not set up. Progress is saved in this browser only.', auth).className = 'meta';
    } else if (email) {
      add('p', `Signed in as ${email}. Progress syncs to the cloud.`, auth).className = 'meta';
      add('button', 'Sign out', auth).onclick = async () => { await signOut(); email = null; render(); };
    } else {
      const em = add('input', '', auth); em.type = 'email'; em.placeholder = 'Email';
      const pw = add('input', '', auth); pw.type = 'password'; pw.placeholder = 'Password (6+ characters)';
      const go = (fn: typeof signIn) => async () => {
        const err = await fn(em.value.trim(), pw.value);
        if (err) { render(err); return; }
        email = await restoreSession(); render();
      };
      add('button', 'Sign in', auth).onclick = go(signIn);
      add('button', 'Create account', auth).onclick = go(signUp);
      add('p', 'Or just play as a guest below.', auth).className = 'meta';
    }
    if (msg) add('p', msg, auth).className = 'fb';

    const play = add('div');
    if (state.xp > 0) {
      add('button', 'Continue', play).onclick = () => start(false);
      add('button', 'New game', play).onclick = () => { if (confirm('Erase your progress and start over?')) start(true); };
    } else {
      add('button', 'Start', play).onclick = () => start(false);
    }
  };
  render();
}
