import type { UI } from './ui';
import type { Challenge, Source, McChallenge, TagChallenge, SaqChallenge } from '../data/content';

type Done = (ok: boolean) => void;
const el = (tag: string, text?: string, cls?: string): HTMLElement => {
  const e = document.createElement(tag);
  if (text) e.textContent = text;
  if (cls) e.className = cls;
  return e;
};

export function runChallenge(ui: UI, c: Challenge, sources: Source[], done: Done): void {
  ui.clearKeys();
  const card = ui.card;
  card.innerHTML = '';
  card.append(el('h3', c.title), el('p', c.prompt));
  sources.forEach((s) => card.append(el('div', `• ${s.title}: ${s.text}`, 'meta')));
  const retry = () => runChallenge(ui, c, sources, done);
  if (c.kind === 'mc') mc(ui, c, done);
  else if (c.kind === 'tag') tag(ui, c, sources, done, retry);
  else saq(ui, c, done, retry);
  card.append(ui.button('Leave', () => { ui.close(); done(false); }));
  ui.open();
}

function mc(ui: UI, c: McChallenge, done: Done): void {
  const fb = el('div');
  const btns: HTMLButtonElement[] = [];
  c.options.forEach((o, idx) => {
    const b = ui.button(o, () => {
      const ok = idx === c.correct;
      b.classList.add(ok ? 'good' : 'bad');
      fb.className = 'fb'; fb.textContent = c.feedback[idx];
      if (ok) {
        btns.forEach((x) => (x.disabled = true));
        fb.append(document.createElement('br'), ui.button('Continue', () => { ui.close(); done(true); }));
      } else b.disabled = true;
    }, 'opt');
    btns.push(b); ui.card.append(b);
  });
  ui.card.append(fb);
}

function tag(ui: UI, c: TagChallenge, sources: Source[], done: Done, retry: () => void): void {
  const picks: (string | null)[] = c.answers.map(() => null);
  const rows: { fb: HTMLElement; btns: HTMLButtonElement[] }[] = [];
  const check = ui.button('Check answers', () => {
    let ok = true;
    picks.forEach((p, i) => {
      const right = p === c.answers[i];
      ok = ok && right;
      rows[i].btns.forEach((b) => { b.disabled = true; });
      rows[i].fb.className = 'fb';
      rows[i].fb.textContent = `${right ? '✔ ' : '✘ '}${c.feedback[i]}`;
    });
    check.remove();
    const next = ok ? ui.button('Continue', () => { ui.close(); done(true); }) : ui.button('Try again', retry);
    ui.card.insertBefore(next, ui.card.lastElementChild);
  });
  check.disabled = true;
  const opts: [string, string][] = [['S', 'Supports'], ['C', 'Contradicts'], ['N', 'Not relevant']];
  sources.forEach((s, i) => {
    const row = el('div', undefined, 'row');
    row.append(el('b', s.title));
    const btns: HTMLButtonElement[] = [];
    const wrap = el('div');
    opts.forEach(([v, label]) => {
      const b = ui.button(label, () => {
        picks[i] = v; btns.forEach((x) => x.classList.remove('sel')); b.classList.add('sel');
        check.disabled = picks.some((p) => p === null);
      }, 'tg');
      btns.push(b); wrap.append(b);
    });
    const fb = el('div');
    row.append(wrap, fb); rows.push({ fb, btns }); ui.card.append(row);
  });
  ui.card.append(check);
}

function saq(ui: UI, c: SaqChallenge, done: Done, retry: () => void): void {
  const areas: HTMLTextAreaElement[] = [];
  c.parts.forEach((p) => {
    const ta = document.createElement('textarea');
    ta.placeholder = 'Your answer…'; areas.push(ta);
    ui.card.append(el('p', p.q), ta);
  });
  const out = el('div');
  const submit = ui.button('Submit', () => {
    let score = 0;
    out.innerHTML = '';
    c.parts.forEach((p, i) => {
      const t = areas[i].value.toLowerCase();
      const hit = t.trim().length >= 10 && p.keywords.some((k) => t.includes(k));
      if (hit) score++;
      const d = el('div', `${hit ? '✔ Point earned.' : '✘ No point yet.'} Model answer: ${p.model}`, 'fb');
      out.append(d);
    });
    out.append(el('p', `Score: ${score}/${c.parts.length}. (The auto-check looks for key ideas, so compare your wording to the model answers.)`));
    submit.remove();
    const pass = score >= c.passMark;
    out.append(pass ? ui.button('Continue', () => { ui.close(); done(true); }) : ui.button('Try again', retry));
  });
  ui.card.append(submit, out);
}
