import { state, level, XP_PER_LEVEL } from '../state';
import { AREAS, TITLES } from '../data/content';
import { QUESTS, questDone } from '../quests';
import type { Source } from '../data/content';

const $ = (id: string) => document.getElementById(id) as HTMLElement;

export class UI {
  modal = $('modal');
  card = $('card');
  closedAt = 0;
  keyHandler: ((e: KeyboardEvent) => void) | null = null;

  isOpen(): boolean { return this.modal.style.display === 'flex'; }
  open(): void { this.modal.style.display = 'flex'; }

  close(): void {
    this.modal.style.display = 'none';
    this.card.innerHTML = '';
    this.closedAt = performance.now();
    this.clearKeys();
  }

  clearKeys(): void {
    if (this.keyHandler) { document.removeEventListener('keydown', this.keyHandler); this.keyHandler = null; }
  }

  onAdvance(fn: () => void): void {
    this.clearKeys();
    this.keyHandler = (e) => {
      if (['e', 'E', ' ', 'Enter'].includes(e.key)) { e.preventDefault(); fn(); }
    };
    document.addEventListener('keydown', this.keyHandler);
  }

  button(label: string, fn: () => void, cls = ''): HTMLButtonElement {
    const b = document.createElement('button');
    b.textContent = label; b.className = cls; b.onclick = fn;
    return b;
  }

  showDialogue(name: string, lines: string[], done: () => void): void {
    let i = 0;
    const render = () => {
      this.card.innerHTML = '';
      const h = document.createElement('h3'); h.textContent = name;
      const p = document.createElement('p'); p.textContent = lines[i];
      const last = i === lines.length - 1;
      const next = () => { if (last) { this.close(); done(); } else { i++; render(); } };
      this.card.append(h, p, this.button(last ? 'Close' : 'Next ▸', next));
      this.onAdvance(next);
    };
    this.open(); render();
  }

  showSource(s: Source, done: () => void): void {
    this.card.innerHTML = '';
    const h = document.createElement('h3'); h.textContent = s.title;
    const meta = document.createElement('div'); meta.className = 'meta';
    meta.textContent = `${s.kind} • ${s.author} • ${s.place}, ${s.date}`;
    const q = document.createElement('blockquote'); q.textContent = s.text;
    const pov = document.createElement('p');
    const b = document.createElement('b'); b.textContent = 'Point of view: ';
    pov.append(b, document.createTextNode(s.pov));
    const close = () => { this.close(); done(); };
    this.card.append(h, meta, q, pov, this.button('Close', close));
    this.open(); this.onAdvance(close);
  }

  renderHud(): void {
    const into = state.xp % XP_PER_LEVEL;
    const area = AREAS[state.area];
    const active = QUESTS.find((q) => !questDone(q));
    const title = TITLES[Math.min(level(), TITLES.length) - 1];
    let html = `<h4>${title} • Lv ${level()} • ${state.xp} XP</h4><div id="xpbar"><div id="xpfill" style="width:${(into / XP_PER_LEVEL) * 100}%"></div></div>`;
    html += `<div class="meta">📍 ${area.name}<br>Quests ${QUESTS.filter(questDone).length}/${QUESTS.length} • J = Journal</div>`;
    if (active) {
      html += `<div class="q">◇ ${active.title}</div><ul>`;
      for (const o of active.objectives) html += `<li class="${o.done() ? 'done' : ''}">${o.done() ? '☑' : '☐'} ${o.text}</li>`;
      html += '</ul>';
    } else html += '<div class="q done">✔ Chapter complete!</div>';
    $('hud').innerHTML = html;
  }

  prompt(text: string | null): void {
    const el = $('prompt');
    el.style.display = text ? 'block' : 'none';
    if (text) el.textContent = text;
  }

  toast(msg: string): void {
    const el = $('toast'); el.textContent = msg; el.style.display = 'block';
    window.setTimeout(() => (el.style.display = 'none'), 2200);
  }
}
