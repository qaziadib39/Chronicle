import { state, level, XP_PER_LEVEL } from '../state';
import { QUESTS, questDone } from '../quests';
import type { Challenge, Source } from '../data/content';

const $ = (id: string) => document.getElementById(id) as HTMLElement;

export class UI {
  private modal = $('modal');
  private card = $('card');
  closedAt = 0;
  private keyHandler: ((e: KeyboardEvent) => void) | null = null;

  isOpen(): boolean { return this.modal.style.display === 'flex'; }
  private open(): void { this.modal.style.display = 'flex'; }

  close(): void {
    this.modal.style.display = 'none';
    this.card.innerHTML = '';
    this.closedAt = performance.now();
    this.clearKeys();
  }

  private clearKeys(): void {
    if (this.keyHandler) { document.removeEventListener('keydown', this.keyHandler); this.keyHandler = null; }
  }

  private onAdvance(fn: () => void): void {
    this.clearKeys();
    this.keyHandler = (e) => {
      if (['e', 'E', ' ', 'Enter'].includes(e.key)) { e.preventDefault(); fn(); }
    };
    document.addEventListener('keydown', this.keyHandler);
  }

  private button(label: string, fn: () => void, cls = ''): HTMLButtonElement {
    const b = document.createElement('button');
    b.textContent = label; b.className = cls; b.onclick = fn;
    return b;
  }

  showDialogue(name: string, lines: string[], done: () => void): void {
    let i = 0;
    const render = () => {
      this.card.innerHTML = '';
      const h = document.createElement('h3'); h.textContent = name;
      const p = document.createElement('p'); p.textContent = lines[i];
      const last = i === lines.length - 1;
      const next = () => { if (last) { this.close(); done(); } else { i++; render(); } };
      this.card.append(h, p, this.button(last ? 'Close' : 'Next ▸', next));
      this.onAdvance(next);
    };
    this.open(); render();
  }

  showSource(s: Source, done: () => void): void {
    this.card.innerHTML = '';
    const h = document.createElement('h3'); h.textContent = s.title;
    const meta = document.createElement('div'); meta.className = 'meta';
    meta.textContent = `${s.kind} • ${s.author} • ${s.place}, ${s.date}`;
    const q = document.createElement('blockquote'); q.textContent = s.text;
    const pov = document.createElement('p');
    const b = document.createElement('b'); b.textContent = 'Point of view: ';
    pov.append(b, document.createTextNode(s.pov));
    const close = () => { this.close(); done(); };
    this.card.append(h, meta, q, pov, this.button('Close', close));
    this.open(); this.onAdvance(close);
  }

  showChallenge(c: Challenge, sources: Source[], onResult: (correct: boolean) => void): void {
    this.card.innerHTML = '';
    this.clearKeys();
    const h = document.createElement('h3'); h.textContent = 'Evidence Challenge';
    const p = document.createElement('p'); p.textContent = c.prompt;
    this.card.append(h, p);
    sources.forEach((s) => {
      const d = document.createElement('div'); d.className = 'meta';
      d.textContent = `• ${s.title}: ${s.text}`; this.card.append(d);
    });
    const fb = document.createElement('div');
    const btns: HTMLButtonElement[] = [];
    c.options.forEach((o, idx) => {
      const b = this.button(o, () => {
        const ok = idx === c.correct;
        b.classList.add(ok ? 'good' : 'bad');
        fb.className = 'fb'; fb.textContent = c.feedback[idx];
        if (ok) {
          btns.forEach((x) => (x.disabled = true));
          fb.append(document.createElement('br'),
            this.button('Continue', () => { this.close(); onResult(true); }));
        } else { b.disabled = true; }
      }, 'opt');
      btns.push(b); this.card.append(b);
    });
    this.card.append(fb, this.button('Leave', () => { this.close(); onResult(false); }));
    this.open();
  }

  renderHud(): void {
    const into = state.xp % XP_PER_LEVEL;
    let html = `<h4>Level ${level()} • ${state.xp} XP</h4><div id="xpbar"><div id="xpfill" style="width:${(into / XP_PER_LEVEL) * 100}%"></div></div>`;
    for (const q of QUESTS) {
      const d = questDone(q);
      html += `<div class="q ${d ? 'done' : ''}">${d ? '✔' : '◇'} ${q.title}</div><ul>`;
      for (const o of q.objectives) html += `<li class="${o.done() ? 'done' : ''}">${o.done() ? '☑' : '☐'} ${o.text}</li>`;
      html += '</ul>';
    }
    $('hud').innerHTML = html;
  }

  prompt(text: string | null): void {
    const el = $('prompt');
    el.style.display = text ? 'block' : 'none';
    if (text) el.textContent = text;
  }

  toast(msg: string): void {
    const el = $('toast'); el.textContent = msg; el.style.display = 'block';
    window.setTimeout(() => (el.style.display = 'none'), 2200);
  }
}
