import Phaser from 'phaser';
import { GameScene } from './scenes/GameScene';

new Phaser.Game({
  type: Phaser.AUTO,
  parent: 'game',
  width: 800,
  height: 540,
  backgroundColor: '#3f7a46',
  pixelArt: true,
  physics: { default: 'arcade', arcade: { debug: false } },
  scene: [GameScene],
});
