# Chronicle – Educational RPG (Prototype)

2D top-down browser RPG for AP World History: Modern. Built with **Phaser 3 + TypeScript + Vite**.

## Run
```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # type-check + production build into dist/
```
Deploy `dist/` to GitHub Pages, Netlify, or Vercel (`base: './'` is already set).

## Prototype features
Top-down movement (WASD/arrows) • Silk Road crossroads map with collisions • NPC dialogue •
Interactive artifacts • Quest/objective tracker • Source viewer (author, date, point of view) •
Evidence challenge with per-answer explanatory feedback • XP and levels • Progress saved in `localStorage`.

## Structure
- `src/data/content.ts` – all NPCs, sources, challenges (swap for real sourced content / a database)
- `src/quests.ts` – quest and objective definitions
- `src/state.ts` – player state, XP, persistence (replace `save()` with Supabase calls later)
- `src/scenes/GameScene.ts` – world, movement, interaction
- `src/ui/ui.ts` – HUD, dialogue, source viewer, challenge UI (DOM overlay)

## Roadmap
1. Replace placeholder sources with real cited primary sources.
2. Replace generated art with a Tiled tilemap + sprite sheets.
3. Move to React UI shell + Supabase auth/progress tables.
4. Add more regions, units, and AP-style (SAQ/DBQ) challenges.

Reset progress: run `localStorage.removeItem('chronicle-save-v1')` in the browser console.

## v0.2 additions
- Title screen with subject picker (only AP World History is playable) and optional login.
- Second area: Indian Ocean Port (unlocks after the first challenge) with its own quests and sources.
- Challenge types: multiple choice, **evidence tagging** (supports/contradicts/not relevant), and **short-answer (SAQ)** with model answers.
- Historian's Journal (press J): collected evidence you can re-read, plus level titles.
- Cloud saves with Supabase: run `supabase/schema.sql` in the Supabase SQL editor, copy `.env.example` to `.env`, fill in the two values, restart `npm run dev`. Without them the game runs in guest mode.
